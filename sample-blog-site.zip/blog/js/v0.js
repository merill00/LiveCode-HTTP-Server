self.AMP_CONFIG = {
	v: '012007242032002',
	type: 'production',
	'allow-doc-opt-in': [ 'amp-next-page', 'analytics-chunks', 'analytics-chunks-inabox' ],
	'allow-url-opt-in': [ 'pump-early-frame' ],
	canary: 0,
	a4aProfilingRate: 0.01,
	'adsense-ad-size-optimization': 0.01,
	'amp-access-iframe': 1,
	'amp-action-macro': 1,
	'amp-ad-ff-adx-ady': 0.01,
	'amp-auto-ads-adsense-holdout': 0.1,
	'ampdoc-fie': 0.1,
	'amp-mega-menu': 1,
	'amp-nested-menu': 1,
	'amp-playbuzz': 1,
	'amp-sidebar-swipe-to-dismiss': 1,
	'amp-story-responsive-units': 1,
	'amp-story-v1': 1,
	'chunked-amp': 1,
	doubleclickSraExp: 0.01,
	doubleclickSraReportExcludedBlock: 0.1,
	'expand-json-targeting': 0.01,
	'fix-inconsistent-responsive-height-selection': 0,
	'fixed-elements-in-lightbox': 1,
	flexAdSlots: 0.05,
	'hidden-mutation-observer': 1,
	'intersect-resources': 0.1,
	'ios-fixed-no-transfer': 0,
	'layoutbox-invalidate-on-scroll': 1,
	'pump-early-frame': 1,
	'swg-gpay-api': 1,
	'swg-gpay-native': 1,
	'version-locking': 1,
	'amp-ad-no-center-css': 0,
	'analytics-chunks': 1,
	'sticky-ad-padding-bottom': 0.05,
	'render-on-idle-fix': 0.02,
	'ad-adsense-gam-round-params': 0.02
};
/*AMP_CONFIG*/ var global = self;
self.AMP = self.AMP || [];
try {
	(function(_) {
		var f,
			aa =
				'function' == typeof Object.create
					? Object.create
					: function(a) {
							function b() {}
							b.prototype = a;
							return new b();
						};
		function ba(a) {
			for (
				var b = [
						'object' == typeof globalThis && globalThis,
						a,
						'object' == typeof window && window,
						'object' == typeof self && self,
						'object' == typeof global && global
					],
					c = 0;
				c < b.length;
				++c
			) {
				var d = b[c];
				if (d && d.Math == Math) return d;
			}
			return (function() {
				throw Error('Cannot find global object');
			})();
		}
		var da = ba(this);
		'function' === typeof Symbol && Symbol('x');
		var ea;
		if ('function' == typeof Object.setPrototypeOf) ea = Object.setPrototypeOf;
		else {
			var fa;
			a: {
				var ha = { a: !0 },
					ia = {};
				try {
					ia.__proto__ = ha;
					fa = ia.a;
					break a;
				} catch (a) {}
				fa = !1;
			}
			ea = fa
				? function(a, b) {
						a.__proto__ = b;
						if (a.__proto__ !== b) throw new TypeError(a + ' is not extensible');
						return a;
					}
				: null;
		}
		var ka = ea;
		function m(a, b) {
			a.prototype = aa(b.prototype);
			a.prototype.constructor = a;
			if (ka) ka(a, b);
			else
				for (var c in b)
					if ('prototype' != c)
						if (Object.defineProperties) {
							var d = Object.getOwnPropertyDescriptor(b, c);
							d && Object.defineProperty(a, c, d);
						} else a[c] = b[c];
			a.hi = b.prototype;
		}
		function la(a, b) {
			b = void 0 === b ? '' : b;
			try {
				return decodeURIComponent(a);
			} catch (c) {
				return b;
			}
		}
		var ma = /(?:^[#?]?|&)([^=&]+)(?:=([^&]*))?/g;
		function t(a) {
			var b = Object.create(null);
			if (!a) return b;
			for (var c; (c = ma.exec(a)); ) {
				var d = la(c[1], c[1]),
					e = c[2] ? la(c[2].replace(/\+/g, ' '), c[2]) : '';
				b[d] = e;
			}
			return b;
		}
		var oa = '';
		function v(a) {
			var b = a || self;
			if (b.__AMP_MODE) var c = b.__AMP_MODE;
			else {
				c = t(b.location.originalHash || b.location.hash);
				var d = t(b.location.search);
				oa || (oa = b.AMP_CONFIG && b.AMP_CONFIG.v ? b.AMP_CONFIG.v : '012007242032002');
				c = {
					localDev: !1,
					development: !!(
						0 <= [ '1', 'actions', 'amp', 'amp4ads', 'amp4email' ].indexOf(c.development) || b.AMP_DEV_MODE
					),
					examiner: '2' == c.development,
					esm: !1,
					geoOverride: c['amp-geo'],
					minified: !0,
					lite: void 0 != d.amp_lite,
					test: !1,
					log: c.log,
					version: '2007242032002',
					rtvVersion: oa
				};
				c = b.__AMP_MODE = c;
			}
			return c;
		}
		function pa(a, b) {
			var c = b || 0,
				d = this.length;
			for (b = 0 <= c ? c : Math.max(d + c, 0); b < d; b++) {
				var e = this[b];
				if (e === a || (a !== a && e !== e)) return !0;
			}
			return !1;
		}
		var qa;
		function x() {
			return qa ? qa : (qa = Promise.resolve(void 0));
		}
		var ra = /^[a-z][a-z0-9._]*-[a-z0-9._-]*$/,
			sa = 'annotation-xml color-profile font-face font-face-src font-face-uri font-face-format font-face-name missing-glyph'.split(
				' '
			),
			ta = { childList: !0, subtree: !0 };
		function ua(a, b) {
			if (!ra.test(b) || sa.includes(b)) throw new a('invalid custom element name "' + b + '"');
		}
		function va(a) {
			setTimeout(function() {
				self.__AMP_REPORT_ERROR(a);
				throw a;
			});
		}
		function wa(a, b) {
			this.w = a;
			this.Oc = b;
			this.Wf = Object.create(null);
		}
		wa.prototype.define = function(a, b, c) {
			this.Oc.define(a, b, c);
			var d = this.Wf,
				e = d[a];
			e && (e.resolve(), delete d[a]);
		};
		wa.prototype.get = function(a) {
			var b = this.Oc.getByName(a);
			if (b) return b.ctor;
		};
		wa.prototype.whenDefined = function(a) {
			var b = this.w,
				c = b.Promise;
			ua(b.SyntaxError, a);
			if (this.Oc.getByName(a)) return x();
			b = this.Wf;
			var d = b[a];
			if (d) return d.promise;
			var e,
				g = new c(function(a) {
					return (e = a);
				});
			b[a] = { promise: g, resolve: e };
			return g;
		};
		wa.prototype.upgrade = function(a) {
			this.Oc.upgrade(a);
		};
		function xa(a) {
			this.w = a;
			this.Fd = Object.create(null);
			this.Pa = '';
			this.ma = this.Ed = null;
			this.ue = [ a.document ];
		}
		f = xa.prototype;
		f.current = function() {
			var a = this.Ed;
			this.Ed = null;
			return a;
		};
		f.getByName = function(a) {
			var b = this.Fd[a];
			if (b) return b;
		};
		f.getByConstructor = function(a) {
			var b = this.Fd,
				c;
			for (c in b) {
				var d = b[c];
				if (d.ctor === a) return d;
			}
		};
		f.define = function(a, b, c) {
			var d = this,
				e = this.w,
				g = e.Error;
			e = e.SyntaxError;
			if (c) throw new g('Extending native custom elements is not supported');
			ua(e, a);
			if (this.getByName(a) || this.getByConstructor(b)) throw new g('duplicate definition "' + a + '"');
			this.Fd[a] = { name: a, ctor: b };
			ya(this, a);
			this.ue.forEach(function(b) {
				d.upgrade(b, a);
			});
		};
		f.upgrade = function(a, b) {
			var c = !!b,
				d = za(a, b || this.Pa);
			for (a = 0; a < d.length; a++) {
				var e = d[a];
				c ? Aa(this, e) : this.upgradeSelf(e);
			}
		};
		f.upgradeSelf = function(a) {
			var b = this.getByName(a.localName);
			b && Ba(this, a, b);
		};
		function za(a, b) {
			return b && a.querySelectorAll ? a.querySelectorAll(b) : [];
		}
		function Ba(a, b, c) {
			c = c.ctor;
			if (!(b instanceof c)) {
				a.Ed = b;
				try {
					if (new c() !== b) throw new a.w.Error('Constructor illegally returned a different instance.');
				} catch (d) {
					va(d);
				}
			}
		}
		function Aa(a, b) {
			var c = a.getByName(b.localName);
			if (c && (Ba(a, b, c), b.connectedCallback))
				try {
					b.connectedCallback();
				} catch (d) {
					va(d);
				}
		}
		function ya(a, b) {
			if (a.Pa) a.Pa += ',' + b;
			else {
				a.Pa = b;
				var c = new a.w.MutationObserver(function(b) {
					b && Ca(a, b);
				});
				a.ma = c;
				a.ue.forEach(function(a) {
					c.observe(a, ta);
				});
				Da(a.w, a);
			}
		}
		f.observe = function(a) {
			this.ue.push(a);
			this.ma && this.ma.observe(a, ta);
		};
		f.sync = function() {
			this.ma && Ca(this, this.ma.takeRecords());
		};
		function Ca(a, b) {
			for (var c = 0; c < b.length; c++) {
				var d = b[c];
				if (d) {
					var e = d,
						g = e.addedNodes,
						h = e.removedNodes;
					for (e = 0; e < g.length; e++) {
						var l = g[e],
							k = za(l, a.Pa);
						Aa(a, l);
						for (l = 0; l < k.length; l++) Aa(a, k[l]);
					}
					for (e = 0; e < h.length; e++) {
						l = h[e];
						var n = za(l, a.Pa);
						if (l.disconnectedCallback)
							try {
								l.disconnectedCallback();
							} catch (u) {
								va(u);
							}
						for (l = 0; l < n.length; l++) {
							var r = n[l];
							if (r.disconnectedCallback)
								try {
									r.disconnectedCallback();
								} catch (u) {
									va(u);
								}
						}
					}
				}
			}
		}
		function Da(a, b) {
			var c = a.document,
				d = a.Document.prototype,
				e = a.Element.prototype,
				g = a.Node.prototype,
				h = d.createElement,
				l = d.importNode,
				k = g.appendChild,
				n = g.cloneNode,
				r = g.insertBefore,
				u = g.removeChild,
				w = g.replaceChild;
			d.createElement = function(a) {
				var c = b.getByName(a);
				return c ? new c.ctor() : h.apply(this, arguments);
			};
			d.importNode = function() {
				var a = l.apply(this, arguments);
				a && this === c && (b.upgradeSelf(a), b.upgrade(a));
				return a;
			};
			g.appendChild = function() {
				var a = k.apply(this, arguments);
				b.sync();
				return a;
			};
			g.insertBefore = function() {
				var a = r.apply(this, arguments);
				b.sync();
				return a;
			};
			g.removeChild = function() {
				var a = u.apply(this, arguments);
				b.sync();
				return a;
			};
			g.replaceChild = function() {
				var a = w.apply(this, arguments);
				b.sync();
				return a;
			};
			g.cloneNode = function() {
				var a = n.apply(this, arguments);
				a.ownerDocument === c && (b.upgradeSelf(a), b.upgrade(a));
				return a;
			};
			var y = e,
				p = Object.getOwnPropertyDescriptor(y, 'innerHTML');
			p ||
				((y = Object.getPrototypeOf(a.HTMLElement.prototype)),
				(p = Object.getOwnPropertyDescriptor(y, 'innerHTML')));
			if (p && p.configurable) {
				var q = p.set;
				p.set = function(a) {
					q.call(this, a);
					b.upgrade(this);
				};
				Object.defineProperty(y, 'innerHTML', p);
			}
		}
		function Ea() {
			function a() {
				var a = this.constructor,
					b = h.current();
				b || ((b = h.getByConstructor(a)), (b = g.call(e, b.name)));
				Fa(b, a.prototype);
				return b;
			}
			var b = Ga,
				c = b.Element,
				d = b.HTMLElement,
				e = b.document,
				g = e.createElement,
				h = new xa(b),
				l = new wa(b, h);
			Object.defineProperty(b, 'customElements', { enumerable: !0, configurable: !0, value: l });
			c = c.prototype;
			var k = c.attachShadow,
				n = c.createShadowRoot;
			k &&
				((c.attachShadow = function(a) {
					var b = k.apply(this, arguments);
					h.observe(b);
					return b;
				}),
				(c.attachShadow.toString = function() {
					return k.toString();
				}));
			n &&
				((c.createShadowRoot = function() {
					var a = n.apply(this, arguments);
					h.observe(a);
					return a;
				}),
				(c.createShadowRoot.toString = function() {
					return n.toString();
				}));
			Ha(d, a);
			b.HTMLElement = a;
			a.call || ((a.apply = b.Function.apply), (a.bind = b.Function.bind), (a.call = b.Function.call));
		}
		function Ia() {
			function a() {
				return d.construct(c, [], this.constructor);
			}
			var b = Ga,
				c = b.HTMLElement,
				d = b.Reflect;
			Ha(c, a);
			b.HTMLElement = a;
		}
		function Ha(a, b) {
			b.prototype = Object.create(a.prototype, { constructor: { configurable: !0, writable: !0, value: b } });
			Fa(b, a);
		}
		function Fa(a, b) {
			if (Object.setPrototypeOf) Object.setPrototypeOf(a, b);
			else if ({ __proto__: { test: !0 } }.test) a.__proto__ = b;
			else
				for (; null !== b && !Object.isPrototypeOf.call(b, a); ) {
					for (var c = Object.getOwnPropertyNames(b), d = 0; d < c.length; d++) {
						var e = c[d];
						if (!Object.hasOwnProperty.call(a, e)) {
							var g = Object.getOwnPropertyDescriptor(b, e);
							Object.defineProperty(a, e, g);
						}
					}
					b = Object.getPrototypeOf(b);
				}
		}
		function Ja(a, b) {
			if (void 0 === b ? this.contains(a) : !b) return this.remove(a), !1;
			this.add(a);
			return !0;
		}
		function Ka() {
			var a = self;
			if (/Trident|MSIE|IEMobile/i.test(a.navigator.userAgent) && a.DOMTokenList) {
				a.Object.defineProperty(a.DOMTokenList.prototype, 'toggle', {
					enumerable: !1,
					configurable: !0,
					writable: !0,
					value: Ja
				});
				var b = a.DOMTokenList.prototype.add;
				a.DOMTokenList.prototype.add = function() {
					for (var a = 0; a < arguments.length; a++) b.call(this, arguments[a]);
				};
			}
		}
		function La(a) {
			return a == this || this.documentElement.contains(a);
		}
		var Ma = Object.prototype.toString;
		function z(a) {
			return Array.isArray(a);
		}
		function Na(a) {
			return a ? Array.prototype.slice.call(a) : [];
		}
		function Oa(a) {
			return '[object Object]' === Ma.call(a);
		}
		function Pa(a) {
			return 'number' === typeof a && isFinite(a);
		}
		function Qa(a) {
			var b = !1,
				c = null,
				d = a;
			return function(a) {
				for (var e = [], h = 0; h < arguments.length; ++h) e[h - 0] = arguments[h];
				b || ((c = d.apply(self, e)), (b = !0), (d = null));
				return c;
			};
		}
		var A = self.AMP_CONFIG || {},
			Ra =
				('string' == typeof A.cdnProxyRegex ? new RegExp(A.cdnProxyRegex) : A.cdnProxyRegex) ||
				/^https:\/\/([a-zA-Z0-9_-]+\.)?cdn\.ampproject\.org$/;
		function Sa(a) {
			if (!self.document || !self.document.head || (self.location && Ra.test(self.location.origin))) return null;
			var b = self.document.head.querySelector('meta[name="' + a + '"]');
			return (b && b.getAttribute('content')) || null;
		}
		var B = {
				thirdParty: A.thirdPartyUrl || 'https://3p.ampproject.net',
				thirdPartyFrameHost: A.thirdPartyFrameHost || 'ampproject.net',
				thirdPartyFrameRegex:
					('string' == typeof A.thirdPartyFrameRegex
						? new RegExp(A.thirdPartyFrameRegex)
						: A.thirdPartyFrameRegex) || /^d-\d+\.ampproject\.net$/,
				cdn: A.cdnUrl || Sa('runtime-host') || 'https://cdn.ampproject.org',
				cdnProxyRegex: Ra,
				localhostRegex: /^https?:\/\/localhost(:\d+)?$/,
				errorReporting: A.errorReportingUrl || 'https://us-central1-amp-error-reporting.cloudfunctions.net/r',
				betaErrorReporting:
					A.betaErrorReportingUrl || 'https://us-central1-amp-error-reporting.cloudfunctions.net/r-beta',
				localDev: A.localDev || !1,
				trustedViewerHosts: [ /(^|\.)google\.(com?|[a-z]{2}|com?\.[a-z]{2}|cat)$/, /(^|\.)gmail\.(com|dev)$/ ],
				geoApi: A.geoApiUrl || Sa('amp-geo-api')
			},
			Ta = { urls: B };
		function Ua() {}
		function Va(a) {
			return 0 <= a.indexOf('\u200b\u200b\u200b');
		}
		var Wa = void 0;
		function Xa(a) {
			Wa = a;
		}
		function Ya(a, b) {
			return b.reduce(function(a, b) {
				return a + '&s[]=' + encodeURIComponent(String(Za(b)));
			}, 'https://log.amp.dev/?v=012007242032002&id=' + encodeURIComponent(a));
		}
		function $a(a, b, c) {
			var d = this;
			c = void 0 === c ? '' : c;
			this.win = a;
			this.nh = b;
			this.oh =
				this.win.console && this.win.console.log && '0' != v().log
					? this.nh(parseInt(v().log, 10), v().development)
					: 0;
			this.Yc = c;
			this.Cc = null;
			this.Ug = Qa(function() {
				a
					.fetch(B.cdn + '/rtv/012007242032002/log-messages.simple.json')
					.then(function(a) {
						return a.json();
					}, Ua)
					.then(function(a) {
						a && (d.Cc = a);
					});
			});
		}
		function ab(a) {
			return void 0 !== Wa ? Wa : a.oh;
		}
		function bb(a, b, c, d) {
			if (0 != ab(a)) {
				var e = a.win.console.log;
				'ERROR' == c
					? (e = a.win.console.error || e)
					: 'INFO' == c ? (e = a.win.console.info || e) : 'WARN' == c && (e = a.win.console.warn || e);
				c = z(d[0]) ? cb(a, d[0]) : d;
				b = '[' + b + ']';
				'string' === typeof c[0] ? (c[0] = b + ' ' + c[0]) : c.unshift(b);
				e.apply(a.win.console, c);
			}
		}
		f = $a.prototype;
		f.isEnabled = function() {
			return 0 != ab(this);
		};
		f.fine = function(a, b) {
			4 <= ab(this) && bb(this, a, 'FINE', Array.prototype.slice.call(arguments, 1));
		};
		f.info = function(a, b) {
			3 <= ab(this) && bb(this, a, 'INFO', Array.prototype.slice.call(arguments, 1));
		};
		f.warn = function(a, b) {
			2 <= ab(this) && bb(this, a, 'WARN', Array.prototype.slice.call(arguments, 1));
		};
		f.La = function(a, b) {
			if (1 <= ab(this)) bb(this, a, 'ERROR', Array.prototype.slice.call(arguments, 1));
			else {
				var c = db.apply(null, Array.prototype.slice.call(arguments, 1));
				eb(this, c);
				return c;
			}
		};
		f.error = function(a, b) {
			var c = this.La.apply(this, arguments);
			c && ((c.name = a || c.name), self.__AMP_REPORT_ERROR(c));
		};
		f.expectedError = function(a, b) {
			var c = this.La.apply(this, arguments);
			c && ((c.expected = !0), self.__AMP_REPORT_ERROR(c));
		};
		f.createError = function(a) {
			var b = db.apply(null, arguments);
			eb(this, b);
			return b;
		};
		f.createExpectedError = function(a) {
			var b = db.apply(null, arguments);
			eb(this, b);
			b.expected = !0;
			return b;
		};
		f.assert = function(a, b, c) {
			var d;
			if (z(b)) return this.assert.apply(this, [ a ].concat(cb(this, b)));
			if (!a) {
				var e = (b || 'Assertion failed').split('%s'),
					g = e.shift(),
					h = g,
					l = [],
					k = 2;
				for ('' != g && l.push(g); 0 < e.length; ) {
					var n = e.shift(),
						r = arguments[k++];
					r && r.tagName && (d = r);
					l.push(r);
					g = n.trim();
					'' != g && l.push(g);
					h += Za(r) + n;
				}
				k = Error(h);
				k.fromAssert = !0;
				k.associatedElement = d;
				k.messageArray = l;
				eb(this, k);
				self.__AMP_REPORT_ERROR(k);
				throw k;
			}
			return a;
		};
		f.assertElement = function(a, b) {
			fb(this, a, a && 1 == a.nodeType, 'Element expected', b);
			return a;
		};
		f.assertString = function(a, b) {
			fb(this, a, 'string' == typeof a, 'String expected', b);
			return a;
		};
		f.assertNumber = function(a, b) {
			fb(this, a, 'number' == typeof a, 'Number expected', b);
			return a;
		};
		f.assertArray = function(a, b) {
			fb(this, a, z(a), 'Array expected', b);
			return a;
		};
		f.assertBoolean = function(a, b) {
			fb(this, a, !!a === a, 'Boolean expected', b);
			return a;
		};
		f.assertEnumValue = function(a, b, c) {
			a: {
				for (var d in a)
					if (a[d] === b) {
						a = !0;
						break a;
					}
				a = !1;
			}
			if (a) return b;
			this.assert(!1, 'Unknown %s value: "%s"', c || 'enum', b);
		};
		function eb(a, b) {
			b = gb(b);
			a.Yc
				? b.message ? -1 == b.message.indexOf(a.Yc) && (b.message += a.Yc) : (b.message = a.Yc)
				: Va(b.message) && (b.message = b.message.replace('\u200b\u200b\u200b', ''));
		}
		function cb(a, b) {
			var c = b.shift();
			v(a.win).development && a.Ug();
			return a.Cc && c in a.Cc ? [ a.Cc[c] ].concat(b) : [ 'More info at ' + Ya(c, b) ];
		}
		function fb(a, b, c, d, e) {
			z(e) ? a.assert(c, e.concat(b)) : a.assert(c, (e || d) + ': %s', b);
		}
		function Za(a) {
			return a && 1 == a.nodeType ? a.tagName.toLowerCase() + (a.id ? '#' + a.id : '') : a;
		}
		function gb(a) {
			var b = Object.getOwnPropertyDescriptor(a, 'message');
			if (b && b.writable) return a;
			var c = a.stack,
				d = Error(a.message),
				e;
			for (e in a) d[e] = a[e];
			d.stack = c;
			return d;
		}
		function db(a) {
			for (var b = null, c = '', d = 0; d < arguments.length; d++) {
				var e = arguments[d];
				e instanceof Error && !b ? (b = gb(e)) : (c && (c += ' '), (c += e));
			}
			b ? c && (b.message = c + ': ' + b.message) : (b = Error(c));
			return b;
		}
		function hb(a) {
			var b = db.apply(null, arguments);
			setTimeout(function() {
				self.__AMP_REPORT_ERROR(b);
				throw b;
			});
		}
		self.__AMP_LOG = self.__AMP_LOG || { user: null, dev: null, userForEmbed: null };
		var ib = self.__AMP_LOG,
			kb = null;
		function C(a) {
			ib.user || (ib.user = lb('\u200b\u200b\u200b'));
			var b = ib.user.win;
			return a && a.ownerDocument.defaultView != b
				? ib.userForEmbed ? ib.userForEmbed : (ib.userForEmbed = lb('\u200b\u200b\u200b\u200b'))
				: ib.user;
		}
		function lb(a) {
			if (!kb) throw Error('failed to call initLogConstructor');
			return new kb(
				self,
				function(a, c) {
					return c || 1 <= a ? 4 : 2;
				},
				a
			);
		}
		function F() {
			if (ib.dev) return ib.dev;
			if (!kb) throw Error('failed to call initLogConstructor');
			return (ib.dev = new kb(self, function(a) {
				return 3 <= a ? 4 : 2 <= a ? 3 : 0;
			}));
		}
		function G(a, b, c, d, e, g) {
			return C().assert(a, b, c, d, e, g, void 0, void 0, void 0, void 0, void 0);
		}
		var mb = Object.prototype.hasOwnProperty;
		function I(a) {
			var b = Object.create(null);
			a && Object.assign(b, a);
			return b;
		}
		function K(a) {
			return a || {};
		}
		function L() {
			var a, b;
			this.promise = new Promise(function(c, d) {
				a = c;
				b = d;
			});
			this.resolve = a;
			this.reject = b;
		}
		function nb(a) {
			return new Promise(function(b) {
				b(a());
			});
		} /*
 https://mths.be/cssescape v1.5.1 by @mathias | MIT license */
		var ob = /(\0)|^(-)$|([\x01-\x1f\x7f]|^-?[0-9])|([\x80-\uffff0-9a-zA-Z_-]+)|[^]/g;
		function pb(a, b, c, d, e) {
			return e
				? e
				: b ? '\ufffd' : d ? a.slice(0, -1) + '\\' + a.slice(-1).charCodeAt(0).toString(16) + ' ' : '\\' + a;
		}
		var qb;
		function rb(a) {
			try {
				var b = a.ownerDocument,
					c = b.createElement('div'),
					d = b.createElement('div');
				c.appendChild(d);
				return c.querySelector(':scope div') === d;
			} catch (e) {
				return !1;
			}
		}
		function sb(a, b) {
			var c = a.length - b.length;
			return 0 <= c && a.indexOf(b, c) == c;
		}
		function M(a, b) {
			return b.length > a.length ? !1 : 0 == a.lastIndexOf(b, 0);
		}
		function tb(a) {
			return a.trimStart ? a.trimStart() : (a + '_').trim().slice(0, -1);
		}
		function ub(a, b, c) {
			if (b(a)) c();
			else {
				var d = a.ownerDocument.defaultView;
				if (d.MutationObserver) {
					var e = new d.MutationObserver(function() {
						b(a) && (e.disconnect(), c());
					});
					e.observe(a, { childList: !0 });
				} else
					var g = d.setInterval(function() {
						b(a) && (d.clearInterval(g), c());
					}, 5);
			}
		}
		function vb(a, b) {
			return new Promise(function(c) {
				ub(a, b, c);
			});
		}
		function wb(a, b) {
			ub(
				a.documentElement,
				function() {
					return !!a.body;
				},
				b
			);
		}
		function xb(a) {
			return new Promise(function(b) {
				return wb(a, b);
			});
		}
		function yb(a) {
			a.parentElement && a.parentElement.removeChild(a);
		}
		function zb(a) {
			var b = K({ src: 'about:blank', style: 'display:none' });
			a = a.createElement('iframe');
			for (var c in b) a.setAttribute(c, b[c]);
			return a;
		}
		function Ab(a) {
			var b = a.isConnected;
			if (void 0 !== b) return b;
			do
				if (((a = Bb(a)), a.host)) a = a.host;
				else break;
			while (1);
			return a.nodeType === Node.DOCUMENT_NODE;
		}
		function Bb(a) {
			if (Node.prototype.getRootNode) return a.getRootNode() || a;
			for (; a.parentNode && !Cb(a); a = a.parentNode);
			return a;
		}
		function Cb(a) {
			return a
				? 'I-AMPHTML-SHADOW-ROOT' == a.tagName
					? !0
					: 11 == a.nodeType && '[object ShadowRoot]' === Object.prototype.toString.call(a)
				: !1;
		}
		function Db(a, b) {
			for (; a && void 0 !== a; a = a.parentElement) if (b(a)) return a;
			return null;
		}
		function Eb(a, b) {
			for (; a; a = a.parentNode) if (b(a)) return a;
			return null;
		}
		function Fb(a, b) {
			return a.closest
				? a.closest(b)
				: Db(a, function(a) {
						return Gb(a, b);
					});
		}
		function Hb(a, b) {
			var c = [];
			for (a = a.firstElementChild; a; a = a.nextElementSibling) b(a) && c.push(a);
			return c;
		}
		function Ib(a, b) {
			for (a = a.lastElementChild; a; a = a.previousElementSibling) if (b(a)) return a;
			return null;
		}
		function Jb(a, b) {
			var c = [];
			for (a = a.firstChild; a; a = a.nextSibling) b(a) && c.push(a);
			return c;
		}
		function Kb(a, b) {
			/^[\w-]+$/.test(b);
			return Lb(a, '> [' + b + ']');
		}
		function Gb(a, b) {
			var c =
				a.matches ||
				a.webkitMatchesSelector ||
				a.mozMatchesSelector ||
				a.msMatchesSelector ||
				a.oMatchesSelector;
			return c ? c.call(a, b) : !1;
		}
		function Mb(a, b) {
			a.classList.add('i-amphtml-scoped');
			var c = b.replace(/^|,/g, '$&.i-amphtml-scoped '),
				d = a.querySelectorAll(c);
			a.classList.remove('i-amphtml-scoped');
			return d;
		}
		function Lb(a, b) {
			if (void 0 !== qb ? qb : (qb = rb(a))) return a.querySelector(b.replace(/^|,/g, '$&:scope '));
			var c = Mb(a, b);
			return void 0 === c[0] ? null : c[0];
		}
		function Nb(a, b) {
			for (var c = a.length, d = 0; d < c; d++) b(a[d], d);
		}
		function Ob(a, b, c, d) {
			try {
				var e = a.open(b, c, d);
			} catch (h) {
				F().error('DOM', 'Failed to open url on target: ', c, h);
			}
			if (!(c = e || '_top' == c)) {
				c = d || '';
				var g;
				'number' !== typeof g && (g = 0);
				c = g + 8 > c.length ? !1 : -1 !== c.indexOf('noopener', g);
			}
			c || (e = a.open(b, '_top'));
			return e;
		}
		function Pb(a) {
			try {
				a.focus();
			} catch (b) {}
		}
		function Qb(a) {
			return a.parent && a.parent != a;
		}
		function Rb(a) {
			var b = Object.create(null),
				c;
			for (c in a)
				if (Sb(a, c)) {
					var d = a[c];
					b[c] = Oa(d) ? Rb(d) : d;
				}
			return b;
		}
		function Tb(a) {
			return JSON.parse(a);
		}
		function Sb(a, b) {
			return null == a || 'object' != typeof a ? !1 : Object.prototype.hasOwnProperty.call(a, b);
		}
		function Ub(a) {
			return 'undefined' !== typeof TextEncoder
				? new TextEncoder('utf-8').encode(a)
				: Vb(unescape(encodeURIComponent(a)));
		}
		function Vb(a) {
			for (var b = new Uint8Array(a.length), c = 0; c < a.length; c++) {
				var d = a.charCodeAt(c);
				b[c] = d;
			}
			return b;
		}
		function Wb(a) {
			for (var b = Array(a.length), c = 0; c < a.length; c++) b[c] = String.fromCharCode(a[c]);
			return b.join('');
		}
		var Xb = { document: 1, text: 2 },
			Yb = [ 'GET', 'POST' ];
		function Zb(a, b) {
			b = void 0 === b ? {} : b;
			return new Promise(function(c, d) {
				var e = $b(b.method || 'GET'),
					g = ac(e, a);
				'include' == b.credentials && (g.withCredentials = !0);
				b.responseType in Xb && (g.responseType = b.responseType);
				b.headers &&
					Object.keys(b.headers).forEach(function(a) {
						g.setRequestHeader(a, b.headers[a]);
					});
				g.onreadystatechange = function() {
					2 > g.readyState ||
						(100 > g.status || 599 < g.status
							? ((g.onreadystatechange = null),
								d(C().createExpectedError('Unknown HTTP status ' + g.status)))
							: 4 == g.readyState && c(new bc(g)));
				};
				g.onerror = function() {
					d(C().createExpectedError('Network failure'));
				};
				g.onabort = function() {
					d(C().createExpectedError('Request aborted'));
				};
				'POST' == e ? g.send(b.body) : g.send();
			});
		}
		function ac(a, b) {
			var c = new XMLHttpRequest();
			if ('withCredentials' in c) c.open(a, b, !0);
			else throw F().createExpectedError('CORS is not supported');
			return c;
		}
		function bc(a) {
			this.Ta = a;
			this.status = this.Ta.status;
			this.statusText = this.Ta.statusText;
			this.ok = 200 <= this.status && 300 > this.status;
			this.headers = new cc(a);
			this.bodyUsed = !1;
			this.body = null;
			this.url = a.responseURL;
		}
		bc.prototype.clone = function() {
			return new bc(this.Ta);
		};
		function dc(a) {
			a.bodyUsed = !0;
			return Promise.resolve(a.Ta.responseText);
		}
		bc.prototype.text = function() {
			return dc(this);
		};
		bc.prototype.json = function() {
			return dc(this).then(Tb);
		};
		bc.prototype.arrayBuffer = function() {
			return dc(this).then(Ub);
		};
		function $b(a) {
			if (void 0 === a) return 'GET';
			a = a.toUpperCase();
			Yb.includes(a);
			return a;
		}
		function cc(a) {
			this.Ta = a;
		}
		cc.prototype.get = function(a) {
			return this.Ta.getResponseHeader(a);
		};
		cc.prototype.has = function(a) {
			return null != this.Ta.getResponseHeader(a);
		};
		function ec(a, b) {
			b = void 0 === b ? {} : b;
			var c = I();
			a = Object.assign(
				{},
				{
					status: 200,
					statusText: 'OK',
					responseText: a ? String(a) : '',
					getResponseHeader: function(a) {
						var b = String(a).toLowerCase();
						return mb.call(c, b) ? c[b] : null;
					}
				},
				b
			);
			a.status = void 0 === b.status ? 200 : parseInt(b.status, 10);
			if (z(b.headers))
				b.headers.forEach(function(a) {
					var b = a[1];
					c[String(a[0]).toLowerCase()] = String(b);
				});
			else if (Oa(b.headers)) for (var d in b.headers) c[String(d).toLowerCase()] = String(b.headers[d]);
			b.statusText && (a.statusText = String(b.statusText));
			bc.call(this, a);
		}
		m(ec, bc);
		function fc(a, b, c, d) {
			return { left: a, top: b, width: c, height: d, bottom: b + d, right: a + c, x: a, y: b };
		}
		function gc(a) {
			for (var b = -Infinity, c = Infinity, d = -Infinity, e = Infinity, g = 0; g < arguments.length; g++) {
				var h = arguments[g];
				if (
					h &&
					((b = Math.max(b, h.left)),
					(c = Math.min(c, h.left + h.width)),
					(d = Math.max(d, h.top)),
					(e = Math.min(e, h.top + h.height)),
					c < b || e < d)
				)
					return null;
			}
			return Infinity == c ? null : fc(b, d, c - b, e - d);
		}
		function hc(a, b, c) {
			return fc(a.left - a.width * b, a.top - a.height * c, a.width * (1 + 2 * b), a.height * (1 + 2 * c));
		}
		function ic(a, b, c) {
			return (0 == b && 0 == c) || (0 == a.width && 0 == a.height)
				? a
				: fc(a.left + b, a.top + c, a.width, a.height);
		}
		var jc;
		function kc() {
			return Ab(this) ? jc.call(this) : fc(0, 0, 0, 0);
		}
		function lc() {
			var a = mc;
			if (!a.document) return !1;
			try {
				return 0 !== a.document.createElement('div').getBoundingClientRect().top;
			} catch (b) {
				return !0;
			}
		}
		function nc() {
			this.Mg = 100;
			this.nd = this.aa = 0;
			this.Va = Object.create(null);
		}
		nc.prototype.has = function(a) {
			return !!this.Va[a];
		};
		nc.prototype.get = function(a) {
			var b = this.Va[a];
			if (b) return (b.access = ++this.nd), b.payload;
		};
		nc.prototype.put = function(a, b) {
			this.has(a) || this.aa++;
			this.Va[a] = { payload: b, access: this.nd };
			if (!(this.aa <= this.Mg)) {
				F().warn('lru-cache', 'Trimming LRU cache');
				a = this.Va;
				var c = this.nd + 1,
					d;
				for (d in a) {
					var e = a[d].access;
					if (e < c) {
						c = e;
						var g = d;
					}
				}
				void 0 !== g && (delete a[g], this.aa--);
			}
		};
		var oc = K({ c: !0, v: !0, a: !0, ad: !0, action: !0 }),
			pc,
			qc,
			rc = /[?&]amp_js[^&]*/,
			sc = /[?&]amp_gsa[^&]*/,
			tc = /[?&]amp_r[^&]*/,
			uc = /[?&]amp_kit[^&]*/,
			vc = /[?&]usqp[^&]*/,
			wc = [ 'javascript:', 'data:', 'vbscript:' ];
		function N(a, b) {
			pc ||
				((pc = self.document.createElement('a')),
				(qc = self.__AMP_URL_CACHE || (self.__AMP_URL_CACHE = new nc())));
			return xc(pc, a, b ? null : qc);
		}
		function xc(a, b, c) {
			if (c && c.has(b)) return c.get(b);
			a.href = b;
			a.protocol || (a.href = a.href);
			var d = {
				href: a.href,
				protocol: a.protocol,
				host: a.host,
				hostname: a.hostname,
				port: '0' == a.port ? '' : a.port,
				pathname: a.pathname,
				search: a.search,
				hash: a.hash,
				origin: null
			};
			'/' !== d.pathname[0] && (d.pathname = '/' + d.pathname);
			if (('http:' == d.protocol && 80 == d.port) || ('https:' == d.protocol && 443 == d.port))
				(d.port = ''), (d.host = d.hostname);
			d.origin =
				a.origin && 'null' != a.origin
					? a.origin
					: 'data:' != d.protocol && d.host ? d.protocol + '//' + d.host : d.href;
			c && c.put(b, d);
			return d;
		}
		function Ac(a, b, c) {
			if (!b) return a;
			var d = a.split('#', 2),
				e = d[0].split('?', 2),
				g = e[0] + (e[1] ? (c ? '?' + b + '&' + e[1] : '?' + e[1] + '&' + b) : '?' + b);
			return (g += d[1] ? '#' + d[1] : '');
		}
		function Bc(a, b) {
			return Ac(a, Cc(b));
		}
		function Cc(a) {
			var b = [],
				c;
			for (c in a) {
				var d = a[c];
				if (null != d)
					if (z(d))
						for (var e = 0; e < d.length; e++) {
							var g = d[e];
							b.push(encodeURIComponent(c) + '=' + encodeURIComponent(g));
						}
					else b.push(encodeURIComponent(c) + '=' + encodeURIComponent(d));
			}
			return b.join('&');
		}
		function Dc(a) {
			'string' == typeof a && (a = N(a));
			return (
				'https:' == a.protocol ||
				'localhost' == a.hostname ||
				'127.0.0.1' == a.hostname ||
				sb(a.hostname, '.localhost')
			);
		}
		function Ec(a, b, c) {
			c = void 0 === c ? 'source' : c;
			G(null != a, '%s %s must be available', b, c);
			G(
				Dc(a) || /^(\/\/)/.test(a),
				'%s %s must start with "https://" or "//" or be relative and served from either https or from localhost. Invalid value: %s',
				b,
				c,
				a
			);
			return a;
		}
		function Fc(a) {
			var b = a.indexOf('#');
			return -1 == b ? a : a.substring(0, b);
		}
		function O(a) {
			'string' == typeof a && (a = N(a));
			return B.cdnProxyRegex.test(a.origin);
		}
		function Gc(a) {
			if (!a) return !0;
			'string' == typeof a && (a = N(a));
			return !wc.includes(a.protocol);
		}
		function Hc(a) {
			var b = N(a),
				c = Ic(b.search);
			return b.origin + b.pathname + c + b.hash;
		}
		function Ic(a) {
			if (!a || '?' == a) return '';
			var b = a
				.replace(rc, '')
				.replace(sc, '')
				.replace(tc, '')
				.replace(uc, '')
				.replace(vc, '')
				.replace(/^[?&]/, '');
			return b ? '?' + b : '';
		}
		function Jc(a) {
			'string' == typeof a && (a = N(a));
			if (!O(a)) return a.href;
			var b = a.pathname.split('/');
			G(oc[b[1]], 'Unknown path prefix in url %s', a.href);
			var c = b[2],
				d = 's' == c ? 'https://' + decodeURIComponent(b[3]) : 'http://' + decodeURIComponent(c);
			G(0 < d.indexOf('.'), 'Expected a . in origin %s', d);
			b.splice(1, 's' == c ? 3 : 2);
			return d + b.join('/') + Ic(a.search) + (a.hash || '');
		}
		function Kc(a) {
			return N(Jc(a)).origin;
		}
		function Lc(a, b) {
			Mc(b);
			var c = Kc(a.location.href);
			a = encodeURIComponent('__amp_source_origin') + '=' + encodeURIComponent(c);
			return Ac(b, a, void 0);
		}
		function Mc(a) {
			var b = N(a),
				c = t(b.search);
			G(!('__amp_source_origin' in c), 'Source origin is not allowed in %s', a);
		}
		function P(a, b) {
			return !!Nc(a)[b];
		}
		function Oc(a, b, c, d) {
			var e = P(a, b),
				g = !(void 0 !== c ? !c : e);
			if (g != e && ((Nc(a)[b] = g), !d)) {
				var h = Pc(a);
				h[b] = g;
				var l = [],
					k;
				for (k in h) l.push((!1 === h[k] ? '-' : '') + k);
				try {
					'localStorage' in a && a.localStorage.setItem('amp-experiment-toggles', l.join(','));
				} catch (n) {
					C().error('EXPERIMENTS', 'Failed to save experiments to localStorage.');
				}
				C().warn(
					'EXPERIMENTS',
					'"%s" experiment %s for the domain "%s". See: https://amp.dev/documentation/guides-and-tutorials/learn/experimental',
					b,
					g ? 'enabled' : 'disabled',
					a.location.hostname
				);
			}
			return g;
		}
		function Nc(a) {
			if (a.__AMP__EXPERIMENT_TOGGLES) return a.__AMP__EXPERIMENT_TOGGLES;
			a.__AMP__EXPERIMENT_TOGGLES = Object.create(null);
			var b = a.__AMP__EXPERIMENT_TOGGLES;
			if (a.AMP_CONFIG)
				for (var c in a.AMP_CONFIG) {
					var d = a.AMP_CONFIG[c];
					'number' === typeof d && 0 <= d && 1 >= d && (b[c] = Math.random() < d);
				}
			if (
				a.AMP_CONFIG &&
				Array.isArray(a.AMP_CONFIG['allow-doc-opt-in']) &&
				0 < a.AMP_CONFIG['allow-doc-opt-in'].length
			) {
				var e = a.AMP_CONFIG['allow-doc-opt-in'],
					g = a.document.head.querySelector('meta[name="amp-experiments-opt-in"]');
				if (g) {
					var h = g.getAttribute('content').split(',');
					for (c = 0; c < h.length; c++) -1 != e.indexOf(h[c]) && (b[h[c]] = !0);
				}
			}
			Object.assign(b, Pc(a));
			if (
				a.AMP_CONFIG &&
				Array.isArray(a.AMP_CONFIG['allow-url-opt-in']) &&
				0 < a.AMP_CONFIG['allow-url-opt-in'].length
			) {
				c = a.AMP_CONFIG['allow-url-opt-in'];
				a = t(a.location.originalHash || a.location.hash);
				for (var l = 0; l < c.length; l++) {
					var k = a['e-' + c[l]];
					'1' == k && (b[c[l]] = !0);
					'0' == k && (b[c[l]] = !1);
				}
			}
			return b;
		}
		function Pc(a) {
			var b = '';
			try {
				'localStorage' in a && (b = a.localStorage.getItem('amp-experiment-toggles'));
			} catch (e) {
				F().warn('EXPERIMENTS', 'Failed to retrieve experiments from localStorage.');
			}
			var c = b ? b.split(/\s*,\s*/g) : [];
			a = Object.create(null);
			for (var d = 0; d < c.length; d++)
				0 != c[d].length && ('-' == c[d][0] ? (a[c[d].substr(1)] = !1) : (a[c[d]] = !0));
			return a;
		}
		function Qc(a, b) {
			a.__AMP_EXPERIMENT_BRANCHES = a.__AMP_EXPERIMENT_BRANCHES || {};
			for (var c = 0; c < b.length; c++) {
				var d = b[c],
					e = d.experimentId;
				mb.call(a.__AMP_EXPERIMENT_BRANCHES, e) ||
					(d.isTrafficEligible && d.isTrafficEligible(a)
						? !a.__AMP_EXPERIMENT_BRANCHES[e] &&
							P(a, e) &&
							((d = d.branches),
							(a.__AMP_EXPERIMENT_BRANCHES[e] = d[Math.floor(Math.random() * d.length)] || null))
						: (a.__AMP_EXPERIMENT_BRANCHES[e] = null));
			}
		}
		var Rc = [
			{
				experimentId: 'ampdoc-fie',
				isTrafficEligible: function() {
					return !0;
				},
				branches: [ '21066823', '21066824' ]
			}
		];
		function Sc(a) {
			if (!P(a, 'ampdoc-fie')) return !1;
			Qc(a, Rc);
			return '21066824' === (a.__AMP_EXPERIMENT_BRANCHES ? a.__AMP_EXPERIMENT_BRANCHES['ampdoc-fie'] : null);
		}
		function Tc(a, b) {
			var c = a.ownerDocument.defaultView,
				d = Uc(c),
				e = c != d,
				g = Sc(d);
			e && !g ? (b = Vc(c, b) ? Wc(c, b) : null) : ((a = Xc(a)), (a = Yc(a)), (b = Vc(a, b) ? Wc(a, b) : null));
			return b;
		}
		function Zc(a, b, c) {
			var d = Uc(a);
			Vc(a, b);
			if (Sc(d)) {
				var e = Xc(a.document);
				$c(
					Yc(e),
					e,
					b,
					function() {
						return c;
					},
					!0
				);
			} else
				$c(a, a, b, function() {
					return c;
				}),
					Wc(a, b);
		}
		function Q(a, b, c) {
			a = Uc(a);
			$c(a, a, b, c);
		}
		function R(a, b, c, d) {
			var e = Xc(a),
				g = Yc(e);
			$c(g, e, b, c);
			d && Wc(g, b);
		}
		function S(a, b) {
			a = Uc(a);
			return Wc(a, b);
		}
		function ad(a) {
			a = Uc(a);
			return Vc(a, 'performance') ? Wc(a, 'performance') : null;
		}
		function bd(a, b) {
			var c = Xc(a);
			c = Yc(c);
			return Wc(c, b);
		}
		function cd(a, b) {
			return dd(Yc(a), b);
		}
		function Uc(a) {
			return a.__AMP_TOP || (a.__AMP_TOP = a);
		}
		function ed(a, b) {
			var c = (a.ownerDocument || a).defaultView;
			a = b || Uc(c);
			if (c && c != a && Uc(c) == a)
				try {
					return c.frameElement;
				} catch (d) {}
			return null;
		}
		function Xc(a) {
			return a.nodeType ? S((a.ownerDocument || a).defaultView, 'ampdoc').getAmpDoc(a) : a;
		}
		function Yc(a) {
			a = Xc(a);
			return a.isSingleDoc() ? a.win : a;
		}
		function Wc(a, b) {
			Vc(a, b);
			a = fd(a)[b];
			a.obj ||
				((a.obj = new a.ctor(a.context)), (a.ctor = null), (a.context = null), a.resolve && a.resolve(a.obj));
			return a.obj;
		}
		function $c(a, b, c, d, e) {
			var g = fd(a),
				h = g[c];
			h || (h = g[c] = { obj: null, promise: null, resolve: null, reject: null, context: null, ctor: null });
			if (e || (!h.ctor && !h.obj)) (h.ctor = d), (h.context = b), h.resolve && Wc(a, c);
		}
		function gd(a, b) {
			var c = dd(a, b);
			if (c) return c;
			a = fd(a);
			a[b] = hd();
			return a[b].promise;
		}
		function dd(a, b) {
			var c = fd(a)[b];
			if (c) {
				if (c.promise) return c.promise;
				Wc(a, b);
				return (c.promise = Promise.resolve(c.obj));
			}
			return null;
		}
		function fd(a) {
			var b = a.__AMP_SERVICES;
			b || (b = a.__AMP_SERVICES = {});
			return b;
		}
		function id(a, b) {
			var c = Wc(Yc(a.getParent()), b);
			$c(Yc(a), a, b, function() {
				return c;
			});
		}
		function Vc(a, b) {
			a = a.__AMP_SERVICES && a.__AMP_SERVICES[b];
			return !(!a || (!a.ctor && !a.obj));
		}
		function hd() {
			var a = new L(),
				b = a.promise,
				c = a.resolve;
			a = a.reject;
			b.catch(function() {});
			return { obj: null, promise: b, resolve: c, reject: a, context: null, ctor: null };
		}
		function jd(a, b, c) {
			return kd(a, b, c, void 0).then(function(a) {
				return G(
					a,
					'Service %s was requested to be provided through %s, but %s is not loaded in the current page. To fix this problem load the JavaScript file for %s in this page.',
					b,
					c,
					c,
					c
				);
			});
		}
		function kd(a, b, c, d) {
			var e = cd(a, b);
			if (e) return e;
			var g = Xc(a);
			return g
				.waitForBodyOpen()
				.then(function() {
					return ld(g.win, c, g.win.document.head);
				})
				.then(function() {
					if (d) var e = cd(a, b);
					else
						(e = g.win),
							(e = e.__AMP_EXTENDED_ELEMENTS && e.__AMP_EXTENDED_ELEMENTS[c] ? gd(Yc(a), b) : null);
					return e;
				});
		}
		function md(a) {
			var b = Tc(a, 'bind');
			if (b) return Promise.resolve(b);
			b = a.ownerDocument.defaultView;
			var c = Uc(b);
			return b !== c ? nd(b) : kd(a, 'bind', 'amp-bind');
		}
		function od(a) {
			if (!a) return [];
			for (
				var b = {}, c = a.querySelectorAll('script[custom-element],script[custom-template]'), d = 0;
				d < c.length;
				d++
			) {
				var e = c[d];
				e = e.getAttribute('custom-element') || e.getAttribute('custom-template');
				b[e] = !0;
			}
			return Object.keys(b);
		}
		function pd(a) {
			return a.waitForBodyOpen().then(function() {
				var b = a.getHeadNode();
				return od(b).includes('amp-form');
			});
		}
		function ld(a, b, c) {
			return od(c).includes(b) ? S(a, 'extensions').waitForExtension(a, b) : x();
		}
		function nd(a) {
			return xb(a.document)
				.then(function() {
					return ld(a, 'amp-bind', a.document.head);
				})
				.then(function() {
					return a.__AMP_EXTENDED_ELEMENTS && a.__AMP_EXTENDED_ELEMENTS['amp-bind'] ? gd(a, 'bind') : null;
				});
		}
		function qd(a) {
			return S(a, 'ampdoc');
		}
		function rd(a) {
			return bd(a, 'documentInfo').get();
		}
		function sd(a) {
			return S(a, 'extensions');
		}
		function td(a) {
			return bd(a, 'mutator');
		}
		function T(a) {
			return S(a, 'platform');
		}
		function ud(a) {
			return bd(a, 'resources');
		}
		function U(a) {
			return S(a, 'timer');
		}
		function V(a) {
			return bd(a, 'viewer');
		}
		function vd(a) {
			return S(a, 'vsync');
		}
		function wd(a) {
			return bd(a, 'viewport');
		}
		function xd(a, b) {
			this.Lg = a;
			this.Jb = Object.assign({}, { root: null, rootMargin: '0px 0px 0px 0px' }, b);
			if ((a = this.Jb.root) && 1 !== a.nodeType) throw Error('root must be an Element');
			this.J = [];
			this.U = null;
			xd._upgraders.push(this.di.bind(this));
		}
		f = xd.prototype;
		f.disconnect = function() {
			this.U ? this.U.disconnect() : (this.J.length = 0);
		};
		f.takeRecords = function() {
			return this.U ? this.U.takeRecords() : [];
		};
		f.observe = function(a) {
			this.U ? this.U.observe(a) : -1 == this.J.indexOf(a) && this.J.push(a);
		};
		f.unobserve = function(a) {
			this.U ? this.U.unobserve(a) : ((a = this.J.indexOf(a)), -1 != a && this.J.splice(a, 1));
		};
		f.di = function(a) {
			var b = new a(this.Lg, this.Jb);
			this.U = b;
			this.J.forEach(function(a) {
				return b.observe(a);
			});
			this.J = null;
		};
		da.Object.defineProperties(xd.prototype, {
			root: {
				configurable: !0,
				enumerable: !0,
				get: function() {
					return this.U ? this.U.root : this.Jb.root || null;
				}
			},
			rootMargin: {
				configurable: !0,
				enumerable: !0,
				get: function() {
					return this.U ? this.U.rootMargin : this.Jb.rootMargin;
				}
			},
			thresholds: {
				configurable: !0,
				enumerable: !0,
				get: function() {
					return this.U ? this.U.thresholds : [].concat(this.Jb.threshold || 0);
				}
			}
		});
		xd._upgraders = [];
		function yd() {
			var a = zd;
			!a.IntersectionObserverEntry ||
				'isIntersecting' in a.IntersectionObserverEntry.prototype ||
				Object.defineProperty(a.IntersectionObserverEntry.prototype, 'isIntersecting', {
					enumerable: !0,
					configurable: !0,
					get: function() {
						return 0 < this.intersectionRatio;
					}
				});
		}
		function Ad(a) {
			return (a = Number(a)) ? (0 < a ? 1 : -1) : a;
		}
		var Bd = Object.prototype.hasOwnProperty;
		function Cd(a, b) {
			if (null == a) throw new TypeError('Cannot convert undefined or null to object');
			for (var c = Object(a), d = 1; d < arguments.length; d++) {
				var e = arguments[d];
				if (null != e) for (var g in e) Bd.call(e, g) && (c[g] = e[g]);
			}
			return c;
		}
		function Dd(a) {
			return Object.keys(a).map(function(b) {
				return a[b];
			});
		}
		function Ed(a) {
			if (!(this instanceof Ed)) throw new TypeError('Constructor Promise requires `new`');
			if (!Fd(a)) throw new TypeError('Must pass resolver function');
			this._state = Gd;
			this._value = [];
			this._isChainEnd = !0;
			Hd(this, Id(this, Jd), Id(this, Kd), { then: a });
		}
		Ed.prototype.then = function(a, b) {
			a = Fd(a) ? a : void 0;
			b = Fd(b) ? b : void 0;
			if (a || b) this._isChainEnd = !1;
			return this._state(this._value, a, b);
		};
		Ed.prototype.catch = function(a) {
			return this.then(void 0, a);
		};
		function Ld(a) {
			return a === Object(a) && a instanceof this
				? a
				: new this(function(b) {
						b(a);
					});
		}
		function Md(a) {
			return new this(function(b, c) {
				c(a);
			});
		}
		function Nd(a) {
			var b = this;
			return new b(function(c, d) {
				var e = a.length,
					g = Array(e);
				if (0 === e) return c(g);
				Od(a, function(a, l) {
					b.resolve(a).then(function(a) {
						g[l] = a;
						0 === --e && c(g);
					}, d);
				});
			});
		}
		function Pd(a) {
			var b = this;
			return new b(function(c, d) {
				for (var e = 0; e < a.length; e++) b.resolve(a[e]).then(c, d);
			});
		}
		function Jd(a, b, c, d) {
			if (!b) return d && ((b = d.promise), (b._state = Jd), (b._value = a)), this;
			d || (d = new Qd(this.constructor));
			Rd(Sd(d, b, a));
			return d.promise;
		}
		function Kd(a, b, c, d) {
			if (!c) return d && ((b = d.promise), (b._state = Kd), (b._value = a)), this;
			d || (d = new Qd(this.constructor));
			Rd(Sd(d, c, a));
			return d.promise;
		}
		function Gd(a, b, c, d) {
			if (!d) {
				if (!b && !c) return this;
				d = new Qd(this.constructor);
			}
			a.push({ deferred: d, onFulfilled: b || d.resolve, onRejected: c || d.reject });
			return d.promise;
		}
		function Qd(a) {
			var b = this;
			this.promise = new a(function(a, d) {
				b.resolve = a;
				b.reject = d;
			});
			return b;
		}
		function Td(a, b, c, d) {
			var e = a._value;
			a._state = b;
			a._value = c;
			d && b === Gd && d._state(c, void 0, void 0, { promise: a, resolve: void 0, reject: void 0 });
			for (var g = 0; g < e.length; g++) {
				var h = e[g];
				a._state(c, h.onFulfilled, h.onRejected, h.deferred);
			}
			e.length = 0;
			b === Kd &&
				a._isChainEnd &&
				setTimeout(function() {
					if (a._isChainEnd) throw c;
				}, 0);
		}
		function Id(a, b) {
			return function(c) {
				Td(a, b, c);
			};
		}
		function Ud() {}
		function Fd(a) {
			return 'function' === typeof a;
		}
		function Od(a, b) {
			for (var c = 0; c < a.length; c++) b(a[c], c);
		}
		function Sd(a, b, c) {
			var d = a.promise,
				e = a.resolve,
				g = a.reject;
			return function() {
				try {
					var a = b(c);
					Hd(d, e, g, a, a);
				} catch (l) {
					g(l);
				}
			};
		}
		var Rd = (function() {
			function a() {
				for (var a = 0; a < d; a++) {
					var b = c[a];
					c[a] = null;
					b();
				}
				d = 0;
			}
			if ('undefined' !== typeof window && window.postMessage) {
				window.addEventListener('message', a);
				var b = function() {
					window.postMessage('macro-task', '*');
				};
			} else
				b = function() {
					setTimeout(a, 0);
				};
			var c = Array(16),
				d = 0;
			return function(a) {
				0 === d && b();
				c[d++] = a;
			};
		})();
		function Hd(a, b, c, d, e) {
			var g = c,
				h;
			try {
				if (d === a) throw new TypeError('Cannot fulfill promise with itself');
				var l = d === Object(d);
				if (l && d instanceof a.constructor) Td(a, d._state, d._value, d);
				else if (l && (h = d.then) && Fd(h)) {
					var k = function(d) {
						k = g = Ud;
						Hd(a, b, c, d, d);
					};
					g = function(a) {
						k = g = Ud;
						c(a);
					};
					h.call(
						e,
						function(a) {
							k(a);
						},
						function(a) {
							g(a);
						}
					);
				} else b(d);
			} catch (n) {
				g(n);
			}
		}
		(function(a) {
			a.fetch ||
				(Object.defineProperty(a, 'fetch', { value: Zb, writable: !0, enumerable: !0, configurable: !0 }),
				Object.defineProperty(a, 'Response', { value: ec, writable: !0, enumerable: !1, configurable: !0 }));
		})(self);
		(function(a) {
			a.Math.sign ||
				a.Object.defineProperty(a.Math, 'sign', { enumerable: !1, configurable: !0, writable: !0, value: Ad });
		})(self);
		(function(a) {
			a.Object.assign ||
				a.Object.defineProperty(a.Object, 'assign', {
					enumerable: !1,
					configurable: !0,
					writable: !0,
					value: Cd
				});
		})(self);
		(function(a) {
			a.Object.values ||
				a.Object.defineProperty(a.Object, 'values', { configurable: !0, writable: !0, value: Dd });
		})(self);
		(function(a) {
			a.Promise ||
				((a.Promise = Ed),
				Ed.default && (a.Promise = Ed.default),
				(a.Promise.resolve = Ld),
				(a.Promise.reject = Md),
				(a.Promise.all = Nd),
				(a.Promise.race = Pd));
		})(self);
		(function(a) {
			a.Array.prototype.includes ||
				a.Object.defineProperty(a.Array.prototype, 'includes', {
					enumerable: !1,
					configurable: !0,
					writable: !0,
					value: pa
				});
		})(self);
		(function(a) {
			var b = a.Map,
				c = new b();
			if (c.set(0, 0) !== c) {
				var d = c.set;
				a.Object.defineProperty(b.prototype, 'set', {
					enumerable: !1,
					configurable: !0,
					writable: !0,
					value: function() {
						d.apply(this, arguments);
						return this;
					}
				});
			}
		})(self);
		(function(a) {
			var b = a.WeakMap,
				c = new b();
			if (c.set({}, 0) !== c) {
				var d = c.set;
				a.Object.defineProperty(b.prototype, 'set', {
					enumerable: !1,
					configurable: !0,
					writable: !0,
					value: function() {
						d.apply(this, arguments);
						return this;
					}
				});
			}
		})(self);
		(function(a) {
			var b = a.Set,
				c = new b();
			if (c.add(0) !== c) {
				var d = c.add;
				a.Object.defineProperty(b.prototype, 'add', {
					enumerable: !1,
					configurable: !0,
					writable: !0,
					value: function() {
						d.apply(this, arguments);
						return this;
					}
				});
			}
		})(self);
		if (self.document) {
			Ka();
			var Vd = self,
				Wd = Vd.HTMLDocument || Vd.Document;
			Wd &&
				!Wd.prototype.contains &&
				Vd.Object.defineProperty(Wd.prototype, 'contains', {
					enumerable: !1,
					configurable: !0,
					writable: !0,
					value: La
				});
			var mc = self;
			lc() &&
				((jc = Element.prototype.getBoundingClientRect),
				mc.Object.defineProperty(mc.Element.prototype, 'getBoundingClientRect', { value: kc }));
			var Xd = function() {},
				Ga = self,
				$d = Ga.document,
				ae,
				be = Ga.customElements;
			ae = !!(be && be.define && be.get && be.whenDefined);
			var ce;
			if (!(ce = !$d)) {
				var de;
				if ((de = ae)) de = -1 === Ga.HTMLElement.toString().indexOf('[native code]');
				ce = de;
			}
			if (!ce) {
				var ee = !0,
					fe = !1;
				if (Xd && ae)
					try {
						var ge = Ga.Reflect,
							he = Object.create(Xd.prototype);
						Function.call.call(Xd, he);
						fe = !(!ge || !ge.construct);
					} catch (a) {
						ee = !1;
					}
				fe ? Ia() : ee && Ea();
			}
			var zd = self;
			zd.IntersectionObserver || (zd.IntersectionObserver = xd);
			yd();
		}
		var ie;
		function je(a) {
			a = a.ownerDocument || a;
			(ie && ie.ownerDocument === a) || (ie = a.createElement('div'));
			return ke;
		}
		function ke(a) {
			var b = ie;
			b.innerHTML = a[0];
			a = b.firstElementChild;
			b.removeChild(a);
			return a;
		}
		var le,
			me = 'Webkit webkit Moz moz ms O o'.split(' ');
		function ne(a, b, c) {
			if (M(b, '--')) return b;
			le || (le = I());
			var d = le[b];
			if (!d || c) {
				d = b;
				if (void 0 === a[b]) {
					var e = b.charAt(0).toUpperCase() + b.slice(1);
					a: {
						for (var g = 0; g < me.length; g++) {
							var h = me[g] + e;
							if (void 0 !== a[h]) {
								e = h;
								break a;
							}
						}
						e = '';
					}
					var l = e;
					void 0 !== a[l] && (d = l);
				}
				c || (le[b] = d);
			}
			return d;
		}
		function oe(a, b) {
			a = a.style;
			for (var c in b) a.setProperty(ne(a, c), b[c].toString(), 'important');
		}
		function X(a, b, c, d) {
			if ((b = ne(a.style, b, void 0))) {
				var e = d ? c + d : c;
				M(b, '--') ? a.style.setProperty(b, e) : (a.style[b] = e);
			}
		}
		function pe(a, b) {
			if ((b = ne(a.style, b, void 0))) return M(b, '--') ? a.style.getPropertyValue(b) : a.style[b];
		}
		function qe(a, b) {
			for (var c in b) X(a, c, b[c]);
		}
		function re(a, b) {
			void 0 === b && (b = a.hasAttribute('hidden'));
			b ? a.removeAttribute('hidden') : a.setAttribute('hidden', '');
		}
		function se(a, b) {
			return a.getComputedStyle(b) || I();
		}
		function te(a) {
			if (!a.hasAttribute('src') && 0 == 'srcset' in a) {
				var b = a.getAttribute('srcset'),
					c = /\S+/.exec(b);
				null != c && a.setAttribute('src', c[0]);
			}
		}
		function ue(a, b, c) {
			var d = a.createElement('canvas');
			d.width = b;
			d.height = c;
			return d.toDataURL();
		}
		var ve = [
				'<i-amphtml-sizer class=i-amphtml-sizer slot=i-amphtml-svc><img alt="" role=presentation aria-hidden=true class=i-amphtml-intrinsic-sizer></i-amphtml-sizer>'
			],
			we = {
				NODISPLAY: 'nodisplay',
				FIXED: 'fixed',
				FIXED_HEIGHT: 'fixed-height',
				RESPONSIVE: 'responsive',
				CONTAINER: 'container',
				FILL: 'fill',
				FLEX_ITEM: 'flex-item',
				FLUID: 'fluid',
				INTRINSIC: 'intrinsic'
			},
			xe = {
				'AMP-PIXEL': { width: '0px', height: '0px' },
				'AMP-ANALYTICS': { width: '1px', height: '1px' },
				'AMP-AUDIO': null,
				'AMP-SOCIAL-SHARE': { width: '60px', height: '44px' }
			},
			ye = {
				'AMP-AD': !0,
				'AMP-ANIM': !0,
				'AMP-EMBED': !0,
				'AMP-FACEBOOK': !0,
				'AMP-FACEBOOK-COMMENTS': !0,
				'AMP-FACEBOOK-PAGE': !0,
				'AMP-GOOGLE-DOCUMENT-EMBED': !0,
				'AMP-IFRAME': !0,
				'AMP-IMG': !0,
				'AMP-INSTAGRAM': !0,
				'AMP-LIST': !0,
				'AMP-PINTEREST': !0,
				'AMP-PLAYBUZZ': !0,
				'AMP-TWITTER': !0
			},
			ze = /^amp\-(video|.+player)|AMP-BRIGHTCOVE|AMP-DAILYMOTION|AMP-YOUTUBE|AMP-VIMEO|AMP-IMA-VIDEO/i;
		function Ae(a) {
			for (var b in we) if (we[b] == a) return we[b];
		}
		function Be(a) {
			return (
				'fixed' == a ||
				'fixed-height' == a ||
				'responsive' == a ||
				'fill' == a ||
				'flex-item' == a ||
				'fluid' == a ||
				'intrinsic' == a
			);
		}
		function Ce(a) {
			if ('number' == typeof a) return a + 'px';
			if (a && /^\d+(\.\d+)?(px|em|rem|vh|vw|vmin|vmax|cm|mm|q|in|pc|pt)?$/.test(a))
				return /^\d+(\.\d+)?$/.test(a) ? a + 'px' : a;
		}
		function De(a) {
			G(/^\d+(\.\d+)?(px|em|rem|vh|vw|vmin|vmax|cm|mm|q|in|pc|pt)$/.test(a), 'Invalid length value: %s', a);
			return a;
		}
		function Ee(a) {
			G(/^\d+(\.\d+)?(px|em|rem|vh|vw|vmin|vmax|%)$/.test(a), 'Invalid length or percent value: %s', a);
			return a;
		}
		function Fe(a) {
			De(a);
			return G(/[a-z]+/i.exec(a), 'Failed to read units from %s', a)[0];
		}
		function Ge(a) {
			a = parseFloat(a);
			return Pa(a) ? a : void 0;
		}
		var He;
		function Ie(a, b, c, d) {
			var e = a,
				g = c;
			var h = function(a) {
				try {
					return g(a);
				} catch (r) {
					throw (self.__AMP_REPORT_ERROR(r), r);
				}
			};
			var l = Je(),
				k = !1;
			d && (k = d.capture);
			e.addEventListener(b, h, l ? d : k);
			return function() {
				e && e.removeEventListener(b, h, l ? d : k);
				h = e = g = null;
			};
		}
		function Je() {
			if (void 0 !== He) return He;
			He = !1;
			try {
				var a = {
					get capture() {
						He = !0;
					}
				};
				self.addEventListener('test-options', null, a);
				self.removeEventListener('test-options', null, a);
			} catch (b) {}
			return He;
		}
		function Ke(a, b) {
			var c = { detail: b };
			Object.assign(c, void 0);
			if ('function' == typeof a.CustomEvent) return new a.CustomEvent('perf', c);
			a = a.document.createEvent('CustomEvent');
			a.initCustomEvent('perf', !!c.bubbles, !!c.cancelable, b);
			return a;
		}
		function Le(a, b, c, d) {
			return Ie(a, b, c, d);
		}
		function Me(a, b, c, d) {
			var e = c,
				g = Ie(
					a,
					b,
					function(a) {
						try {
							e(a);
						} finally {
							(e = null), g();
						}
					},
					d
				);
			return g;
		}
		function Ne(a, b) {
			var c,
				d = new Promise(function(b) {
					c = Me(a, 'click', b, void 0);
				});
			d.then(c, c);
			b && b(c);
			return d;
		}
		function Oe(a) {
			return !!(
				a.complete ||
				'complete' == a.readyState ||
				(Pe(a) && 0 < a.readyState) ||
				(a.document && 'complete' == a.document.readyState)
			);
		}
		function Qe(a) {
			var b, c;
			if (Oe(a)) return Promise.resolve(a);
			var d = Pe(a);
			return d && a.__AMP_MEDIA_LOAD_FAILURE_SRC === a.currentSrc
				? Promise.reject(a)
				: new Promise(function(e, g) {
						b = d ? Me(a, 'loadedmetadata', e, { capture: !0 }) : Me(a, 'load', e);
						if (a.tagName) {
							var h = a;
							if (
								d &&
								!a.hasAttribute('src') &&
								((h = Ib(a, function(a) {
									return 'SOURCE' === a.tagName;
								})),
								!h)
							)
								return g(Error('Media has no source.'));
							c = Me(h, 'error', g);
						}
					}).then(
						function() {
							c && c();
							return a;
						},
						function() {
							b && b();
							Pe(a) && (a.__AMP_MEDIA_LOAD_FAILURE_SRC = a.currentSrc || !0);
							var c = a;
							c && c.src && (c = c.src);
							throw C().createError('Failed to load:', c);
						}
					);
		}
		function Pe(a) {
			return 'AUDIO' === a.tagName || 'VIDEO' === a.tagName;
		}
		function Re(a) {
			this.element = a;
			this.layout_ = 'nodisplay';
			this.inViewport_ = !1;
			this.win = a.ownerDocument.defaultView;
			this.defaultActionAlias_ = this.actionMap_ = null;
		}
		f = Re.prototype;
		f.signals = function() {
			return this.element.signals();
		};
		f.getDefaultActionAlias = function() {
			return this.defaultActionAlias_;
		};
		f.getLayoutPriority = function() {
			return 0;
		};
		f.updateLayoutPriority = function(a) {
			this.element.getResources().updateLayoutPriority(this.element, a);
		};
		f.getLayout = function() {
			return this.layout_;
		};
		f.getLayoutBox = function() {
			return this.element.getLayoutBox();
		};
		f.getPageLayoutBox = function() {
			return this.element.getPageLayoutBox();
		};
		f.getWin = function() {
			return this.win;
		};
		f.getAmpDoc = function() {
			return this.element.getAmpDoc();
		};
		f.getVsync = function() {
			return vd(this.win);
		};
		f.getConsentPolicy = function() {
			var a = null;
			this.element.hasAttribute('data-block-on-consent') &&
				(a = this.element.getAttribute('data-block-on-consent') || 'default');
			return a;
		};
		f.isLayoutSupported = function(a) {
			return 'nodisplay' == a;
		};
		f.isAlwaysFixed = function() {
			return !1;
		};
		f.isInViewport = function() {
			return this.inViewport_;
		};
		f.upgradeCallback = function() {
			return null;
		};
		f.createdCallback = function() {};
		f.firstAttachedCallback = function() {};
		f.buildCallback = function() {};
		f.preconnectCallback = function() {};
		f.detachedCallback = function() {};
		f.prerenderAllowed = function() {
			return !1;
		};
		f.isBuildRenderBlocking = function() {
			return !1;
		};
		f.createPlaceholderCallback = function() {
			return null;
		};
		f.createLoaderLogoCallback = function() {
			return {};
		};
		f.renderOutsideViewport = function() {
			return 'inabox' == v(this.win).runtime || 3;
		};
		f.idleRenderOutsideViewport = function() {
			return !1;
		};
		f.isRelayoutNeeded = function() {
			return !1;
		};
		f.layoutCallback = function() {
			return x();
		};
		f.firstLayoutCompleted = function() {
			this.togglePlaceholder(!1);
		};
		f.viewportCallback = function() {};
		f.pauseCallback = function() {};
		f.resumeCallback = function() {};
		f.unlayoutCallback = function() {
			return !1;
		};
		f.unlayoutOnPause = function() {
			return !1;
		};
		f.reconstructWhenReparented = function() {
			return !0;
		};
		f.loadPromise = function(a) {
			return Qe(a);
		};
		function Se(a) {
			a.actionMap_ || (a.actionMap_ = a.win.Object.create(null));
		}
		f.registerAction = function(a, b, c) {
			c = void 0 === c ? 2 : c;
			Se(this);
			this.actionMap_[a] = { handler: b, minTrust: c };
		};
		f.registerDefaultAction = function(a, b, c) {
			b = void 0 === b ? 'activate' : b;
			this.registerAction(b, a, void 0 === c ? 2 : c);
			this.defaultActionAlias_ = b;
		};
		f.executeAction = function(a) {
			var b = a.method;
			'activate' === b && (b = this.defaultActionAlias_ || b);
			Se(this);
			var c = this.actionMap_[b];
			G(c, 'Method not found: ' + b + ' in ' + this.element.tagName);
			b = c.handler;
			if (a.satisfiesTrust(c.minTrust)) return b(a);
		};
		f.propagateAttributes = function(a, b, c) {
			a = z(a) ? a : [ a ];
			for (var d = 0; d < a.length; d++) {
				var e = a[d],
					g = this.element.getAttribute(e);
				null !== g ? b.setAttribute(e, g) : c && b.removeAttribute(e);
			}
		};
		f.propagateDataset = function(a) {
			for (var b in a.dataset) b in this.element.dataset || delete a.dataset[b];
			for (var c in this.element.dataset)
				a.dataset[c] !== this.element.dataset[c] && (a.dataset[c] = this.element.dataset[c]);
		};
		f.forwardEvents = function(a, b) {
			var c = this,
				d = (z(a) ? a : [ a ]).map(function(a) {
					return Le(b, a, function(b) {
						c.element.dispatchCustomEvent(a, b.data || {});
					});
				});
			return function() {
				return d.forEach(function(a) {
					return a();
				});
			};
		};
		f.getPlaceholder = function() {
			return this.element.getPlaceholder();
		};
		f.togglePlaceholder = function(a) {
			this.element.togglePlaceholder(a);
		};
		f.getFallback = function() {
			return this.element.getFallback();
		};
		f.toggleFallback = function(a) {
			this.element.toggleFallback(a);
		};
		f.toggleLoading = function(a) {
			this.element.toggleLoading(a);
		};
		f.isLoadingReused = function() {
			return !1;
		};
		f.getOverflowElement = function() {
			return this.element.getOverflowElement();
		};
		f.renderStarted = function() {
			this.element.renderStarted();
		};
		f.getRealChildNodes = function() {
			return this.element.getRealChildNodes();
		};
		f.getRealChildren = function() {
			return this.element.getRealChildren();
		};
		f.applyFillContent = function(a, b) {
			a.classList.add('i-amphtml-fill-content');
			b && a.classList.add('i-amphtml-replaced-content');
		};
		f.getViewport = function() {
			return wd(this.getAmpDoc());
		};
		f.getIntersectionElementLayoutBox = function() {
			return this.getLayoutBox();
		};
		f.collapse = function() {
			td(this.getAmpDoc()).collapseElement(this.element);
		};
		f.attemptCollapse = function() {
			return td(this.getAmpDoc()).attemptCollapse(this.element);
		};
		f.forceChangeHeight = function(a) {
			td(this.getAmpDoc()).forceChangeSize(this.element, a, void 0);
		};
		f.attemptChangeHeight = function(a) {
			return td(this.getAmpDoc()).requestChangeSize(this.element, a, void 0);
		};
		f.attemptChangeSize = function(a, b, c) {
			return td(this.getAmpDoc()).requestChangeSize(this.element, a, b, void 0, c);
		};
		f.measureElement = function(a) {
			return td(this.getAmpDoc()).measureElement(a);
		};
		f.mutateElement = function(a, b) {
			return this.measureMutateElement(null, a, b);
		};
		f.measureMutateElement = function(a, b, c) {
			return td(this.getAmpDoc()).measureMutateElement(c || this.element, a, b);
		};
		f.mutateElementSkipRemeasure = function(a) {
			return td(this.getAmpDoc()).mutateElement(this.element, a, !0);
		};
		f.collapsedCallback = function() {};
		f.expand = function() {
			td(this.getAmpDoc()).expandElement(this.element);
		};
		f.expandedCallback = function() {};
		f.mutatedAttributesCallback = function() {};
		f.onLayoutMeasure = function() {};
		f.onMeasureChanged = function() {};
		f.user = function() {
			return C(this.element);
		};
		function Te(a, b) {
			this.element = a;
			this.win = a.ownerDocument.defaultView || b;
			this.h = V(this.element);
			this.compileCallback();
		}
		f = Te.prototype;
		f.compileCallback = function() {};
		f.setHtml = function() {
			throw Error('Not implemented');
		};
		f.render = function() {
			throw Error('Not implemented');
		};
		f.unwrap = function(a) {
			for (var b = null, c = a.firstChild; null != c; c = c.nextSibling)
				if (3 == c.nodeType) {
					if (c.textContent.trim()) {
						b = null;
						break;
					}
				} else if (8 != c.nodeType)
					if (1 == c.nodeType)
						if (b) {
							b = null;
							break;
						} else b = c;
					else b = null;
			return b || a;
		};
		f.viewerCanRenderTemplates = function() {
			return this.h.hasCapability('viewerRenderTemplate');
		};
		function Ue(a) {
			this.w = a;
			this.Wb = {};
			this.Be = {};
		}
		f = Ue.prototype;
		f.setHtmlForTemplate = function(a, b) {
			return Ve(this, a).then(function(a) {
				return a.setHtml(b);
			});
		};
		f.renderTemplate = function(a, b) {
			return Ve(this, a).then(function(a) {
				return a.render(b);
			});
		};
		f.renderTemplateArray = function(a, b) {
			return 0 == b.length
				? Promise.resolve([])
				: Ve(this, a).then(function(a) {
						return b.map(function(b) {
							return a.render(b);
						});
					});
		};
		f.findAndRenderTemplate = function(a, b, c) {
			return this.renderTemplate(this.findTemplate(a, c), b);
		};
		f.findAndSetHtmlForTemplate = function(a, b, c) {
			return this.setHtmlForTemplate(this.findTemplate(a, c), b);
		};
		f.findAndRenderTemplateArray = function(a, b, c) {
			return this.renderTemplateArray(this.findTemplate(a, c), b);
		};
		f.hasTemplate = function(a, b) {
			return !!this.maybeFindTemplate(a, b);
		};
		f.findTemplate = function(a, b) {
			b = this.maybeFindTemplate(a, b);
			G(b, 'Template not found for %s', a);
			var c = b.tagName;
			G(
				'TEMPLATE' == c || ('SCRIPT' == c && 'text/plain' === b.getAttribute('type')),
				'Template must be defined in a <template> or <script type="text/plain"> tag'
			);
			return b;
		};
		f.maybeFindTemplate = function(a, b) {
			var c = a.getAttribute('template');
			return c ? Bb(a).getElementById(c) : b ? Lb(a, b) : a.querySelector('template, script[type="text/plain"]');
		};
		function Ve(a, b) {
			var c = b.__AMP_IMPL_;
			if (c) return Promise.resolve(c);
			c = '';
			var d = b.tagName;
			'TEMPLATE' == d ? (c = b.getAttribute('type')) : 'SCRIPT' == d && (c = b.getAttribute('template'));
			G(c, 'Type must be specified: %s', b);
			if ((d = b.__AMP_WAIT_)) return d;
			d = We(a, c).then(function(c) {
				var d = (b.__AMP_IMPL_ = new c(b, a.w));
				delete b.__AMP_WAIT_;
				return d;
			});
			return (b.__AMP_WAIT_ = d);
		}
		function We(a, b) {
			if (a.Wb[b]) return a.Wb[b];
			var c = new L(),
				d = c.promise;
			c = c.resolve;
			a.Wb[b] = d;
			a.Be[b] = c;
			return d;
		}
		var Xe = {
			PRERENDER: 'prerender',
			VISIBLE: 'visible',
			HIDDEN: 'hidden',
			PAUSED: 'paused',
			INACTIVE: 'inactive'
		}; /*

 Copyright (c) 2014 The Polymer Project Authors. All rights reserved.
 Use of this source code is governed by a BSD-style
 license that can be found in the LICENSE file or at
 https://developers.google.com/open-source/licenses/bsd */
		var Ye;
		function Ze() {
			if (void 0 === Ye) {
				var a = Element;
				Ye = a.prototype.attachShadow ? 'v1' : a.prototype.createShadowRoot ? 'v0' : 'none';
			}
			return Ye;
		}
		var $e = {
			'amp-dynamic-css-classes': '[custom-element=amp-dynamic-css-classes]',
			variant: 'amp-experiment',
			'amp-story-render': 'amp-story[standalone]'
		};
		function af(a) {
			var b = bf(a).map(function(b) {
				var c = gd(a, b).then(function(a) {
					return a && 'function' == typeof a.whenReady
						? a.whenReady().then(function() {
								return a;
							})
						: a;
				});
				return U(a).timeoutPromise(3e3, c, 'Render timeout waiting for service ' + b + ' to be ready.');
			});
			return Promise.all(b);
		}
		function bf(a) {
			var b = a.document;
			return Object.keys($e).filter(function(a) {
				return b.querySelector($e[a]);
			});
		}
		function cf(a, b, c, d, e) {
			var g = a.getHeadNode(),
				h = df(g, ef(g, b), d || !1, e || null);
			if (c) {
				var l = a.getRootNode();
				if (ff(l, h)) c(h);
				else
					var k = setInterval(function() {
						ff(l, h) && (clearInterval(k), c(h));
					}, 4);
			}
		}
		function df(a, b, c, d) {
			var e = a.__AMP_CSS_SM;
			e || (e = a.__AMP_CSS_SM = I());
			var g = !c && d && 'amp-custom' != d && 'amp-keyframes' != d,
				h = c ? 'amp-runtime' : g ? 'amp-extension=' + d : null;
			if (h) {
				var l = gf(a, e, h);
				if (l) return l.textContent !== b && (l.textContent = b), l;
			}
			var k = (a.ownerDocument || a).createElement('style');
			k.textContent = b;
			var n = null;
			c
				? k.setAttribute('amp-runtime', '')
				: g
					? (k.setAttribute('amp-extension', d || ''), (n = gf(a, e, 'amp-runtime')))
					: (d && k.setAttribute(d, ''), (n = a.lastChild));
			b = n;
			(b = void 0 === b ? null : b) ? a.insertBefore(k, b.nextSibling) : a.insertBefore(k, a.firstChild);
			h && (e[h] = k);
			return k;
		}
		function gf(a, b, c) {
			return b[c] ? b[c] : (a = a.querySelector('style[' + c + ']')) ? (b[c] = a) : null;
		}
		function ef(a, b) {
			return (a = a.__AMP_CSS_TR) ? a(b) : b;
		}
		var hf = !1;
		function jf() {
			var a = self.document,
				b = a.defaultView;
			xb(a)
				.then(function() {
					return af(b);
				})
				.catch(function(a) {
					hb(a);
					return [];
				})
				.then(function(c) {
					hf = !0;
					kf(a);
					Xc(a).signals().signal('render-start');
					0 < c.length && ud(a.documentElement).schedulePass(1, !0);
					try {
						var d = S(b, 'performance');
						d.tick('mbv');
						d.flush();
					} catch (e) {}
				});
		}
		function lf(a) {
			hf || ((hf = !0), kf(a));
		}
		function kf(a) {
			qe(a.body, { opacity: 1, visibility: 'visible', animation: 'none' });
		}
		function ff(a, b) {
			var c = a.styleSheets;
			for (a = 0; a < c.length; a++) if (c[a].ownerNode == b) return !0;
			return !1;
		}
		var mf = { composed: !1 };
		function nf(a) {
			return 'none' != Ze() && Node.prototype.getRootNode
				? a.getRootNode(mf)
				: Eb(a, function(a) {
						return Cb(a);
					});
		}
		function of(a) {
			var b = a.match(/^(.*)\/(.*)-([0-9.]+|latest)(\.max)?\.(?:js|mjs)$/i);
			return { extensionId: b ? b[2] : void 0, extensionVersion: b ? b[3] : void 0 };
		}
		var pf =
			'html{overflow-x:hidden!important}html.i-amphtml-fie{height:100%!important;width:100%!important}html:not([amp4ads]),html:not([amp4ads]) body{height:auto!important}html:not([amp4ads]) body{margin:0!important}body{-webkit-text-size-adjust:100%;-moz-text-size-adjust:100%;-ms-text-size-adjust:100%;text-size-adjust:100%}html.i-amphtml-singledoc.i-amphtml-embedded{-ms-touch-action:pan-y;touch-action:pan-y}html.i-amphtml-fie>body,html.i-amphtml-singledoc>body{overflow:visible!important}html.i-amphtml-fie:not(.i-amphtml-inabox)>body,html.i-amphtml-singledoc:not(.i-amphtml-inabox)>body{position:relative!important}html.i-amphtml-webview>body{overflow-x:hidden!important;overflow-y:visible!important;min-height:100vh!important}html.i-amphtml-ios-embed-legacy>body{overflow-x:hidden!important;overflow-y:auto!important;position:absolute!important}html.i-amphtml-ios-embed{overflow-y:auto!important;position:static}#i-amphtml-wrapper{overflow-x:hidden!important;overflow-y:auto!important;position:absolute!important;top:0!important;left:0!important;right:0!important;bottom:0!important;margin:0!important;display:block!important}html.i-amphtml-ios-embed.i-amphtml-ios-overscroll,html.i-amphtml-ios-embed.i-amphtml-ios-overscroll>#i-amphtml-wrapper{-webkit-overflow-scrolling:touch!important}#i-amphtml-wrapper>body{position:relative!important;border-top:1px solid transparent!important}#i-amphtml-wrapper+body{visibility:visible}#i-amphtml-wrapper+body .i-amphtml-lightbox-element,#i-amphtml-wrapper+body[i-amphtml-lightbox]{visibility:hidden}#i-amphtml-wrapper+body[i-amphtml-lightbox] .i-amphtml-lightbox-element{visibility:visible}#i-amphtml-wrapper.i-amphtml-scroll-disabled,.i-amphtml-scroll-disabled{overflow-x:hidden!important;overflow-y:hidden!important}amp-instagram{padding:54px 0px 0px!important;background-color:#fff}amp-iframe iframe{box-sizing:border-box!important}[amp-access][amp-access-hide]{display:none}[subscriptions-dialog],body:not(.i-amphtml-subs-ready) [subscriptions-action],body:not(.i-amphtml-subs-ready) [subscriptions-section]{display:none!important}amp-experiment,amp-live-list>[update]{display:none}.i-amphtml-jank-meter{position:fixed;background-color:rgba(232,72,95,0.5);bottom:0;right:0;color:#fff;font-size:16px;z-index:1000;padding:5px}amp-list[resizable-children]>.i-amphtml-loading-container.amp-hidden{display:none!important}amp-list [fetch-error],amp-list[load-more] [load-more-button],amp-list[load-more] [load-more-end],amp-list[load-more] [load-more-failed],amp-list[load-more] [load-more-loading]{display:none}amp-list[diffable] div[role=list]{display:block}amp-story-page,amp-story[standalone]{min-height:1px!important;display:block!important;height:100%!important;margin:0!important;padding:0!important;overflow:hidden!important;width:100%!important}amp-story[standalone]{background-color:#202125!important;position:relative!important}amp-story-page{background-color:#757575}amp-story .amp-active>div,amp-story .i-amphtml-loader-background{display:none!important}amp-story-page:not(:first-of-type):not([distance]):not([active]){transform:translateY(1000vh)!important}amp-autocomplete{position:relative!important;display:inline-block!important}amp-autocomplete>input,amp-autocomplete>textarea{padding:0.5rem;border:1px solid rgba(0,0,0,0.33)}.i-amphtml-autocomplete-results,amp-autocomplete>input,amp-autocomplete>textarea{font-size:1rem;line-height:1.5rem}[amp-fx^=fly-in]{visibility:hidden}\n/*# sourceURL=/css/ampdoc.css*/';
		var qf =
			'[hidden]{display:none!important}.i-amphtml-element{display:inline-block}.i-amphtml-blurry-placeholder{transition:opacity 0.3s cubic-bezier(0.0,0.0,0.2,1)!important;pointer-events:none}[layout=nodisplay]:not(.i-amphtml-element){display:none!important}.i-amphtml-layout-fixed,[layout=fixed][width][height]:not(.i-amphtml-layout-fixed){display:inline-block;position:relative}.i-amphtml-layout-responsive,[layout=responsive][width][height]:not(.i-amphtml-layout-responsive),[width][height][heights]:not([layout]):not(.i-amphtml-layout-responsive),[width][height][sizes]:not([layout]):not(.i-amphtml-layout-responsive){display:block;position:relative}.i-amphtml-layout-intrinsic,[layout=intrinsic][width][height]:not(.i-amphtml-layout-intrinsic){display:inline-block;position:relative;max-width:100%}.i-amphtml-layout-intrinsic .i-amphtml-sizer{max-width:100%}.i-amphtml-intrinsic-sizer{max-width:100%;display:block!important}.i-amphtml-layout-container,.i-amphtml-layout-fixed-height,[layout=container],[layout=fixed-height][height]:not(.i-amphtml-layout-fixed-height){display:block;position:relative}.i-amphtml-layout-fill,[layout=fill]:not(.i-amphtml-layout-fill){display:block;overflow:hidden!important;position:absolute;top:0;left:0;bottom:0;right:0}.i-amphtml-layout-flex-item,[layout=flex-item]:not(.i-amphtml-layout-flex-item){display:block;position:relative;-ms-flex:1 1 auto;flex:1 1 auto}.i-amphtml-layout-fluid{position:relative}.i-amphtml-layout-size-defined{overflow:hidden!important}.i-amphtml-layout-awaiting-size{position:absolute!important;top:auto!important;bottom:auto!important}i-amphtml-sizer{display:block!important}.i-amphtml-blurry-placeholder,.i-amphtml-fill-content{display:block;height:0;max-height:100%;max-width:100%;min-height:100%;min-width:100%;width:0;margin:auto}.i-amphtml-layout-size-defined .i-amphtml-fill-content{position:absolute;top:0;left:0;bottom:0;right:0}.i-amphtml-replaced-content,.i-amphtml-screen-reader{padding:0!important;border:none!important}.i-amphtml-screen-reader{position:fixed!important;top:0px!important;left:0px!important;width:4px!important;height:4px!important;opacity:0!important;overflow:hidden!important;margin:0!important;display:block!important;visibility:visible!important}.i-amphtml-screen-reader~.i-amphtml-screen-reader{left:8px!important}.i-amphtml-screen-reader~.i-amphtml-screen-reader~.i-amphtml-screen-reader{left:12px!important}.i-amphtml-screen-reader~.i-amphtml-screen-reader~.i-amphtml-screen-reader~.i-amphtml-screen-reader{left:16px!important}.i-amphtml-unresolved{position:relative;overflow:hidden!important}.i-amphtml-select-disabled{-webkit-user-select:none!important;-moz-user-select:none!important;-ms-user-select:none!important;user-select:none!important}.i-amphtml-notbuilt,[layout]:not(.i-amphtml-element),[width][height][heights]:not([layout]):not(.i-amphtml-element),[width][height][sizes]:not([layout]):not(.i-amphtml-element){position:relative;overflow:hidden!important;color:transparent!important}.i-amphtml-notbuilt:not(.i-amphtml-layout-container)>*,[layout]:not([layout=container]):not(.i-amphtml-element)>*,[width][height][heights]:not([layout]):not(.i-amphtml-element)>*,[width][height][sizes]:not([layout]):not(.i-amphtml-element)>*{display:none}.i-amphtml-notbuilt:not(.i-amphtml-layout-container),[layout]:not([layout=container]):not(.i-amphtml-element),[width][height][heights]:not([layout]):not(.i-amphtml-element),[width][height][sizes]:not([layout]):not(.i-amphtml-element){color:transparent!important;line-height:0!important}.i-amphtml-ghost{visibility:hidden!important}.i-amphtml-element>[placeholder],[layout]:not(.i-amphtml-element)>[placeholder],[width][height][heights]:not([layout]):not(.i-amphtml-element)>[placeholder],[width][height][sizes]:not([layout]):not(.i-amphtml-element)>[placeholder]{display:block}.i-amphtml-element>[placeholder].amp-hidden,.i-amphtml-element>[placeholder].hidden{visibility:hidden}.i-amphtml-element:not(.amp-notsupported)>[fallback],.i-amphtml-layout-container>[placeholder].amp-hidden,.i-amphtml-layout-container>[placeholder].hidden{display:none}.i-amphtml-layout-size-defined>[fallback],.i-amphtml-layout-size-defined>[placeholder]{position:absolute!important;top:0!important;left:0!important;right:0!important;bottom:0!important;z-index:1}.i-amphtml-notbuilt>[placeholder]{display:block!important}.i-amphtml-hidden-by-media-query{display:none!important}.i-amphtml-element-error{background:red!important;color:#fff!important;position:relative!important}.i-amphtml-element-error:before{content:attr(error-message)}i-amp-scroll-container,i-amphtml-scroll-container{position:absolute;top:0;left:0;right:0;bottom:0;display:block}i-amp-scroll-container.amp-active,i-amphtml-scroll-container.amp-active{overflow:auto;-webkit-overflow-scrolling:touch}.i-amphtml-loading-container{display:block!important;pointer-events:none;z-index:1}.i-amphtml-notbuilt>.i-amphtml-loading-container{display:block!important}.i-amphtml-loading-container.amp-hidden{visibility:hidden}.i-amphtml-element>[overflow]{cursor:pointer;position:relative;z-index:2;visibility:hidden;display:initial;line-height:normal}.i-amphtml-element>[overflow].amp-visible{visibility:visible}template{display:none!important}.amp-border-box,.amp-border-box *,.amp-border-box :after,.amp-border-box :before{box-sizing:border-box}amp-pixel{display:none!important}amp-analytics,amp-auto-ads,amp-story-auto-ads{position:fixed!important;top:0!important;width:1px!important;height:1px!important;overflow:hidden!important;visibility:hidden}html.i-amphtml-fie>amp-analytics{position:initial!important}[visible-when-invalid]:not(.visible),form [submit-error],form [submit-success],form [submitting]{display:none}amp-accordion{display:block!important}amp-accordion>section{float:none!important}amp-accordion>section>*{float:none!important;display:block!important;overflow:hidden!important;position:relative!important}amp-accordion,amp-accordion>section{margin:0}amp-accordion>section>:last-child{display:none!important}amp-accordion>section[expanded]>:last-child{display:block!important}\n/*# sourceURL=/css/ampshared.css*/';
		function rf(a, b, c) {
			function d(d) {
				h = null;
				g = a.setTimeout(e, c);
				b.apply(null, d);
			}
			function e() {
				g = 0;
				h && d(h);
			}
			var g = 0,
				h = null;
			return function(a) {
				for (var b = [], c = 0; c < arguments.length; ++c) b[c - 0] = arguments[c];
				g ? (h = b) : d(b);
			};
		}
		function sf(a, b) {
			function c() {
				d = 0;
				var h = 300 - (a.Date.now() - e);
				if (0 < h) d = a.setTimeout(c, h);
				else {
					var l = g;
					g = null;
					b.apply(null, l);
				}
			}
			var d = 0,
				e = 0,
				g = null;
			return function(b) {
				for (var h = [], k = 0; k < arguments.length; ++k) h[k - 0] = arguments[k];
				e = a.Date.now();
				g = h;
				d || (d = a.setTimeout(c, 300));
			};
		}
		function tf(a, b) {
			var c = b.documentElement;
			return a.some(function(a) {
				return c.hasAttribute(a);
			});
		}
		function uf() {
			var a = vf();
			return function(b) {
				return setTimeout(b, a());
			};
		}
		function vf() {
			var a = 0;
			return function() {
				var b = Math.pow(1.5, a++);
				var c = b * (c || 0.3) * Math.random();
				0.5 < Math.random() && (c *= -1);
				b += c;
				return 1e3 * b;
			};
		}
		function wf(a, b) {
			var c = !1;
			b = void 0 === b ? {} : b;
			c = void 0 === c ? !0 : c;
			kd(a, 'amp-analytics-instrumentation', 'amp-analytics').then(function(d) {
				d && d.triggerEventForTarget(a, 'user-error', b, c);
			});
		}
		var xf = self.__AMP_ERRORS || [];
		self.__AMP_ERRORS = xf;
		function yf(a) {
			yf = uf();
			return yf(a);
		}
		function zf(a) {
			try {
				return JSON.stringify(a);
			} catch (b) {
				return String(a);
			}
		}
		var Af;
		function Bf(a, b) {
			try {
				if (a)
					if (void 0 !== a.message) a = gb(a);
					else {
						var c = a;
						a = Error(zf(c));
						a.origError = c;
					}
				else a = Error('Unknown error');
				if (a.reported) return a;
				a.reported = !0;
				var d = b || a.associatedElement;
				d &&
					d.classList &&
					(d.classList.add('i-amphtml-error'),
					v().development &&
						(d.classList.add('i-amphtml-element-error'), d.setAttribute('error-message', a.message)));
				if (self.console) {
					var e = console.error || console.log;
					a.messageArray
						? e.apply(console, a.messageArray)
						: d ? e.call(console, a.message, d) : e.call(console, a.message);
				}
				d && d.Ca && d.Ca('amp:error', a.message);
				Cf.call(self, void 0, void 0, void 0, void 0, a);
			} catch (g) {
				setTimeout(function() {
					throw g;
				});
			}
			return a;
		}
		function Df(a) {
			return a
				? 'string' == typeof a
					? M(a, 'BLOCK_BY_CONSENT')
					: 'string' == typeof a.message ? M(a.message, 'BLOCK_BY_CONSENT') : !1
				: !1;
		}
		function Ef() {
			var a = self;
			a.onerror = Cf;
			a.addEventListener('unhandledrejection', function(a) {
				!a.reason ||
				('CANCELLED' !== a.reason.message &&
					'BLOCK_BY_CONSENT' !== a.reason.message &&
					'AbortError' !== a.reason.message)
					? Bf(a.reason || Error('rejected promise ' + a))
					: a.preventDefault();
			});
		}
		function Cf(a, b, c, d, e) {
			var g = this;
			!this || !this.document || (e && e.expected) || lf(this.document);
			if (!v().development) {
				var h = !1;
				try {
					h = Ff();
				} catch (k) {}
				if (!(h && 0.01 < Math.random())) {
					var l = Gf(a, b, c, d, e, h);
					l &&
						yf(function() {
							try {
								return Hf(g, l).catch(function() {});
							} catch (k) {}
						});
				}
			}
		}
		function Hf(a, b) {
			return b.pt && 0.9 > Math.random()
				? x()
				: If(a, b).then(function(a) {
						if (!a) {
							var c = new XMLHttpRequest();
							c.open('POST', 0.1 > Math.random() ? B.betaErrorReporting : B.errorReporting, !0);
							c.send(JSON.stringify(b));
						}
					});
		}
		function If(a, b) {
			a = qd(a);
			if (!a.isSingleDoc()) return Promise.resolve(!1);
			var c = a.getSingleDoc();
			if (!c.getRootNode().documentElement.hasAttribute('report-errors-to-viewer')) return Promise.resolve(!1);
			var d = V(c);
			return d.hasCapability('errorReporter')
				? d.isTrustedViewer().then(function(a) {
						if (!a) return !1;
						d.sendMessage(
							'error',
							K({ m: b.m, a: b.a, s: b.s, el: b.el, ex: b.ex, v: b.v, pt: b.pt, jse: b.jse })
						);
						return !0;
					})
				: Promise.resolve(!1);
		}
		function Gf(a, b, c, d, e, g) {
			var h = a;
			e && (h = e.message ? e.message : String(e));
			h || (h = 'Unknown error');
			a = h;
			var l = !(!e || !e.expected);
			if (!/_reported_/.test(a) && 'CANCELLED' != a) {
				var k = !(self && self.window),
					n = Math.random();
				if (-1 != a.indexOf('Failed to load:') || 'Script error.' == a || k) if (((l = !0), 0.001 < n)) return;
				var r = Va(a);
				if (!(r && 0.1 < n)) {
					h = Object.create(null);
					h.v = v().rtvVersion;
					h.noAmp = g ? '1' : '0';
					h.m = a.replace('\u200b\u200b\u200b', '');
					h.a = r ? '1' : '0';
					h.ex = l ? '1' : '0';
					h.dw = k ? '1' : '0';
					var u = '1p';
					self.context && self.context.location
						? ((h['3p'] = '1'), (u = '3p'))
						: v().runtime && (u = v().runtime);
					h.rt = u;
					'inabox' === u && (h.adid = v().a4aId);
					g = self;
					h.ca = g.AMP_CONFIG && g.AMP_CONFIG.canary ? '1' : '0';
					g = self;
					h.bt = g.AMP_CONFIG && g.AMP_CONFIG.type ? g.AMP_CONFIG.type : 'unknown';
					self.location.ancestorOrigins &&
						self.location.ancestorOrigins[0] &&
						(h.or = self.location.ancestorOrigins[0]);
					self.viewerState && (h.vs = self.viewerState);
					self.parent && self.parent != self && (h.iem = '1');
					if (self.AMP && self.AMP.viewer) {
						var w = self.AMP.viewer.getResolvedViewerUrl(),
							y = self.AMP.viewer.maybeGetMessagingOrigin();
						w && (h.rvu = w);
						y && (h.mso = y);
					}
					Af || (Af = Jf());
					h.jse = Af;
					var p = [];
					g = self.__AMP__EXPERIMENT_TOGGLES || null;
					for (var q in g) p.push(q + '=' + (g[q] ? '1' : '0'));
					h.exps = p.join(',');
					e
						? ((h.el = e.associatedElement ? e.associatedElement.tagName : 'u'),
							e.args && (h.args = JSON.stringify(e.args)),
							r || e.ignoreStack || !e.stack || (h.s = e.stack),
							e.message && (e.message += ' _reported_'))
						: ((h.f = b || ''), (h.l = c || ''), (h.c = d || ''));
					h.r = self.document ? self.document.referrer : '';
					h.ae = xf.join(',');
					h.fr = self.location.originalHash || self.location.hash;
					'production' === h.bt && (h.pt = '1');
					b = a;
					25 <= xf.length && xf.splice(0, xf.length - 25 + 1);
					xf.push(b);
					return h;
				}
			}
		}
		function Ff() {
			var a = self;
			if (!a.document) return !1;
			a = a.document.querySelectorAll('script[src]');
			for (var b = 0; b < a.length; b++) if (!O(a[b].src.toLowerCase())) return !0;
			return !1;
		}
		function Jf() {
			function a() {}
			a.prototype.t = function() {
				throw Error('message');
			};
			var b = new a();
			try {
				b.t();
			} catch (d) {
				b = d.stack;
				if (M(b, 't@')) return 'Safari';
				if (-1 < b.indexOf('.prototype.t@')) return 'Firefox';
				var c = b.split('\n').pop();
				if (/\bat .* \(/i.test(c)) return 'IE';
				if (M(b, 'Error: message')) return 'Chrome';
			}
			return 'unknown';
		}
		var Kf = '__AMP_ACTION_MAP__' + Math.random(),
			Lf = { form: [ 'submit', 'clear' ] },
			Mf = [
				{ tagOrTarget: 'AMP', method: 'setState' },
				{ tagOrTarget: '*', method: 'focus' },
				{ tagOrTarget: '*', method: 'hide' },
				{ tagOrTarget: '*', method: 'show' },
				{ tagOrTarget: '*', method: 'toggleClass' },
				{ tagOrTarget: '*', method: 'toggleVisibility' }
			],
			Nf = {
				button: !0,
				checkbox: !0,
				link: !0,
				listbox: !0,
				menuitem: !0,
				menuitemcheckbox: !0,
				menuitemradio: !0,
				option: !0,
				radio: !0,
				scrollbar: !0,
				slider: !0,
				spinbutton: !0,
				switch: !0,
				tab: !0,
				treeitem: !0
			};
		function Of(a, b, c, d, e, g, h, l, k, n) {
			l = void 0 === l ? '?' : l;
			k = void 0 === k ? null : k;
			n = void 0 === n ? Math.random() : n;
			this.node = a;
			this.method = b;
			this.args = c;
			this.source = d;
			this.caller = e;
			this.event = g;
			this.trust = h;
			this.actionEventType = l;
			this.tagOrTarget = k || a.tagName;
			this.sequenceId = n;
		}
		Of.prototype.satisfiesTrust = function(a) {
			if (!Pa(this.trust))
				return F().error('Action', "Invalid trust for '" + this.method + "': " + this.trust), !1;
			if (this.trust < a) {
				a: switch (this.trust) {
					case 1:
						var b = 'low';
						break a;
					case 3:
						b = 'high';
						break a;
					default:
						b = 'default';
				}
				C().error(
					'Action',
					'"' +
						this.actionEventType +
						'" event with "' +
						b +
						'" trust is not allowed to invoke "' +
						(this.tagOrTarget.toLowerCase() + '.' + this.method + '".')
				);
				return !1;
			}
			return !0;
		};
		function Pf(a, b) {
			this.ampdoc = a;
			this.W = b || a.getRootNode();
			this.ka = (this.Ff = this.ampdoc.isSingleDoc() && tf([ '\u26a14email', 'amp4email' ], this.W)) ? Mf : null;
			this.Md = I();
			this.xf = I();
			this.addEvent('tap');
			this.addEvent('submit');
			this.addEvent('change');
			this.addEvent('input-debounced');
			this.addEvent('input-throttled');
			this.addEvent('valid');
			this.addEvent('invalid');
		}
		Pf.installInEmbedWindow = function(a, b) {
			Zc(a, 'action', new Pf(b, a.document));
		};
		f = Pf.prototype;
		f.addEvent = function(a) {
			var b = this;
			if ('tap' == a)
				this.W.addEventListener('click', function(c) {
					c.defaultPrevented || b.trigger(c.target, a, c, 3);
				}),
					this.W.addEventListener('keydown', function(c) {
						var d = c.key,
							e = c.target;
						if ('Enter' == d || ' ' == d) {
							var l = e.getAttribute('role');
							if ((d = l)) (d = l.toLowerCase()), (d = mb.call(Nf, d));
							var k = d;
							!c.defaultPrevented && k && b.trigger(e, a, c, 3) && c.preventDefault();
						}
					});
			else if ('submit' == a)
				this.W.addEventListener(a, function(c) {
					b.trigger(c.target, a, c, 3);
				});
			else if ('change' == a)
				this.W.addEventListener(a, function(c) {
					var d = c.target;
					Qf(c);
					b.trigger(d, a, c, 3);
				});
			else if ('input-debounced' == a) {
				var c = sf(this.ampdoc.win, function(c) {
					b.trigger(c.target, a, c, 3);
				});
				this.W.addEventListener('input', function(a) {
					var b = new Rf(a);
					Qf(b);
					c(b);
				});
			} else if ('input-throttled' == a) {
				var d = rf(
					this.ampdoc.win,
					function(c) {
						b.trigger(c.target, a, c, 3);
					},
					100
				);
				this.W.addEventListener('input', function(a) {
					a = new Rf(a);
					Qf(a);
					d(a);
				});
			} else
				('valid' != a && 'invalid' != a) ||
					this.W.addEventListener(a, function(c) {
						b.trigger(c.target, a, c, 3);
					});
		};
		f.addGlobalTarget = function(a, b) {
			this.Md[a] = b;
		};
		f.addGlobalMethodHandler = function(a, b, c) {
			this.xf[a] = { handler: b, minTrust: void 0 === c ? 2 : c };
		};
		f.trigger = function(a, b, c, d, e) {
			return Sf(this, a, b, c, d, e);
		};
		f.execute = function(a, b, c, d, e, g, h) {
			a = new Of(a, b, c, d, e, g, h);
			Tf(this, a);
		};
		f.installActionHandler = function(a, b) {
			'amp-' === (a.getAttribute('id') || '').substring(0, 4) || a.tagName.toLowerCase();
			if (a.__AMP_ACTION_HANDLER__) F().error('Action', 'Action handler already installed for ' + a);
			else {
				a.__AMP_ACTION_HANDLER__ = b;
				var c = a.__AMP_ACTION_QUEUE__;
				z(c) &&
					U(a.ownerDocument.defaultView).delay(function() {
						c.forEach(function(a) {
							try {
								b(a);
							} catch (e) {
								F().error('Action', 'Action execution failed:', a, e);
							}
						});
						a.__AMP_ACTION_QUEUE__.length = 0;
					}, 1);
			}
		};
		f.hasAction = function(a, b, c) {
			return !!Uf(a, b, c);
		};
		f.hasResolvableAction = function(a, b, c) {
			var d = this,
				e = Uf(a, b, c);
			return e
				? e.actionInfos.some(function(a) {
						return !!Vf(d, a.target);
					})
				: !1;
		};
		f.hasResolvableActionForTarget = function(a, b, c, d) {
			var e = this;
			return (a = Uf(a, b, d))
				? a.actionInfos.some(function(a) {
						return Vf(e, a.target) == c;
					})
				: !1;
		};
		function Vf(a, b) {
			return a.Md[b] ? a.W : a.W.getElementById(b);
		}
		f.setAllowlist = function(a) {
			a.every(function(a) {
				return a.tagOrTarget && a.method;
			});
			this.ka = a;
		};
		f.addToAllowlist = function(a, b, c) {
			var d = this;
			(c && c.includes('email') !== this.Ff) ||
				(this.ka || (this.ka = []),
				z(b) || (b = [ b ]),
				b.forEach(function(b) {
					d.ka.some(function(c) {
						return c.tagOrTarget == a && c.method == b;
					}) || d.ka.push({ tagOrTarget: a, method: b });
				}));
		};
		function Sf(a, b, c, d, e, g) {
			var h = Uf(b, c);
			if (!h) return !1;
			var l = Math.random(),
				k = null;
			h.actionInfos.forEach(function(n) {
				function r() {
					var g = Vf(a, u);
					if (g) return (g = new Of(g, w, p, b, h.node, d, e, c, g.tagName || u, l)), Tf(a, g);
					a.La('Target "' + u + '" not found for action [' + y + '].');
				}
				var u = n.target,
					w = n.method,
					y = n.str,
					p = Wf(n.args, d, g);
				k = k ? k.then(r) : r();
			});
			return 1 <= h.actionInfos.length;
		}
		f.La = function(a, b) {
			if (b) throw ((a = C().createError('[Action] ' + a)), Bf(a, b), a);
			C().error('Action', a);
		};
		function Tf(a, b) {
			var c = b.method,
				d = b.tagOrTarget;
			if (a.ka && !Xf(b, a.ka))
				return a.La('"' + d + '.' + c + '" is not allowlisted ' + JSON.stringify(a.ka) + '.'), null;
			var e = a.Md[d];
			if (e) return e(b);
			var g = b.node,
				h = a.xf[c];
			if (h && b.satisfiesTrust(h.minTrust)) return h.handler(b);
			var l = g.tagName.toLowerCase();
			if ('amp-' === l.substring(0, 4))
				return g.enqueAction ? g.enqueAction(b) : a.La('Unrecognized AMP element "' + l + '".', g), null;
			var k = Lf[l];
			if ('amp-' === (g.getAttribute('id') || '').substring(0, 4) || (k && -1 < k.indexOf(c)))
				return (
					(a = g.__AMP_ACTION_HANDLER__)
						? a(b)
						: ((g.__AMP_ACTION_QUEUE__ = g.__AMP_ACTION_QUEUE__ || []), g.__AMP_ACTION_QUEUE__.push(b)),
					null
				);
			a.La('Target (' + d + ') doesn\'t support "' + c + '" action.', b.caller);
			return null;
		}
		function Uf(a, b, c) {
			for (; a && (!c || a != c); ) {
				var d = b;
				var e = a;
				var g = d,
					h = e[Kf];
				void 0 === h &&
					((h = null),
					e.hasAttribute('on')
						? ((g = e.getAttribute('on')), (h = Yf(g, e)), (e[Kf] = h))
						: e.hasAttribute('execute') &&
							((h = e.getAttribute('execute')), (h = Yf(g + ':' + h, e)), (e[Kf] = h)));
				var l = (e = h) ? e[d] || null : null;
				if (l && !a.disabled && !Gb(a, ':disabled')) return { node: a, actionInfos: l };
				a = a.parentElement;
			}
			return null;
		}
		f.setActions = function(a, b) {
			a.setAttribute('on', b);
			delete a[Kf];
		};
		function Qf(a) {
			var b = I(),
				c = a.target;
			void 0 !== c.value && (b.value = c.value);
			'INPUT' == c.tagName && (b.valueAsNumber = Number(c.value));
			void 0 !== c.checked && (b.checked = c.checked);
			if (void 0 !== c.min || void 0 !== c.max) (b.min = c.min), (b.max = c.max);
			c.files &&
				(b.files = Na(c.files).map(function(a) {
					return { name: a.name, size: a.size, type: a.type };
				}));
			if (0 < Object.keys(b).length)
				try {
					a.detail = b;
				} catch (d) {}
		}
		function Xf(a, b) {
			var c = a.method,
				d = a.node;
			a = a.tagOrTarget;
			'activate' === c && 'function' == typeof d.getDefaultActionAlias && (c = d.getDefaultActionAlias());
			var e = c.toLowerCase(),
				g = a.toLowerCase();
			return b.some(function(a) {
				return (a.tagOrTarget.toLowerCase() !== g && '*' !== a.tagOrTarget) || a.method.toLowerCase() !== e
					? !1
					: !0;
			});
		}
		function Rf(a) {
			this.detail = null;
			var b = this || I(),
				c;
			for (c in a) b[c] = 'function' === typeof a[c] ? Zf : a[c];
		}
		function Zf() {}
		function Yf(a, b) {
			var c = $f.bind(null, a, b),
				d = ag.bind(null, a, b);
			b = null;
			var e = new bg(a);
			do {
				var g = e.next();
				if (g.type != cg && (g.type != dg || ';' != g.value))
					if (g.type == eg || g.type == fg) {
						var h = g.value;
						d(e.next(), [ dg ], ':');
						var l = [];
						do {
							var k = d(e.next(), [ eg, fg ]).value,
								n = 'activate',
								r = null;
							var u = e.peek();
							if (
								u.type == dg &&
								'.' == u.value &&
								(e.next(),
								(n = d(e.next(), [ eg, fg ]).value || n),
								(u = e.peek()),
								u.type == dg && '(' == u.value)
							) {
								e.next();
								r = e;
								var w = d,
									y = c,
									p = r.peek(),
									q = null;
								if (p.type == gg) {
									q = I();
									var H = r.next().value;
									q.__AMP_OBJECT_STRING__ = H;
									w(r.next(), [ dg ], ')');
								} else {
									do {
										var E = (H = r.next());
										p = E.type;
										E = E.value;
										if (p != dg || (',' != E && ')' != E))
											if (p == eg || p == fg) {
												w(r.next(), [ dg ], '=');
												H = w(r.next(!0), [ eg, fg ]);
												var ja = [ H ];
												if (H.type == fg)
													for (p = r.peek(); p.type == dg && '.' == p.value; p = r.peek())
														r.next(), (H = w(r.next(!1), [ fg ])), ja.push(H);
												p = hg(ja);
												q || (q = I());
												q[E] = p;
												p = r.peek();
												y(
													p.type == dg && (',' == p.value || ')' == p.value),
													'Expected either [,] or [)]'
												);
											} else y(!1, '; unexpected token [' + (H.value || '') + ']');
									} while (H.type != dg || ')' != H.value);
								}
								r = q;
							}
							l.push({
								event: h,
								target: k,
								method: n,
								args: r,
								str: a
							});
							u = e.peek();
						} while (u.type == dg && ',' == u.value && e.next());
						b || (b = I());
						b[h] = l;
					} else c(!1, '; unexpected token [' + (g.value || '') + ']');
			} while (g.type != cg);
			return b;
		}
		function hg(a) {
			return 0 == a.length
				? null
				: 1 == a.length
					? a[0].value
					: {
							expression: a
								.map(function(a) {
									return a.value;
								})
								.join('.')
						};
		}
		function Wf(a, b, c) {
			if (!a) return a;
			var d = c || K({});
			b && (b = b.detail) && (d.event = b);
			var e = I();
			Object.keys(a).forEach(function(b) {
				var c = a[b];
				if ('object' == typeof c && c.expression) {
					c = c.expression;
					if ('.' == c) c = d;
					else {
						c = c.split('.');
						for (var g = d, k = 0; k < c.length; k++) {
							var n = c[k];
							if (n && g && void 0 !== g[n] && Sb(g, n)) g = g[n];
							else {
								g = void 0;
								break;
							}
						}
						c = g;
					}
					var r = c;
					c = void 0 === r ? null : r;
				}
				e[b] = d[c] ? d[c] : c;
			});
			return e;
		}
		function $f(a, b, c, d) {
			return G(c, 'Invalid action definition in %s: [%s] %s', b, a, d || '');
		}
		function ag(a, b, c, d, e) {
			void 0 !== e
				? $f(a, b, d.includes(c.type) && c.value == e, '; expected [' + e + ']')
				: $f(a, b, d.includes(c.type));
			return c;
		}
		var cg = 1,
			dg = 2,
			eg = 3,
			fg = 4,
			gg = 5;
		function bg(a) {
			this.M = a;
			this.Qd = -1;
		}
		bg.prototype.next = function(a) {
			var b = ig(this, a || !1);
			this.Qd = b.index;
			return b;
		};
		bg.prototype.peek = function(a) {
			return ig(this, a || !1);
		};
		function ig(a, b) {
			var c = a.Qd + 1;
			if (c >= a.M.length) return { type: cg, index: a.Qd };
			var d = a.M.charAt(c);
			if (-1 != ' \t\n\r\f\v\u00a0\u2028\u2029'.indexOf(d)) {
				for (c++; c < a.M.length && -1 != ' \t\n\r\f\v\u00a0\u2028\u2029'.indexOf(a.M.charAt(c)); c++);
				if (c >= a.M.length) return { type: cg, index: c };
				d = a.M.charAt(c);
			}
			if (b && (jg(d) || ('.' == d && c + 1 < a.M.length && jg(a.M[c + 1])))) {
				for (var e = '.' == d, g = c + 1; g < a.M.length; g++) {
					var h = a.M.charAt(g);
					if ('.' == h) e = !0;
					else if (!jg(h)) break;
				}
				a = a.M.substring(c, g);
				a = e ? parseFloat(a) : parseInt(a, 10);
				c = g - 1;
				return {
					type: eg,
					value: a,
					index: c
				};
			}
			if (-1 != ';:.()=,|!'.indexOf(d)) return { type: dg, value: d, index: c };
			if (-1 != '"\''.indexOf(d)) {
				g = -1;
				for (var l = c + 1; l < a.M.length; l++)
					if (a.M.charAt(l) == d) {
						g = l;
						break;
					}
				if (-1 == g) return { type: 0, index: c };
				a = a.M.substring(c + 1, g);
				c = g;
				return { type: eg, value: a, index: c };
			}
			if ('{' == d) {
				var k = 1;
				g = -1;
				for (d = c + 1; d < a.M.length; d++) {
					var n = a.M[d];
					'{' == n ? k++ : '}' == n && k--;
					if (0 >= k) {
						g = d;
						break;
					}
				}
				if (-1 == g) return { type: 0, index: c };
				a = a.M.substring(c, g + 1);
				c = g;
				return { type: gg, value: a, index: c };
			}
			for (
				g = c + 1;
				g < a.M.length && -1 == ' \t\n\r\f\x0B\u00a0\u2028\u2029;:.()=,|!"\'{}'.indexOf(a.M.charAt(g));
				g++
			);
			a = a.M.substring(c, g);
			c = g - 1;
			return !b || ('true' != a && 'false' != a)
				? jg(a.charAt(0)) ? { type: eg, value: a, index: c } : { type: fg, value: a, index: c }
				: { type: eg, value: 'true' == a, index: c };
		}
		function jg(a) {
			return '0' <= a && '9' >= a;
		}
		function kg(a, b) {
			for (var c = [], d = 0, e = 0; e < a.length; e++) {
				var g = a[e];
				b(g, e, a) ? c.push(g) : (d < e && (a[d] = g), d++);
			}
			d < a.length && (a.length = d);
			return c;
		}
		function lg(a, b) {
			for (var c = 0; c < a.length; c++) if (b(a[c], c, a)) return c;
			return -1;
		}
		function mg(a) {
			return !!a && 'function' == typeof a.getFormData;
		}
		var ng = [ 'GET', 'POST' ],
			og = [ z, Oa ];
		function pg(a, b) {
			var c = Object.assign({}, b);
			if (mg(b.body)) {
				var d = b.body;
				c.headers['Content-Type'] = 'multipart/form-data;charset=utf-8';
				b = d.entries();
				for (var e = [], g = b.next(); !g.done; g = b.next()) e.push(g.value);
				c.body = e;
			}
			return { input: a, init: c };
		}
		function qg(a, b) {
			G(Oa(a), 'Object expected: %s', a);
			if ('document' != b) return new Response(a.body, a.init);
			var c = I(),
				d = {
					status: 200,
					statusText: 'OK',
					getResponseHeader: function(a) {
						return c[String(a).toLowerCase()] || null;
					}
				};
			if (a.init) {
				var e = a.init;
				z(e.headers) &&
					e.headers.forEach(function(a) {
						var b = a[1];
						c[String(a[0]).toLowerCase()] = String(b);
					});
				e.status && (d.status = parseInt(e.status, 10));
				e.statusText && (d.statusText = String(e.statusText));
			}
			return new Response(a.body ? String(a.body) : '', d);
		}
		function rg(a, b, c, d) {
			if (!b) return x();
			var e = d.prerenderSafe ? x() : b.whenFirstVisible(),
				g = V(b),
				h = O(c),
				l = g.hasCapability('xhrInterceptor'),
				k = d.bypassInterceptorForDev && !1;
			return h || !l || k || !b.getRootNode().documentElement.hasAttribute('allow-xhr-interception')
				? e
				: e
						.then(function() {
							return g.isTrustedViewer();
						})
						.then(function(b) {
							if (b || P(a, 'untrusted-xhr-interception')) {
								var e = K({ originalRequest: pg(c, d) });
								return g.sendMessageAwaitResponse('xhr', e).then(function(a) {
									return qg(a, d.responseType);
								});
							}
						});
		}
		function sg(a, b, c) {
			!1 !== c.ampCors && (b = Lc(a, b));
			return b;
		}
		function tg(a, b) {
			a = a || {};
			var c = a.method;
			void 0 === c ? (c = 'GET') : ((c = c.toUpperCase()), ng.includes(c));
			a.method = c;
			a.headers = a.headers || K({});
			b && (a.headers.Accept = b);
			return a;
		}
		function ug(a, b, c) {
			c = c || {};
			var d = a.origin || N(a.location.href).origin;
			a = N(b).origin;
			d == a && ((c.headers = c.headers || {}), (c.headers['AMP-Same-Origin'] = 'true'));
			return c;
		}
		function vg(a) {
			var b = tg(a, 'application/json');
			'POST' != b.method ||
				mg(b.body) ||
				(og.some(function(a) {
					return a(b.body);
				}),
				(b.headers['Content-Type'] = b.headers['Content-Type'] || 'text/plain;charset=utf-8'),
				(b.body =
					'application/x-www-form-urlencoded' === b.headers['Content-Type']
						? Cc(b.body)
						: JSON.stringify(b.body)));
			return b;
		}
		function wg(a) {
			return new Promise(function(b) {
				if (a.ok) return b(a);
				b = a.status;
				var c = C().createError('HTTP error ' + b);
				c.retriable = 415 == b || (500 <= b && 600 > b);
				c.response = a;
				throw c;
			});
		}
		function xg(a) {
			this.win = a;
			a = qd(a);
			this.Bg = a.isSingleDoc() ? a.getSingleDoc() : null;
		}
		f = xg.prototype;
		f.Vg = function(a, b) {
			var c = arguments,
				d = this;
			return rg(this.win, this.Bg, a, b).then(function(a) {
				if (a) return a;
				mg(b.body) && (b.body = b.body.getFormData());
				return d.win.fetch.apply(null, c);
			});
		};
		function yg(a, b, c) {
			c = void 0 === c ? {} : c;
			b = sg(a.win, b, c);
			c = ug(a.win, b, c);
			return a.Vg(b, c).then(
				function(a) {
					return a;
				},
				function(a) {
					var c = N(b).origin;
					throw C().createExpectedError('XHR', 'Failed fetching (' + c + '/...):', a && a.message);
				}
			);
		}
		f.fetchJson = function(a, b) {
			return this.fetch(a, vg(b));
		};
		f.fetchText = function(a, b) {
			return this.fetch(a, tg(b, 'text/plain'));
		};
		f.xssiJson = function(a, b) {
			return b
				? a.text().then(function(a) {
						return M(a, b)
							? Tb(a.slice(b.length))
							: (C().warn('XHR', 'Failed to strip missing prefix "' + b + '" in fetch response.'), Tb(a));
					})
				: a.json();
		};
		f.fetch = function(a, b) {
			b = tg(b);
			return yg(this, a, b).then(function(a) {
				return wg(a);
			});
		};
		f.sendSignal = function(a, b) {
			return yg(this, a, b).then(function(a) {
				return wg(a);
			});
		};
		f.getCorsUrl = function(a, b) {
			return Lc(a, b);
		};
		function zg(a) {
			xg.call(this, a);
			this.xb = I();
		}
		m(zg, xg);
		zg.prototype.fetch = function(a, b) {
			var c = this,
				d = !b || !b.method || 'GET' === b.method,
				e = Ag(this, a, (b && b.headers && b.headers.Accept) || ''),
				g = !!this.xb[e];
			if (d && g)
				return this.xb[e].then(function(a) {
					return a.clone();
				});
			var h = xg.prototype.fetch.call(this, a, b);
			d &&
				(this.xb[e] = h.then(
					function(a) {
						delete c.xb[e];
						return a.clone();
					},
					function(a) {
						delete c.xb[e];
						throw a;
					}
				));
			return h;
		};
		function Ag(a, b, c) {
			a = Kc(a.win.location);
			'string' == typeof a && (a = N(a));
			if ('function' == typeof URL) b = new URL(b, a.href).toString();
			else {
				'string' == typeof a && (a = N(a));
				b = b.replace(/\\/g, '/');
				var d = N(b);
				b = M(b.toLowerCase(), d.protocol)
					? d.href
					: M(b, '//')
						? a.protocol + b
						: M(b, '/') ? a.origin + b : a.origin + a.pathname.replace(/\/[^/]*$/, '/') + b;
			}
			return Fc(b) + c;
		}
		function Bg(a, b) {
			var c = Cg(a);
			if (!c) return null;
			var d = c.split(';');
			for (a = 0; a < d.length; a++) {
				var e = d[a].trim(),
					g = e.indexOf('='),
					h;
				if ((h = -1 != g)) (h = e.substring(0, g).trim()), (h = la(h, void 0) == b);
				if (h) return (b = e.substring(g + 1).trim()), la(b, b);
			}
			return null;
		}
		function Cg(a) {
			try {
				return a.document.cookie;
			} catch (b) {
				return '';
			}
		}
		function Dg(a, b, c, d) {
			var e = { highestAvailableDomain: !0 };
			e = void 0 === e ? {} : e;
			if (e.allowOnProxyOrigin)
				G(
					!e.highestAvailableDomain,
					'Could not support highestAvailable Domain on proxy origin, specify domain explicitly'
				);
			else {
				G(!O(a.location.href), 'Should never attempt to set cookie on proxy origin: ' + b);
				var g = N(a.location.href).hostname.toLowerCase(),
					h = N(B.cdn).hostname.toLowerCase();
				G(
					!(g == h || sb(g, '.' + h)),
					'Should never attempt to set cookie on proxy origin. (in depth check): ' + b
				);
			}
			g = void 0;
			if (e.domain) g = e.domain;
			else if (e.highestAvailableDomain)
				a: if ((g = a.document.head && a.document.head.querySelector("meta[name='amp-cookie-scope']")))
					(g = g.getAttribute('content') || ''),
						(h = Kc(a.location.href)),
						(g = sb(h, '.' + g) ? g : h.split('://')[1]);
				else {
					if (!O(a.location.href)) {
						g = a.location.hostname.split('.');
						h = g[g.length - 1];
						var l;
						for (l = '-test-amp-cookie-tmp'; Bg(a, l); ) l = '-test-amp-cookie-tmp0';
						for (var k = g.length - 2; 0 <= k; k--)
							if (((h = g[k] + '.' + h), Eg(a, l, 'delete', Date.now() + 1e3, h), 'delete' == Bg(a, l))) {
								Eg(a, l, 'delete', Date.now() - 1e3, h);
								g = h;
								break a;
							}
					}
					g = null;
				}
			Eg(a, b, c, d, g, e.sameSite, e.secure);
		}
		function Eg(a, b, c, d, e, g, h) {
			'ampproject.org' == e && ((c = 'delete'), (d = 0));
			b =
				encodeURIComponent(b) +
				'=' +
				encodeURIComponent(c) +
				'; path=/' +
				(e ? '; domain=' + e : '') +
				'; expires=' +
				new Date(d).toUTCString() +
				(g ? '; SameSite=' + g : '') +
				(h ? '; Secure' : '');
			try {
				a.document.cookie = b;
			} catch (l) {}
		}
		function Fg(a) {
			this.w = a.win;
			this.R = U(this.w);
			this.Cd = {};
			var b = rd(a).canonicalUrl;
			this.Bd = b ? N(b).origin : null;
		}
		Fg.prototype.getScopedCid = function(a, b) {
			var c = this;
			if (this.Cd[b]) return this.Cd[b];
			var d;
			return (this.Cd[b] = this.R
				.poll(200, function() {
					d = Bg(c.w, 'AMP_TOKEN');
					return '$RETRIEVING' !== d;
				})
				.then(function() {
					if ('$OPT_OUT' === d) return '$OPT_OUT';
					if (('$NOT_FOUND' !== d || !O(c.w.document.referrer)) && d && '$' === d[0]) return null;
					(d && (!d || '$' !== d[0])) || Gg(c, '$RETRIEVING', 3e4);
					return c
						.wb('https://ampcid.google.com/v1/publisher:getClientId?key=' + a, b, d)
						.then(function(e) {
							var g = c.zf(e);
							return !g && e.alternateUrl
								? c.wb(e.alternateUrl + '?key=' + a, b, d).then(c.zf.bind(c))
								: g;
						})
						.catch(function(a) {
							Gg(c, '$ERROR', 3e4);
							a && a.response
								? a.response.json().then(function(a) {
										F().error('GoogleCidApi', JSON.stringify(a));
									})
								: F().error('GoogleCidApi', a);
							return null;
						});
				}));
		};
		Fg.prototype.wb = function(a, b, c) {
			b = K({ originScope: b, canonicalOrigin: this.Bd });
			c && (b.securityToken = c);
			return this.R.timeoutPromise(
				3e4,
				S(this.w, 'xhr')
					.fetchJson(a, { method: 'POST', ampCors: !1, credentials: 'include', mode: 'cors', body: b })
					.then(function(a) {
						return a.json();
					})
			);
		};
		Fg.prototype.zf = function(a) {
			if (a.optOut) return Gg(this, '$OPT_OUT', 31536e6), '$OPT_OUT';
			if (a.clientId) return Gg(this, a.securityToken, 31536e6), a.clientId;
			if (a.alternateUrl) return null;
			Gg(this, '$NOT_FOUND', 36e5);
			return null;
		};
		function Gg(a, b, c) {
			if (b) {
				var d = a.w;
				a = a.w.Date.now() + c;
				Dg(d, 'AMP_TOKEN', b, a);
			}
		}
		function Hg(a) {
			this.C = a;
			this.h = V(this.C);
			this.te = null;
			this.R = U(this.C.win);
		}
		Hg.prototype.isSupported = function() {
			return this.h.isCctEmbedded() && this.h.isProxyOrigin();
		};
		Hg.prototype.getScopedCid = function(a) {
			var b = this;
			if (!this.h.isCctEmbedded()) return Promise.resolve(null);
			this.te ||
				(this.te = this.wb(
					'https://ampcid.google.com/v1/cache:getClientId?key=AIzaSyDKtqGxnoeIqVM33Uf7hRSa3GJxuzR7mLc'
				));
			return this.te.then(function(c) {
				return c ? Ig(b, c, a) : null;
			});
		};
		Hg.prototype.wb = function(a, b) {
			var c = this;
			b = void 0 === b ? !0 : b;
			var d = K({ publisherOrigin: Kc(this.C.win.location) });
			return this.R
				.timeoutPromise(
					3e4,
					S(this.C.win, 'xhr').fetchJson(a, {
						method: 'POST',
						ampCors: !1,
						credentials: 'include',
						mode: 'cors',
						body: d
					}),
					'fetchCidTimeout'
				)
				.then(function(a) {
					return a.json().then(function(a) {
						if (a.optOut) return null;
						var d = a.publisherClientId;
						return !d && b && a.alternateUrl
							? c.wb(a.alternateUrl + '?key=AIzaSyDKtqGxnoeIqVM33Uf7hRSa3GJxuzR7mLc', !1)
							: d;
					});
				})
				.catch(function(a) {
					a && a.response
						? a.response.json().then(function(a) {
								F().error('CacheCidApi', JSON.stringify(a));
							})
						: a && 'fetchCidTimeout' == a.message
							? F().expectedError('CacheCidApi', a)
							: F().error('CacheCidApi', a);
					return null;
				});
		};
		function Ig(a, b, c) {
			b = b + ';' + c;
			return S(a.C.win, 'crypto').sha384Base64(b).then(function(a) {
				return 'amp-' + a;
			});
		}
		function Jg(a) {
			this.C = a;
			this.h = V(this.C);
			this.Bd = (a = rd(this.C).canonicalUrl) ? N(a).origin : null;
		}
		Jg.prototype.isSupported = function() {
			return this.h.hasCapability('cid') ? this.h.isTrustedViewer() : Promise.resolve(!1);
		};
		Jg.prototype.getScopedCid = function(a, b) {
			b = K({ scope: b, clientIdApi: !!a, canonicalOrigin: this.Bd });
			a && (b.apiKey = a);
			return this.h.sendMessageAwaitResponse('cid', b);
		};
		var Kg = { '+': '-', '/': '_', '=': '.' };
		function Lg(a) {
			a = Wb(a);
			return btoa(a).replace(/[+/=]/g, function(a) {
				return Kg[a];
			});
		}
		var Mg = /^[a-zA-Z0-9-_.]+$/,
			Ng = { googleanalytics: 'AMP_ECID_GOOGLE' },
			Og = { googleanalytics: 'AIzaSyA65lEHUEizIsNtlbNo-l2K18dT680nsaM' };
		function Pg(a) {
			this.ampdoc = a;
			this.rd = null;
			this.Jd = Object.create(null);
			this.df = new Hg(a);
			this.xg = new Jg(a);
			this.Ng = new Fg(a);
			this.qd = null;
		}
		Pg.prototype.get = function(a, b, c) {
			var d = this;
			G(
				Mg.test(a.scope) && Mg.test(a.cookieName),
				'The CID scope and cookie name must only use the characters [a-zA-Z0-9-_.]+\nInstead found: %s',
				a.scope
			);
			return b
				.then(function() {
					return d.ampdoc.whenFirstVisible();
				})
				.then(function() {
					return Qg(d.ampdoc);
				})
				.then(function(e) {
					if (e) return '';
					var g = Rg(d, a, c || b);
					return U(d.ampdoc.win)
						.timeoutPromise(1e4, g, 'Getting cid for "' + a.scope + '" timed out')
						.catch(function(a) {
							hb(a);
						});
				});
		};
		Pg.prototype.optOut = function() {
			return Sg(this.ampdoc);
		};
		function Rg(a, b, c) {
			var d = b.scope,
				e = N(a.ampdoc.win.location.href);
			if (!O(e)) {
				var g = Tg(a, d);
				return g
					? a.Ng.getScopedCid(g, d).then(function(e) {
							return '$OPT_OUT' == e ? null : e ? (Ug(a.ampdoc.win, b.cookieName || d, e), e) : Vg(a, b, c);
						})
					: Vg(a, b, c);
			}
			return a.xg.isSupported().then(function(b) {
				if (b) {
					var g = Tg(a, d);
					return a.xg.getScopedCid(g, d);
				}
				return a.df.isSupported() && Tg(a, d)
					? a.df.getScopedCid(d).then(function(b) {
							return b ? b : Wg(a, c, d, e);
						})
					: Wg(a, c, d, e);
			});
		}
		function Wg(a, b, c, d) {
			return Xg(a, b).then(function(b) {
				return S(a.ampdoc.win, 'crypto').sha384Base64(b + Yg(d) + c);
			});
		}
		function Tg(a, b) {
			a.qd || (a.qd = Zg(a));
			return a.qd[b];
		}
		function Zg(a) {
			var b = {},
				c = a.ampdoc.getMetaByName('amp-google-client-id-api');
			c &&
				c.split(',').forEach(function(a) {
					a = a.trim();
					if (0 < a.indexOf('=')) {
						var c = a.split('=');
						a = c[0].trim();
						b[a] = c[1].trim();
					} else {
						var d = a;
						(a = Ng[d])
							? (b[a] = Og[d])
							: C().warn(
									'CID',
									'Unsupported client for Google CID API: ' +
										d +
										'.Please remove or correct meta[name="amp-google-client-id-api"]'
								);
					}
				});
			return b;
		}
		function Sg(a) {
			V(a).sendMessage('cidOptOut', {});
			return gd(Yc(a), 'storage').then(function(a) {
				return a.set('amp-cid-optout', !0);
			});
		}
		function Qg(a) {
			return gd(Yc(a), 'storage')
				.then(function(a) {
					return a.get('amp-cid-optout').then(function(a) {
						return !!a;
					});
				})
				.catch(function() {
					return !1;
				});
		}
		function Ug(a, b, c) {
			var d = Date.now() + 31536e6;
			Dg(a, b, c, d);
		}
		function Vg(a, b, c) {
			var d = a.ampdoc.win,
				e = b.scope,
				g = b.cookieName || e,
				h = Bg(d, g);
			if (!h && !b.createCookieIfNotPresent) return Promise.resolve(null);
			if (h) return /^amp-/.test(h) && Ug(d, g, h), Promise.resolve(h);
			if (a.Jd[e]) return a.Jd[e];
			var l = ah(d).then(function(a) {
				return 'amp-' + a;
			});
			Promise.all([ l, c ]).then(function(a) {
				var b = a[0];
				Bg(d, g) || Ug(d, g, b);
			});
			return (a.Jd[e] = l);
		}
		function Yg(a) {
			G(O(a), 'Expected proxy origin %s', a.origin);
			return Kc(a);
		}
		function Xg(a, b) {
			if (a.rd) return a.rd;
			var c = a.ampdoc.win;
			return (a.rd = bh(a.ampdoc).then(function(d) {
				var e = !1;
				if (d && !ch(d)) {
					var g = Promise.resolve(d.cid);
					dh(d) && (e = !0);
				} else (g = S(c, 'crypto').sha384Base64(eh(c))), (e = !0);
				e &&
					g.then(function(c) {
						fh(a.ampdoc, b, c);
					});
				return g;
			}));
		}
		function fh(a, b, c) {
			var d = a.win;
			Qb(d)
				? gh(a, hh(c))
				: b.then(function() {
						try {
							d.localStorage.setItem('amp-cid', hh(c));
						} catch (e) {}
					});
		}
		function gh(a, b) {
			var c = V(a);
			return c.isTrustedViewer().then(function(a) {
				if (a)
					return (
						F().expectedError('CID', 'Viewer does not provide cap=cid'),
						c.sendMessageAwaitResponse('cid', b).then(function(a) {
							var b;
							if ((b = a)) {
								try {
									var c = Tb(a);
								} catch (l) {
									c = null;
								}
								b = !c;
							}
							return b
								? (F().expectedError('CID', 'invalid cid format'),
									JSON.stringify(K({ time: Date.now(), cid: a })))
								: a;
						})
					);
			});
		}
		function hh(a) {
			return JSON.stringify(K({ time: Date.now(), cid: a }));
		}
		function bh(a) {
			var b = a.win;
			try {
				var c = b.localStorage.getItem('amp-cid');
			} catch (e) {}
			var d = Promise.resolve(c);
			!c && Qb(b) && (d = gh(a));
			return d.then(function(a) {
				if (!a) return null;
				a = Tb(a);
				return { time: a.time, cid: a.cid };
			});
		}
		function ch(a) {
			var b = a.time,
				c = Date.now();
			return b + 31536e6 < c;
		}
		function dh(a) {
			a = a.time;
			var b = Date.now();
			return a + 864e5 < b;
		}
		function eh(a) {
			var b;
			if ((b = a.crypto || a.msCrypto) && b.getRandomValues) {
				var c = new Uint8Array(16);
				b.getRandomValues(c);
				b = c;
			} else b = null;
			return b ? b : String(a.location.href + Date.now() + a.Math.random() + a.screen.width + a.screen.height);
		}
		function ah(a) {
			var b = eh(a);
			return 'string' == typeof b
				? S(a, 'crypto').sha384Base64(b)
				: nb(function() {
						return Lg(b).replace(/\.+$/, '');
					});
		}
		function ih(a) {
			this.w = a;
			var b = null,
				c = !1;
			a.crypto &&
				(a.crypto.subtle
					? (b = a.crypto.subtle)
					: a.crypto.webkitSubtle && ((b = a.crypto.webkitSubtle), (c = !0)));
			this.pkcsAlgo = { name: 'RSASSA-PKCS1-v1_5', hash: { name: 'SHA-256' } };
			this.subtle = b;
			this.kh = c;
			this.Nb = null;
		}
		f = ih.prototype;
		f.sha384 = function(a) {
			var b = this;
			'string' === typeof a && (a = Vb(a));
			if (!this.subtle || this.Nb)
				return (this.Nb || jh(this)).then(function(b) {
					return b(a);
				});
			try {
				return this.subtle.digest({ name: 'SHA-384' }, a).then(
					function(a) {
						return new Uint8Array(a);
					},
					function(c) {
						c.message &&
							0 > c.message.indexOf('secure origin') &&
							C().error('Crypto', 'SubtleCrypto failed, fallback to closure lib.', c);
						return jh(b).then(function() {
							return b.sha384(a);
						});
					}
				);
			} catch (c) {
				return (
					F().error('Crypto', 'SubtleCrypto failed, fallback to closure lib.', c),
					jh(this).then(function() {
						return b.sha384(a);
					})
				);
			}
		};
		f.sha384Base64 = function(a) {
			return this.sha384(a).then(function(a) {
				return Lg(a);
			});
		};
		f.uniform = function(a) {
			return this.sha384(a).then(function(a) {
				for (var b = 0, d = 2; 0 <= d; d--) b = (b + a[d]) / 256;
				return b;
			});
		};
		function jh(a) {
			return a.Nb
				? a.Nb
				: (a.Nb = sd(a.w).preloadExtension('amp-crypto-polyfill').then(function() {
						return S(a.w, 'crypto-polyfill');
					}));
		}
		f.isPkcsAvailable = function() {
			return !!this.subtle && !1 !== this.w.isSecureContext;
		};
		f.importPkcsKey = function(a) {
			this.isPkcsAvailable();
			var b = this.kh ? Ub(JSON.stringify(a)) : a;
			return this.subtle.importKey('jwk', b, this.pkcsAlgo, !0, [ 'verify' ]);
		};
		f.verifyPkcs = function(a, b, c) {
			this.isPkcsAvailable();
			return this.subtle.verify(this.pkcsAlgo, a, b, c);
		};
		var kh = [ 'prefetch', 'preload', 'preconnect', 'dns-prefetch' ];
		function lh(a) {
			this.C = a;
			this.pe = this.Rd = null;
		}
		lh.prototype.get = function() {
			if (this.Rd) return this.Rd;
			var a = this.C,
				b = a.getUrl(),
				c = Jc(b),
				d = a.getRootNode();
			b = d && d.AMP && d.AMP.canonicalUrl;
			if (!b) {
				var e = d.querySelector('link[rel=canonical]');
				b = e ? N(e.href).href : c;
			}
			var g = String(Math.floor(1e4 * a.win.Math.random())),
				h = mh(a.win.document);
			d = nh(a.win.document);
			var l = oh(a);
			return (this.Rd = {
				get sourceUrl() {
					return Jc(a.getUrl());
				},
				canonicalUrl: b,
				pageViewId: g,
				get pageViewId64() {
					this.pe || (this.pe = ah(a.win));
					return this.pe;
				},
				linkRels: h,
				viewport: d,
				replaceParams: l
			});
		};
		function mh(a) {
			var b = I();
			if (a.head) {
				a = a.head.querySelectorAll('link[rel]');
				for (var c = {}, d = 0; d < a.length; c = { mb: c.mb }, d++) {
					var e = a[d];
					c.mb = e.href;
					var g = e.getAttribute('rel');
					g &&
						c.mb &&
						g.split(/\s+/).forEach(
							(function(a) {
								return function(c) {
									if (-1 == kh.indexOf(c)) {
										var d = b[c];
										d ? (z(d) || (d = b[c] = [ d ]), d.push(a.mb)) : (b[c] = a.mb);
									}
								};
							})(c)
						);
				}
			}
			return b;
		}
		function nh(a) {
			var b = a.head.querySelector('meta[name="viewport"]');
			return b ? b.getAttribute('content') : null;
		}
		function oh(a) {
			var b;
			(b = !a.isSingleDoc()) ||
				((b = a.win.location.href),
				'string' == typeof b && (b = N(b)),
				(b = 'a' != (O(b) ? b.pathname.split('/', 2)[1] : null)));
			if (b) return null;
			a = N(a.win.location.href);
			var c = t(a.search).amp_r;
			return void 0 === c ? null : t(c);
		}
		var ph = null,
			qh = [ 'gclid', 'gclsrc' ],
			rh = [ /^t.co$/ ];
		function sh() {
			return G(ph, 'E#19457 trackImpressionPromise');
		}
		function th() {
			var a = self,
				b = new L(),
				c = b.promise,
				d = b.resolve;
			ph = U(a).timeoutPromise(8e3, c, 'TrackImpressionPromise timeout').catch(function(a) {
				F().warn('IMPRESSION', a);
			});
			b = V(a.document.documentElement);
			var e = b.isTrustedViewer(),
				g = b.getReferrerUrl().then(function(a) {
					return uh(a);
				});
			Promise.all([ e, g ]).then(function(b) {
				var c = b[1];
				if (b[0] || c || P(a, 'alp')) {
					var e = vh(a),
						g = wh(a);
					Promise.all([ e, g ]).then(
						function() {
							d();
						},
						function() {}
					);
				} else d();
			});
		}
		function vh(a) {
			var b = V(a.document.documentElement);
			return b.getParam('replaceUrl')
				? b.hasCapability('replaceUrl')
					? b.sendMessageAwaitResponse('getReplaceUrl', void 0).then(
							function(a) {
								a && 'object' == typeof a
									? b.replaceUrl(a.replaceUrl || null)
									: F().warn('IMPRESSION', 'get invalid replaceUrl response');
							},
							function(a) {
								F().warn('IMPRESSION', 'Error request replaceUrl from viewer', a);
							}
						)
					: (b.replaceUrl(b.getParam('replaceUrl') || null), x())
				: x();
		}
		function uh(a) {
			var b = N(a);
			return 'https:' != b.protocol
				? !1
				: rh.some(function(a) {
						return a.test(b.hostname);
					});
		}
		function wh(a) {
			var b = Xc(a.document.documentElement),
				c = V(b).getParam('click');
			if (!c) return x();
			if (0 != c.indexOf('https://'))
				return C().warn('IMPRESSION', 'click fragment param should start with https://. Found ', c), x();
			a.location.hash && (a.location.hash = '');
			return b
				.whenFirstVisible()
				.then(function() {
					return xh(a, c);
				})
				.then(function(b) {
					if (b) {
						var c = b.location;
						(b = b.tracking_url || c) && !O(b) && (new Image().src = b);
						if (c && a.history.replaceState) {
							b = V(a.document.documentElement);
							var d = a.location.href;
							c = N(c);
							c = t(c.search);
							c = Bc(d, c);
							a.history.replaceState(null, '', c);
							b.maybeUpdateFragmentForCct();
						}
					}
				})
				.catch(function(a) {
					C().warn('IMPRESSION', 'Error on request clickUrl: ', a);
				});
		}
		function xh(a, b) {
			return S(a, 'xhr').fetchJson(b, { credentials: 'include' }).then(function(a) {
				return 204 == a.status ? null : a.json();
			});
		}
		function yh(a) {
			return a.whenReady().then(function() {
				return !!a.getBody().querySelector('amp-analytics[type=googleanalytics]');
			});
		}
		function zh() {
			this.F = [];
		}
		zh.prototype.peek = function() {
			var a = this.F.length;
			return a ? this.F[a - 1].item : null;
		};
		zh.prototype.enqueue = function(a, b) {
			if (isNaN(b)) throw Error('Priority must not be NaN.');
			for (var c = -1, d = 0, e = this.F.length; d <= e; ) {
				c = Math.floor((d + e) / 2);
				if (c === this.F.length) break;
				if (this.F[c].priority < b) d = c + 1;
				else if (0 < c && this.F[c - 1].priority >= b) e = c - 1;
				else break;
			}
			this.F.splice(c, 0, { item: a, priority: b });
		};
		zh.prototype.forEach = function(a) {
			for (var b = this.F.length; b--; ) a(this.F[b].item);
		};
		zh.prototype.dequeue = function() {
			return this.F.length ? this.F.pop().item : null;
		};
		da.Object.defineProperties(zh.prototype, {
			length: {
				configurable: !0,
				enumerable: !0,
				get: function() {
					return this.F.length;
				}
			}
		});
		var Ah = [ '_top', '_blank' ];
		function Bh(a, b) {
			var c = this;
			this.ampdoc = a;
			this.oa = b || a.getRootNode();
			this.H = wd(this.ampdoc);
			this.h = V(this.ampdoc);
			this.O = bd(this.ampdoc, 'history');
			this.ta = T(this.ampdoc.win);
			this.jh = this.ta.isIos() && this.ta.isSafari();
			this.Db = Qb(this.ampdoc.win) && this.h.isOvertakeHistory();
			this.Vd = this.oa != this.ampdoc.getRootNode() || !!this.ampdoc.getParent();
			this.ih = 'inabox' == v(this.ampdoc.win).runtime;
			this.eg = this.oa.nodeType == Node.DOCUMENT_NODE ? this.oa.documentElement : this.oa;
			this.qb = this.bh.bind(this);
			this.oa.addEventListener('click', this.qb);
			this.oa.addEventListener('contextmenu', this.qb);
			this.Oe = !1;
			yh(this.ampdoc).then(function(a) {
				c.Oe = a;
			});
			this.Gf = this.Za = !1;
			Promise.all([ this.h.isTrustedViewer(), this.h.getViewerOrigin() ]).then(function(a) {
				c.Za = a[0];
				a = a[1];
				'string' == typeof a && (a = N(a));
				a = B.localhostRegex.test(a.origin);
				c.Gf = a;
			});
			this.md = null;
			this.Ne = new zh();
			this.Sf = new zh();
		}
		Bh.installInEmbedWindow = function(a, b) {
			Zc(a, 'navigation', new Bh(b, a.document));
		};
		f = Bh.prototype;
		f.cleanup = function() {
			this.qb &&
				(this.oa.removeEventListener('click', this.qb), this.oa.removeEventListener('contextmenu', this.qb));
		};
		f.openWindow = function(a, b, c, d) {
			var e = '';
			(!this.ta.isIos() && this.ta.isChrome()) || d || (e += 'noopener');
			var g = Ob(a, b, c, e);
			g && !d && (g.opener = null);
		};
		f.navigateTo = function(a, b, c, d) {
			var e = void 0 === d ? {} : d;
			d = void 0 === e.target ? '_top' : e.target;
			e = void 0 === e.opener ? !1 : e.opener;
			b = Ch(this, b);
			var g = Tc(this.eg, 'url');
			if (g.isProtocolValid(b))
				if ((G(Ah.includes(d), "Target '" + d + "' not supported."), (b = g.getSourceUrl(b)), '_blank' == d))
					this.openWindow(a, b, d, e);
				else {
					if (c && (this.md || (this.md = Dh(this)), this.md.includes(c) && this.navigateToAmpUrl(b, c)))
						return;
					a.top.location.href = b;
				}
			else C().error('navigation', 'Cannot navigate to invalid protocol: ' + b);
		};
		f.navigateToAmpUrl = function(a, b) {
			return this.h.hasCapability('a2a')
				? (this.h.sendMessage('a2aNavigate', K({ url: a, requestedBy: b })), !0)
				: !1;
		};
		function Dh(a) {
			return (a = a.oa.querySelector('meta[name="amp-to-amp-navigation"]')) && a.hasAttribute('content')
				? a.getAttribute('content').split(',').map(function(a) {
						return a.trim();
					})
				: [];
		}
		f.bh = function(a) {
			if (!a.defaultPrevented) {
				var b = Fb(a.__AMP_CUSTOM_LINKER_TARGET__ || a.target, 'A');
				if (b && b.href)
					if ('click' == a.type) {
						Eh(this, b);
						var c = Fh(this, b.href),
							d;
						if ((d = !Gh(this, a, b, c))) {
							if (this.Db) {
								d = b.ownerDocument.defaultView;
								var e = b.href,
									g = c.protocol;
								'ftp:' == g
									? (Ob(d, e, '_blank'), a.preventDefault(), (d = !0))
									: ((g = /^(https?|mailto):$/.test(g)),
										this.jh && !g ? (Ob(d, e, '_top'), a.preventDefault(), (d = !0)) : (d = !1));
							} else d = !1;
							d = !d;
						}
						if (d)
							if (
								((d = Fh(this, '')),
								Hh(c) != Hh(d) && (Ih(this, b, a), (c = Fh(this, b.href))),
								(e = c),
								(c = Hh(e)),
								(g = Hh(d)),
								e.hash && c == g)
							)
								Jh(this, a, e, d);
							else {
								e = (b.getAttribute('target') || '').toLowerCase();
								(this.Vd || this.ih) &&
									'_top' != e &&
									'_blank' != e &&
									((e = '_blank'), b.setAttribute('target', e));
								g = this.ampdoc.win;
								var h = T(g);
								b = V(b);
								d.search &&
									h.isSafari() &&
									13 <= h.getMajorVersion() &&
									b.isProxyOrigin() &&
									b.isEmbedded() &&
									Kh(g, d, e);
								this.viewerInterceptsNavigation(c, 'intercept_click') && a.preventDefault();
							}
					} else 'contextmenu' == a.type && (Eh(this, b), Ih(this, b, a));
			}
		};
		function Ih(a, b, c) {
			a.Ne.forEach(function(a) {
				a(b, c);
			});
		}
		function Ch(a, b) {
			a.Sf.forEach(function(a) {
				b = a(b);
			});
			return b;
		}
		function Eh(a, b) {
			var c = null;
			if (a.Oe && !a.Vd) {
				a = N(a.ampdoc.win.location.href);
				var d = t(a.search);
				a = [];
				for (var e = 0; e < qh.length; e++) {
					var g = qh[e];
					'undefined' !== typeof d[g] && a.push(g);
				}
				d = b.getAttribute('data-amp-addparams');
				e = b.href;
				d && (e = Bc(e, t(d)));
				d = N(e);
				d = t(d.search);
				for (e = a.length - 1; 0 <= e; e--) 'undefined' !== typeof d[a[e]] && a.splice(e, 1);
				d = '';
				for (e = 0; e < a.length; e++)
					(g = a[e]), (d += 0 == e ? g + '=QUERY_PARAM(' + g + ')' : '&' + g + '=QUERY_PARAM(' + g + ')');
				c = d;
			}
			Tc(b, 'url-replace').maybeExpandLink(b, c);
		}
		function Gh(a, b, c, d) {
			return c.hasAttribute('rel') &&
			c
				.getAttribute('rel')
				.split(' ')
				.map(function(a) {
					return a.trim();
				})
				.includes('amphtml')
				? a.navigateToAmpUrl(d.href, '<a rel=amphtml>') ? (b.preventDefault(), !0) : !1
				: !1;
		}
		function Kh(a, b, c) {
			function d() {
				var b = a.location.href;
				b == g
					? (F().info('navigation', 'Restored iframe URL with query string:', e),
						a.history.replaceState(null, '', e))
					: F().error('navigation', 'Unexpected iframe URL change:', b, g);
			}
			F().info('navigation', 'Removing iframe query string before navigation:', b.search);
			var e = b.href,
				g = '' + b.origin + b.pathname + b.hash;
			a.history.replaceState(null, '', g);
			'_blank' === c
				? a.setTimeout(d, 0)
				: a.addEventListener('pageshow', function k(b) {
						b.persisted && (d(), a.removeEventListener('pageshow', k));
					});
		}
		function Jh(a, b, c, d) {
			if (T(a.ampdoc.win).isIe()) {
				var e = c.hash.substring(1),
					g = a.ampdoc.getElementById(e);
				g && (/^(?:a|select|input|button|textarea)$/i.test(g.tagName) || (g.tabIndex = -1), Pb(g));
			}
			b.preventDefault();
			if (!a.Vd) {
				var h = c.hash.slice(1),
					l = null;
				if (h) {
					var k = String(h).replace(ob, pb);
					l = a.oa.getElementById(h) || a.oa.querySelector('a[name="' + k + '"]');
				}
				c.hash != d.hash
					? a.O.replaceStateForTarget(c.hash).then(function() {
							Lh(a, l, h);
						})
					: Lh(a, l, h);
			}
		}
		f.registerAnchorMutator = function(a, b) {
			this.Ne.enqueue(a, b);
		};
		f.registerNavigateToMutator = function(a, b) {
			this.Sf.enqueue(a, b);
		};
		function Lh(a, b, c) {
			b
				? (a.H.scrollIntoView(b),
					U(a.ampdoc.win).delay(function() {
						return a.H.scrollIntoView(b);
					}, 1))
				: F().warn('navigation', 'failed to find element with id=' + c + ' or a[name=' + c + ']');
		}
		function Fh(a, b) {
			return Tc(a.eg, 'url').parse(b);
		}
		f.viewerInterceptsNavigation = function(a, b) {
			var c = this.h.hasCapability('interceptNavigation'),
				d = this.ampdoc.getRootNode().documentElement.hasAttribute('allow-navigation-interception');
			if (!c || !d || (!this.Za && !this.Gf)) return !1;
			this.h.sendMessage('navigateTo', K({ url: a, requestedBy: b }));
			return !0;
		};
		function Hh(a) {
			return '' + a.origin + a.pathname + a.search;
		}
		function Mh(a) {
			pd(a).then(function(b) {
				b && a.getRootNode().addEventListener('submit', Nh, !0);
			});
		}
		function Nh(a) {
			if (!a.defaultPrevented) {
				var b = a.target;
				if (b && 'FORM' == b.tagName) {
					(b.classList.contains('i-amphtml-form')
						? b.hasAttribute('amp-novalidate')
						: b.hasAttribute('novalidate')) ||
						!b.checkValidity ||
						b.checkValidity() ||
						a.preventDefault();
					for (var c = b.elements, d = 0; d < c.length; d++)
						G(
							!c[d].name || '__amp_source_origin' != c[d].name,
							'Illegal input name, %s found: %s',
							'__amp_source_origin',
							c[d]
						);
					c = b.getAttribute('action');
					var e = b.getAttribute('action-xhr');
					d = (b.getAttribute('method') || 'GET').toUpperCase();
					e && (Ec(e, b, 'action-xhr'), G(!O(e), 'form action-xhr should not be on AMP CDN: %s', b), Mc(e));
					c && (Ec(c, b, 'action'), G(!O(c), 'form action should not be on AMP CDN: %s', b), Mc(c));
					'GET' == d
						? G(e || c, 'form action-xhr or action attribute is required for method=GET: %s', b)
						: 'POST' == d &&
							(c && C().error('form', 'action attribute is invalid for method=POST: %s', b),
							e ||
								(a.preventDefault(),
								G(
									!1,
									'Only XHR based (via action-xhr attribute) submissions are support for POST requests. %s',
									b
								)));
					(c = b.getAttribute('target'))
						? G(
								'_blank' == c || '_top' == c,
								'form target=%s is invalid can only be _blank or _top: %s',
								c,
								b
							)
						: b.setAttribute('target', '_top');
					e &&
						(a.preventDefault(),
						a.stopImmediatePropagation(),
						Tc(b, 'action').execute(b, 'submit', null, b, b, a, 3));
				}
			}
		}
		function Y() {
			this.ba = null;
		}
		f = Y.prototype;
		f.add = function(a) {
			var b = this;
			this.ba || (this.ba = []);
			this.ba.push(a);
			return function() {
				b.remove(a);
			};
		};
		f.remove = function(a) {
			this.ba && ((a = this.ba.indexOf(a)), -1 < a && this.ba.splice(a, 1));
		};
		f.removeAll = function() {
			this.ba && (this.ba.length = 0);
		};
		f.fire = function(a) {
			if (this.ba) for (var b = this.ba, c = 0; c < b.length; c++) (0, b[c])(a);
		};
		f.getHandlerCount = function() {
			return this.ba ? this.ba.length : 0;
		};
		var Oh = { attributes: !0, attributeFilter: [ 'hidden' ], subtree: !0 };
		function Ph(a, b) {
			this.W = b || a.getRootNode();
			this.w = (this.W.ownerDocument || this.W).defaultView;
			this.gb = this.ma = null;
		}
		Ph.installInEmbedWindow = function(a, b) {
			Zc(a, 'hidden-observer', new Ph(b, a.document));
		};
		Ph.prototype.add = function(a) {
			var b = this;
			Qh(this);
			var c = this.gb.add(a);
			return function() {
				c();
				0 === b.gb.getHandlerCount() && b.dispose();
			};
		};
		function Qh(a) {
			if (!a.ma) {
				a.gb = new Y();
				var b = new a.w.MutationObserver(function(b) {
					b && a.gb.fire(b);
				});
				a.ma = b;
				b.observe(a.W, Oh);
			}
		}
		Ph.prototype.dispose = function() {
			this.ma && (this.ma.disconnect(), this.gb.removeAll(), (this.gb = this.ma = null));
		};
		function Rh(a) {
			try {
				return a.state;
			} catch (b) {
				return null;
			}
		}
		function Sh(a, b) {
			this.C = a;
			this.R = U(a.win);
			this.o = b;
			this.B = 0;
			this.Ra = [];
			this.F = [];
			this.o.setOnStateUpdated(this.fa.bind(this));
		}
		f = Sh.prototype;
		f.cleanup = function() {
			this.o.cleanup();
		};
		f.push = function(a, b) {
			var c = this;
			return Th(
				this,
				function() {
					return c.o.push(b).then(function(b) {
						c.fa(b);
						a && (c.Ra[b.stackIndex] = a);
						return b.stackIndex;
					});
				},
				'push'
			);
		};
		f.pop = function(a) {
			var b = this;
			return Th(
				this,
				function() {
					return b.o.pop(a).then(function(a) {
						b.fa(a);
					});
				},
				'pop'
			);
		};
		f.replace = function(a) {
			var b = this;
			return Th(
				this,
				function() {
					return b.o.replace(a);
				},
				'replace'
			);
		};
		f.get = function() {
			var a = this;
			return Th(
				this,
				function() {
					return a.o.get();
				},
				'get'
			);
		};
		f.goBack = function(a) {
			var b = this;
			return Th(
				this,
				function() {
					return 0 >= b.B && !a
						? x()
						: b.o.pop(b.B).then(function(a) {
								b.fa(a);
							});
				},
				'goBack'
			);
		};
		f.replaceStateForTarget = function(a) {
			var b = this,
				c = this.C.win.location.hash;
			return this.push(function() {
				b.C.win.location.replace(c || '#');
			}).then(function() {
				b.o.replaceStateForTarget(a);
			});
		};
		f.getFragment = function() {
			return this.o.getFragment();
		};
		f.updateFragment = function(a) {
			'#' == a[0] && (a = a.substr(1));
			return this.o.updateFragment(a);
		};
		f.fa = function(a) {
			this.B = a.stackIndex;
			Uh(this, a);
		};
		function Uh(a, b) {
			if (!(a.B >= a.Ra.length - 1)) {
				for (var c = [], d = a.Ra.length - 1; d > a.B; d--) a.Ra[d] && (c.push(a.Ra[d]), (a.Ra[d] = void 0));
				a.Ra.splice(a.B + 1);
				if (0 < c.length)
					for (d = { nb: 0 }; d.nb < c.length; d = { nb: d.nb }, d.nb++)
						a.R.delay(
							(function(a) {
								return function() {
									return c[a.nb](b);
								};
							})(d),
							1
						);
			}
		}
		function Th(a, b, c) {
			var d = new L(),
				e = d.promise;
			a.F.push({
				callback: b,
				resolve: d.resolve,
				reject: d.reject,
				trace: Error('history trace for ' + c + ': ')
			});
			1 == a.F.length && Vh(a);
			return e;
		}
		function Vh(a) {
			if (0 != a.F.length) {
				var b = a.F[0];
				try {
					var c = b.callback();
				} catch (d) {
					c = Promise.reject(d);
				}
				c
					.then(
						function(a) {
							b.resolve(a);
						},
						function(a) {
							F().error('History', 'failed to execute a task:', a);
							b.trace && ((b.trace.message += a), F().error('History', b.trace));
							b.reject(a);
						}
					)
					.then(function() {
						a.F.splice(0, 1);
						Vh(a);
					});
			}
		}
		function Wh(a) {
			var b = this;
			this.win = a;
			this.R = U(a);
			a = this.win.history;
			this.Sa = a.length - 1;
			var c = Rh(a);
			c && void 0 !== c['AMP.History'] && (this.Sa = Math.min(c['AMP.History'], this.Sa));
			this.B = this.Sa;
			this.fa = null;
			this.Yh = 'state' in a;
			this.kb = Xh(this, this.B);
			if (a.pushState && a.replaceState) {
				this.Fc = a.originalPushState || a.pushState.bind(a);
				this.Kb = a.originalReplaceState || a.replaceState.bind(a);
				var d = function(a, c, d) {
					b.kb = a;
					b.Fc(a, c, d || null);
				};
				var e = function(a, c, d) {
					b.kb = a;
					void 0 !== d ? b.Kb(a, c, d) : b.Kb(a, c);
				};
				a.originalPushState || (a.originalPushState = this.Fc);
				a.originalReplaceState || (a.originalReplaceState = this.Kb);
			} else
				(d = function(a) {
					b.kb = a;
				}),
					(e = function(a) {
						b.kb = a;
					});
			this.Gh = d;
			this.Qc = e;
			try {
				this.Qc(Xh(this, this.B, !0));
			} catch (g) {
				F().error('History', 'Initial replaceState failed: ' + g.message);
			}
			a.pushState = this.Cf.bind(this);
			a.replaceState = this.Pd.bind(this);
			this.Mc = function(a) {
				a = a.state;
				F().fine('History', 'popstate event: ' + b.win.history.length + ', ' + JSON.stringify(a));
				a = Yh(b);
				F().fine('History', 'history event: ' + b.win.history.length + ', ' + JSON.stringify(a));
				var c = a ? a['AMP.History'] : void 0,
					d = b.B,
					e = b.kd;
				b.kd = void 0;
				d > b.win.history.length - 2 && ((d = b.win.history.length - 2), b.za(Zh(a, { stackIndex: d })));
				d = void 0 == c ? d + 1 : c < b.win.history.length ? c : b.win.history.length - 1;
				a || (a = {});
				a['AMP.History'] = d;
				b.Qc(a, void 0, void 0);
				d != b.B && b.za(Zh(a, { stackIndex: d }));
				d < b.Sa && (b.Sa = d);
				e && e.resolve();
			};
			this.win.addEventListener('popstate', this.Mc);
		}
		f = Wh.prototype;
		f.cleanup = function() {
			this.Fc && (this.win.history.pushState = this.Fc);
			this.Kb && (this.win.history.replaceState = this.Kb);
			this.win.removeEventListener('popstate', this.Mc);
		};
		function Xh(a, b, c) {
			a = I(c ? Yh(a) : void 0);
			a['AMP.History'] = b;
			return a;
		}
		f.setOnStateUpdated = function(a) {
			this.fa = a;
		};
		f.push = function(a) {
			var b = this;
			return $h(this, function() {
				var c = Zh(Yh(b), a || {});
				b.Cf(c, void 0, c.fragment ? '#' + c.fragment : void 0);
				return nb(function() {
					return Zh(c, { stackIndex: b.B });
				});
			});
		};
		f.pop = function(a) {
			var b = this;
			a = Math.max(a, this.Sa);
			return $h(this, function() {
				return ai(b, b.B - a + 1);
			}).then(function(a) {
				return Zh(Yh(b), { stackIndex: a });
			});
		};
		f.replace = function(a) {
			var b = this;
			a = void 0 === a ? {} : a;
			return $h(this, function() {
				var c = Zh(Yh(b), a || {}),
					d = (c.url || '').replace(/#.*/, ''),
					e = c.fragment ? '#' + c.fragment : '';
				b.Pd(c, c.title, d || e ? d + e : void 0);
				return nb(function() {
					return Zh(c, { stackIndex: b.B });
				});
			});
		};
		f.get = function() {
			var a = this;
			return nb(function() {
				return Zh(Yh(a), { stackIndex: a.B });
			});
		};
		f.backTo = function(a) {
			var b = this;
			a = Math.max(a, this.Sa);
			return $h(this, function() {
				return ai(b, b.B - a);
			});
		};
		function Yh(a) {
			return a.Yh ? Rh(a.win.history) : a.kb;
		}
		function $h(a, b) {
			return a.kd ? a.kd.promise.then(b, b) : b();
		}
		function bi(a) {
			var b = new L(),
				c = b.resolve,
				d = b.reject;
			b = a.R.timeoutPromise(500, b.promise);
			a.kd = { promise: b, resolve: c, reject: d };
			return b;
		}
		function ai(a, b) {
			if (0 >= b) return Promise.resolve(a.B);
			a.kb = Xh(a, a.B - b);
			var c = bi(a);
			a.win.history.go(-b);
			return c.then(function() {
				return Promise.resolve(a.B);
			});
		}
		f.Cf = function(a, b, c) {
			a || (a = {});
			var d = this.B + 1;
			a['AMP.History'] = d;
			this.Gh(a, b, c);
			d != this.win.history.length - 1 && ((d = this.win.history.length - 1), (a['AMP.History'] = d), this.Qc(a));
			a = Zh(a, { stackIndex: d });
			this.za(a);
		};
		f.replaceStateForTarget = function(a) {
			var b = this;
			$h(this, function() {
				b.win.removeEventListener('popstate', b.Mc);
				try {
					b.win.location.replace(a);
				} finally {
					b.win.addEventListener('popstate', b.Mc);
				}
				b.Pd();
				return x();
			});
		};
		f.Pd = function(a, b, c) {
			a || (a = {});
			var d = Math.min(this.B, this.win.history.length - 1);
			a['AMP.History'] = d;
			this.Qc(a, b, c);
			a = Zh(a, { stackIndex: d });
			this.za(a);
		};
		f.za = function(a) {
			a.stackIndex = Math.min(a.stackIndex, this.win.history.length - 1);
			this.B != a.stackIndex &&
				(F().fine('History', 'stack index changed: ' + this.B + ' -> ' + a.stackIndex),
				(this.B = a.stackIndex),
				this.fa && this.fa(a));
		};
		f.getFragment = function() {
			var a = this.win.location.hash;
			a = a.substr(1);
			return Promise.resolve(a);
		};
		f.updateFragment = function(a) {
			return this.replace({ fragment: a });
		};
		function Zh(a, b) {
			var c = Object.assign({}, (a && a.data) || {}, b.data || {});
			return Object.assign({}, a || {}, b, { data: c });
		}
		function ci(a, b) {
			var c = this;
			this.win = a;
			this.h = b;
			this.B = 0;
			this.fa = null;
			this.bi = this.h.onMessage('historyPopped', function(a) {
				void 0 !== a.newStackIndex && (a.stackIndex = a.newStackIndex);
				di(a) ? c.za(a) : F().warn('History', 'Ignored unexpected "historyPopped" data:', a);
			});
		}
		f = ci.prototype;
		f.replaceStateForTarget = function(a) {
			this.win.location.replace(a);
		};
		f.cleanup = function() {
			this.bi();
		};
		f.setOnStateUpdated = function(a) {
			this.fa = a;
		};
		function ei(a, b, c) {
			if (di(a)) return a;
			F().warn('History', 'Ignored unexpected "%s" data:', c, a);
			return b;
		}
		function di(a) {
			return !!a && void 0 !== a.stackIndex;
		}
		f.push = function(a) {
			var b = this,
				c = Object.assign({}, { stackIndex: this.B + 1 }, a || {});
			return this.h.sendMessageAwaitResponse('pushHistory', c).then(function(a) {
				a = ei(a, c, 'pushHistory');
				b.za(a);
				return a;
			});
		};
		f.pop = function(a) {
			var b = this;
			if (a > this.B) return this.get();
			a = K({ stackIndex: this.B });
			return this.h.sendMessageAwaitResponse('popHistory', a).then(function(a) {
				var c = K({ stackIndex: b.B - 1 });
				a = ei(a, c, 'popHistory');
				b.za(a);
				return a;
			});
		};
		f.replace = function(a) {
			var b = this;
			if (a && a.url) {
				if (!this.h.hasCapability('fullReplaceHistory')) {
					var c = K({ stackIndex: this.B });
					return Promise.resolve(c);
				}
				var d = a.url.replace(/#.*/, '');
				a.url = d;
			}
			var e = Object.assign({}, { stackIndex: this.B }, a || {});
			return this.h.sendMessageAwaitResponse('replaceHistory', e, !0).then(function(a) {
				a = ei(a, e, 'replaceHistory');
				b.za(a);
				return a;
			});
		};
		f.get = function() {
			return Promise.resolve({ data: void 0, fragment: '', stackIndex: this.B, title: '' });
		};
		f.za = function(a) {
			var b = a.stackIndex;
			this.B != b &&
				(F().fine('History', 'stackIndex: ' + this.B + ' -> ' + b), (this.B = b), this.fa && this.fa(a));
		};
		f.getFragment = function() {
			return this.h.hasCapability('fragment')
				? this.h.sendMessageAwaitResponse('getFragment', void 0, !0).then(function(a) {
						if (!a) return '';
						'#' == a[0] && (a = a.substr(1));
						return a;
					})
				: Promise.resolve('');
		};
		f.updateFragment = function(a) {
			return this.h.hasCapability('fragment')
				? this.h.sendMessageAwaitResponse('replaceHistory', K({ fragment: a }), !0)
				: x();
		};
		function fi(a) {
			var b = V(a);
			b.isOvertakeHistory() || a.win.__AMP_TEST_IFRAME
				? (b = new ci(a.win, b))
				: (Q(a.win, 'global-history-binding', Wh), (b = S(a.win, 'global-history-binding')));
			return new Sh(a, b);
		}
		var gi = [];
		function hi(a) {
			Re.call(this, a);
			gi.push(this);
		}
		m(hi, Re);
		hi.prototype.getLayoutPriority = function() {
			return 0;
		};
		hi.prototype.isLayoutSupported = function() {
			return !0;
		};
		hi.prototype.reconstructWhenReparented = function() {
			return !1;
		};
		var ii = { 0: 'cld', 2: 'adld' };
		function ji(a, b) {
			this.w = a;
			this.Lc = ad(a);
			this.jc = this.ic = null;
			this.pf = !1;
			this.rc = ii[b];
		}
		ji.prototype.enterViewport = function() {
			this.rc && !this.ic && ((this.ic = this.w.Date.now()), ki(this));
		};
		ji.prototype.startLayout = function() {
			this.rc && !this.jc && ((this.jc = this.w.Date.now()), ki(this));
		};
		function ki(a) {
			if (a.Lc && a.Lc.isPerformanceTrackingOn() && !a.pf && a.ic && a.jc) {
				var b = a.w.Math.max(a.jc - a.ic, 0);
				a.rc && a.Lc.tickDelta(a.rc, b);
				a.Lc.throttledFlush();
				a.pf = !0;
			}
		}
		function li(a, b, c) {
			b.__AMP__RESOURCE = this;
			this.eh = a;
			this.element = b;
			this.debugid = b.tagName.toLowerCase() + '#' + a;
			this.hostWin = b.ownerDocument.defaultView;
			this.j = c;
			this.lh = b.hasAttribute('placeholder');
			this.Bb = !1;
			this.hb = void 0;
			this.D = b.isBuilt() ? 1 : 0;
			0 == this.D && b.isBuilding() && this.build();
			this.se = -1;
			this.ea = 0;
			this.Kf = null;
			this.qc = !1;
			this.da = fc(-1e4, -1e4, 0, 0);
			this.Sd = null;
			this.Zd = !1;
			this.$a = this.pa = null;
			this.re = void 0;
			this.Nf = !1;
			a = new L();
			this.ph = a.promise;
			this.ee = a.resolve;
			this.Ma = c.isIntersectionExperimentOn();
			this.Ob = null;
		}
		function Z(a) {
			return a.__AMP__RESOURCE;
		}
		f = li.prototype;
		f.getId = function() {
			return this.eh;
		};
		f.updateOwner = function(a) {
			this.hb = a;
		};
		f.getOwner = function() {
			if (void 0 === this.hb) {
				for (var a = this.element; a; a = a.parentElement)
					if (a.__AMP__OWNER) {
						this.hb = a.__AMP__OWNER;
						break;
					}
				void 0 === this.hb && (this.hb = null);
			}
			return this.hb;
		};
		f.hasOwner = function() {
			return !!this.getOwner();
		};
		f.getLayoutPriority = function() {
			return -1 != this.se ? this.se : this.element.getLayoutPriority();
		};
		f.updateLayoutPriority = function(a) {
			this.se = a;
		};
		f.getState = function() {
			return this.D;
		};
		f.isBuilt = function() {
			return this.element.isBuilt();
		};
		f.isBuilding = function() {
			return this.Bb;
		};
		f.whenBuilt = function() {
			return this.element.signals().whenSignal('res-built');
		};
		f.build = function() {
			var a = this;
			if (this.Bb || !this.element.isUpgraded()) return null;
			this.Bb = !0;
			return this.element.build().then(
				function() {
					a.Bb = !1;
					a.Ma && a.hasBeenMeasured() ? ((a.D = 2), a.element.onMeasure(!0)) : (a.D = 1);
					a.element.signals().signal('res-built');
				},
				function(b) {
					a.maybeReportErrorOnBuildFailure(b);
					a.Bb = !1;
					a.element.signals().rejectSignal('res-built', b);
					throw b;
				}
			);
		};
		f.maybeReportErrorOnBuildFailure = function(a) {
			Df(a) || F().error('Resource', 'failed to build:', this.debugid, a);
		};
		f.applySizesAndMediaQuery = function() {
			this.element.applySizesAndMediaQuery();
		};
		f.changeSize = function(a, b, c) {
			this.element.applySize(a, b, c);
			this.requestMeasure();
		};
		f.overflowCallback = function(a, b, c, d) {
			a && (this.re = { height: b, width: c, margins: d });
			this.element.overflowCallback(a, b, c, d);
		};
		f.resetPendingChangeSize = function() {
			this.re = void 0;
		};
		f.getPendingChangeSize = function() {
			return this.re;
		};
		f.getUpgradeDelayMs = function() {
			return this.element.getUpgradeDelayMs();
		};
		f.premeasure = function(a) {
			this.Ob = a;
		};
		f.measure = function(a) {
			a = void 0 === a ? !1 : a;
			if (
				!(this.lh && this.element.parentElement && M(this.element.parentElement.tagName, 'AMP-')) ||
				'__AMP__RESOURCE' in this.element.parentElement
			)
				if (this.element.ownerDocument && this.element.ownerDocument.defaultView) {
					this.Zd = !1;
					var b = this.da;
					a ? (mi(this, this.Ob), (this.Ob = null)) : mi(this);
					var c = this.da,
						d = !(b.width == c.width && b.height === c.height);
					(1 == this.D || b.top != c.top || d) &&
						this.element.isUpgraded() &&
						(1 == this.D
							? (this.D = 2)
							: (4 != this.D && 5 != this.D) || !this.element.isRelayoutNeeded() || (this.D = 2));
					this.hasBeenMeasured() || (this.Sd = c);
					this.element.updateLayoutBox(c, d);
				} else this.D = 1;
		};
		function mi(a, b) {
			var c = wd(a.element);
			a.da = c.getLayoutRect(a.element, b);
			var d = !1;
			if (c.supportsPositionFixed() && a.isDisplayed())
				for (var e = a.j.getAmpdoc().win, g = e.document.body, h = a.element; h && h != g; h = h.offsetParent) {
					if (h.isAlwaysFixed && h.isAlwaysFixed()) {
						d = !0;
						break;
					}
					if (c.isDeclaredFixed(h) && 'fixed' == se(e, h).position) {
						d = !0;
						break;
					}
				}
			if ((a.qc = d)) a.da = ic(a.da, -c.getScrollLeft(), -c.getScrollTop());
		}
		f.completeCollapse = function() {
			re(this.element, !1);
			this.da = fc(this.da.left, this.da.top, 0, 0);
			this.qc = !1;
			this.element.updateLayoutBox(this.getLayoutBox());
			var a = this.getOwner();
			a && a.collapsedCallback(this.element);
		};
		f.completeExpand = function() {
			re(this.element, !0);
			this.requestMeasure();
		};
		f.isMeasureRequested = function() {
			return this.Zd;
		};
		f.hasBeenMeasured = function() {
			return !!this.Sd;
		};
		f.hasBeenPremeasured = function() {
			return !!this.Ob;
		};
		f.requestMeasure = function() {
			this.Zd = !0;
		};
		f.getLayoutBox = function() {
			if (!this.qc) return this.da;
			var a = wd(this.element);
			return ic(this.da, a.getScrollLeft(), a.getScrollTop());
		};
		f.getPageLayoutBox = function() {
			return this.da;
		};
		f.getPageLayoutBoxAsync = function() {
			var a = this;
			return this.hasBeenMeasured()
				? nb(function() {
						return a.getPageLayoutBox();
					})
				: vd(this.hostWin).measurePromise(function() {
						a.measure();
						return a.getPageLayoutBox();
					});
		};
		f.getInitialLayoutBox = function() {
			return this.Sd || this.da;
		};
		f.isDisplayed = function(a) {
			a = void 0 === a ? !1 : a;
			var b = 'fluid' == this.element.getLayout(),
				c = a ? this.Ob : this.getLayoutBox(),
				d = 0 < c.height && 0 < c.width;
			return (b || d) && !!this.element.ownerDocument && !!this.element.ownerDocument.defaultView;
		};
		f.isFixed = function() {
			return this.qc;
		};
		f.overlaps = function(a) {
			var b = this.getLayoutBox();
			return b.top <= a.bottom && a.top <= b.bottom && b.left <= a.right && a.left <= b.right;
		};
		f.prerenderAllowed = function() {
			return this.element.prerenderAllowed();
		};
		f.isBuildRenderBlocking = function() {
			return this.element.isBuildRenderBlocking();
		};
		f.whenWithinViewport = function(a) {
			if (!this.isLayoutPending() || !0 === a) return x();
			var b = String(a);
			if (this.pa && this.pa[b]) return this.pa[b].promise;
			if (this.isWithinViewportRatio(a)) return x();
			this.pa = this.pa || {};
			this.pa[b] = new L();
			return this.pa[b].promise;
		};
		function ni(a) {
			if (a.pa) {
				var b = a.getDistanceViewportRatio(),
					c;
				for (c in a.pa) a.isWithinViewportRatio(parseFloat(c), b) && (a.pa[c].resolve(), delete a.pa[c]);
			}
		}
		f.getDistanceViewportRatio = function() {
			var a = wd(this.element).getRect(),
				b = this.getLayoutBox(),
				c = this.j.getScrollDirection(),
				d = 1,
				e = 0;
			if (a.right < b.left || a.left > b.right) return { distance: !1 };
			if (a.bottom < b.top) (e = b.top - a.bottom), -1 == c && (d = 2);
			else if (a.top > b.bottom) (e = a.top - b.bottom), 1 == c && (d = 2);
			else return { distance: !0 };
			return { distance: e, scrollPenalty: d, viewportHeight: a.height };
		};
		f.isWithinViewportRatio = function(a, b) {
			if ('boolean' === typeof a) return a;
			var c = b || this.getDistanceViewportRatio(),
				d = c.distance;
			return 'boolean' == typeof d ? d : d < c.viewportHeight * a / c.scrollPenalty;
		};
		f.renderOutsideViewport = function() {
			ni(this);
			return this.hasOwner() || this.isWithinViewportRatio(this.element.renderOutsideViewport());
		};
		f.idleRenderOutsideViewport = function() {
			return this.isWithinViewportRatio(this.element.idleRenderOutsideViewport());
		};
		f.layoutScheduled = function(a) {
			this.D = 3;
			this.element.layoutScheduleTime = a;
		};
		f.layoutCanceled = function() {
			this.D = this.hasBeenMeasured() ? 2 : 1;
		};
		f.startLayout = function() {
			var a = this;
			if (this.$a) return this.$a;
			if (4 == this.D) return x();
			if (5 == this.D) return Promise.reject(this.Kf);
			this.isDisplayed();
			if (3 != this.D) {
				var b = F().createError('startLayout called but not LAYOUT_SCHEDULED', 'currently: ', this.D);
				b.associatedElement = this.element;
				Bf(b);
				return Promise.reject(b);
			}
			if (0 < this.ea && !this.element.isRelayoutNeeded())
				return (
					F().fine('Resource', "layout canceled since it wasn't requested:", this.debugid, this.D),
					(this.D = 4),
					x()
				);
			F().fine('Resource', 'start layout:', this.debugid, 'count:', this.ea);
			this.ea++;
			this.D = 3;
			return (this.$a = new Promise(function(b, d) {
				vd(a.hostWin).mutate(function() {
					try {
						b(a.element.layoutCallback());
					} catch (e) {
						d(e);
					}
				});
			}).then(
				function() {
					return oi(a, !0);
				},
				function(b) {
					return oi(a, !1, b);
				}
			));
		};
		function oi(a, b, c) {
			a.ee && (a.ee(), (a.ee = null));
			a.$a = null;
			a.Nf = !0;
			a.D = b ? 4 : 5;
			a.Kf = c;
			if (b) F().fine('Resource', 'layout complete:', a.debugid);
			else return F().fine('Resource', 'loading failed:', a.debugid, c), Promise.reject(c);
		}
		f.isLayoutPending = function() {
			return 4 != this.D && 5 != this.D;
		};
		f.loadedOnce = function() {
			return this.ph;
		};
		f.hasLoadedOnce = function() {
			return this.Nf;
		};
		f.isInViewport = function() {
			var a = this.element.isInViewport();
			a && ni(this);
			return a;
		};
		f.setInViewport = function(a) {
			this.element.viewportCallback(a);
		};
		f.unlayout = function() {
			0 != this.D &&
				1 != this.D &&
				(this.setInViewport(!1),
				this.element.unlayoutCallback() &&
					(this.element.togglePlaceholder(!0), (this.D = this.Ma ? 2 : 1), (this.ea = 0), (this.$a = null)));
		};
		f.getTaskId = function(a) {
			return this.debugid + '#' + a;
		};
		f.pause = function() {
			this.element.pauseCallback();
			this.element.unlayoutOnPause() && this.unlayout();
		};
		f.pauseOnRemove = function() {
			this.element.pauseCallback();
		};
		f.resume = function() {
			this.element.resumeCallback();
		};
		f.unload = function() {
			this.pause();
			this.unlayout();
		};
		f.disconnect = function() {
			delete this.element.__AMP__RESOURCE;
			this.element.disconnect(!0);
		};
		function pi() {
			this.Ea = I();
			this.ga = null;
		}
		f = pi.prototype;
		f.get = function(a) {
			a = this.Ea[a];
			return null == a ? null : a;
		};
		f.whenSignal = function(a) {
			var b = this.ga && this.ga[a];
			if (!b) {
				var c = this.Ea[a];
				null != c
					? (b = { promise: 'number' == typeof c ? Promise.resolve(c) : Promise.reject(c) })
					: ((c = new L()), (b = { promise: c.promise, resolve: c.resolve, reject: c.reject }));
				this.ga || (this.ga = I());
				this.ga[a] = b;
			}
			return b.promise;
		};
		f.signal = function(a, b) {
			if (null == this.Ea[a]) {
				var c = void 0 == b ? Date.now() : b;
				this.Ea[a] = c;
				(a = this.ga && this.ga[a]) && a.resolve && (a.resolve(c), (a.resolve = void 0), (a.reject = void 0));
			}
		};
		f.rejectSignal = function(a, b) {
			null == this.Ea[a] &&
				((this.Ea[a] = b),
				(a = this.ga && this.ga[a]) &&
					a.reject &&
					(a.reject(b), a.promise.catch(function() {}), (a.resolve = void 0), (a.reject = void 0)));
		};
		f.reset = function(a) {
			this.Ea[a] && delete this.Ea[a];
			var b = this.ga && this.ga[a];
			b && !b.resolve && delete this.ga[a];
		};
		function qi(a, b) {
			return sd(a.win).installExtensionForDoc(a, 'amp-loader').then(function() {
				return jd(b, 'loader', 'amp-loader');
			});
		}
		function ri(a, b, c, d, e) {
			e = void 0 === e ? a.win.Date.now() : e;
			var g = b.ownerDocument.createElement('div');
			qi(a, b).then(function(h) {
				var l = a.win.Date.now() - e;
				h.initializeLoader(b, g, l, c, d);
			});
			return g;
		}
		function si(a, b, c) {
			var d = this;
			this.R = U(a);
			this.dh = b;
			this.Pg = c || 0;
			this.ua = -1;
			this.me = 0;
			this.Qa = !1;
			this.Hg = function() {
				d.Kc();
			};
		}
		si.prototype.isPending = function() {
			return -1 != this.ua;
		};
		si.prototype.schedule = function(a) {
			a = a || this.Pg;
			this.Qa && 10 > a && (a = 10);
			var b = Date.now() + a;
			return !this.isPending() || -10 > b - this.me
				? (this.cancel(), (this.me = b), (this.ua = this.R.delay(this.Hg, a)), !0)
				: !1;
		};
		si.prototype.Kc = function() {
			this.ua = -1;
			this.me = 0;
			this.Qa = !0;
			this.dh();
			this.Qa = !1;
		};
		si.prototype.cancel = function() {
			this.isPending() && (this.R.cancel(this.ua), (this.ua = -1));
		};
		var ti = Date.now();
		function ui(a, b) {
			var c = a.split(',');
			G(0 < c.length, 'sizes has to have at least one size');
			var d = [];
			c.forEach(function(a) {
				a = a.replace(/\s+/g, ' ').trim();
				if (0 != a.length) {
					var c,
						e = !1;
					if (')' == a.charAt(a.length - 1)) {
						e = !0;
						var l = 1;
						for (c = a.length - 2; 0 <= c; c--) {
							var k = a.charAt(c);
							'(' == k ? l-- : ')' == k && l++;
							if (0 == l) break;
						}
						var n = c - 1;
						if (0 < c)
							for (
								c--;
								0 <= c &&
								((k = a.charAt(c)),
								'%' == k ||
									'-' == k ||
									'_' == k ||
									('a' <= k && 'z' >= k) ||
									('A' <= k && 'Z' >= k) ||
									('0' <= k && '9' >= k));
								c--
							);
						G(c < n, 'Invalid CSS function in "%s"', a);
					} else
						for (
							c = a.length - 2;
							0 <= c &&
							((k = a.charAt(c)),
							'%' == k ||
								'.' == k ||
								('a' <= k && 'z' >= k) ||
								('A' <= k && 'Z' >= k) ||
								('0' <= k && '9' >= k));
							c--
						);
					if (0 <= c) {
						var r = a.substring(0, c + 1).trim();
						var u = a.substring(c + 1).trim();
					} else (u = a), (r = void 0);
					d.push({ mediaQuery: r, size: e ? u : b ? Ee(u) : De(u) });
				}
			});
			return new vi(d);
		}
		function vi(a) {
			G(0 < a.length, 'SizeList must have at least one option');
			this.Vh = a;
			for (var b = 0; b < a.length; b++) {
				var c = a[b];
				b < a.length - 1
					? G(c.mediaQuery, 'All options except for the last must have a media condition')
					: G(!c.mediaQuery, 'The last option must not have a media condition');
			}
		}
		vi.prototype.select = function(a) {
			for (var b = this.Vh, c = b.length - 1, d = 0; d < c; d++) {
				var e = b[d];
				if (a.matchMedia(e.mediaQuery).matches) return e.size;
			}
			return b[c].size;
		};
		var wi = /nochunking=1/.test(self.location.hash),
			xi = x();
		function yi(a) {
			R(a, 'chunk', zi);
			return bd(a, 'chunk');
		}
		function Ai(a, b, c) {
			if (wi) xi.then(b);
			else {
				var d = yi(a.documentElement || a);
				d.runForStartup(b);
				c &&
					d.runForStartup(function() {
						d.Se = !0;
					});
			}
		}
		function Bi(a, b) {
			wi ? xi.then(b) : yi(a).run(b, 10);
		}
		function Ci(a) {
			this.state = 'not_run';
			this.Kd = a;
		}
		function Di(a, b) {
			if ('run' != a.state) {
				a.state = 'run';
				try {
					a.Kd(b);
				} catch (c) {
					throw (a.Vf(), c);
				}
			}
		}
		Ci.prototype.Vf = function() {};
		Ci.prototype.Df = function() {
			return !1;
		};
		Ci.prototype.wg = function() {
			return !1;
		};
		function Ei(a, b, c) {
			Ci.call(this, a);
			this.hf = c;
		}
		m(Ei, Ci);
		Ei.prototype.Vf = function() {
			lf(self.document);
		};
		Ei.prototype.Df = function() {
			return this.hf.ampdoc.isVisible();
		};
		Ei.prototype.wg = function() {
			return this.hf.kf;
		};
		function zi(a) {
			var b = this;
			this.ampdoc = a;
			this.w = a.win;
			this.L = new zh();
			this.Ue = this.rf.bind(this);
			this.Ya = 0;
			this.Sc = !1;
			this.Se = this.w.document.documentElement.hasAttribute('i-amphtml-no-boilerplate');
			this.w.addEventListener('message', function(a) {
				'amp-macro-task' == a.data && b.rf(null);
			});
			this.kf = !1;
			gd(Yc(a), 'viewer').then(function() {
				b.kf = !0;
			});
			a.onVisibilityChanged(function() {
				a.isVisible() && b.xa();
			});
		}
		zi.prototype.run = function(a, b) {
			a = new Ci(a);
			this.L.enqueue(a, b);
			this.xa();
		};
		zi.prototype.runForStartup = function(a) {
			a = new Ei(a, this.w, this);
			this.L.enqueue(a, Number.POSITIVE_INFINITY);
			this.xa();
		};
		function Fi(a, b) {
			for (var c = a.L.peek(); c && 'not_run' !== c.state; ) a.L.dequeue(), (c = a.L.peek());
			c && b && a.L.dequeue();
			return c;
		}
		zi.prototype.rf = function(a) {
			var b = this,
				c = Fi(this, !0);
			if (!c) return (this.Sc = !1), (this.Ya = 0), !1;
			try {
				var d = Date.now();
				Di(c, a);
			} finally {
				xi.then().then().then().then().then().then().then().then().then(function() {
					b.Sc = !1;
					b.Ya += Date.now() - d;
					F().fine('CHUNK', c.Kd.displayName || c.Kd.name, 'Chunk duration', Date.now() - d, b.Ya);
					b.xa();
				});
			}
			return !0;
		};
		function Gi(a) {
			a.Se && 5 < a.Ya
				? ((a.Ya = 0), Hi(a))
				: xi.then(function() {
						a.Ue(null);
					});
		}
		zi.prototype.xa = function() {
			if (!this.Sc) {
				var a = Fi(this);
				a &&
					(a.Df()
						? ((this.Sc = !0), Gi(this))
						: a.wg() && this.w.requestIdleCallback ? Ii(this.w, this.Ue) : Hi(this));
			}
		};
		function Hi(a) {
			a.w.postMessage('amp-macro-task', '*');
		}
		function Ii(a, b) {
			function c(e) {
				if (15 > e.timeRemaining()) {
					var g = 2e3 - (Date.now() - d);
					0 >= g || e.didTimeout
						? (F().fine('CHUNK', 'Timed out', 2e3, e.didTimeout), b(e))
						: (F().fine('CHUNK', 'Rescheduling with', g, e.timeRemaining()),
							a.requestIdleCallback(c, { timeout: g }));
				} else F().fine('CHUNK', 'Running idle callback with ', 15), b(e);
			}
			var d = Date.now();
			a.requestIdleCallback(c, { timeout: 2e3 });
		}
		var Ji = [ '<div class="i-amphtml-loading-container i-amphtml-fill-content amp-hidden"></div>' ],
			Ki;
		function Li(a) {
			function b() {
				return c.apply(this, arguments) || this;
			}
			var c = Mi(a);
			m(b, c);
			return b;
		}
		function Mi(a) {
			function b() {
				var a = c.call(this) || this;
				a.createdCallback();
				return a;
			}
			if (a.__AMP_BASE_CE_CLASS) return a.__AMP_BASE_CE_CLASS;
			var c = a.HTMLElement;
			m(b, c);
			b.prototype.createdCallback = function() {
				this.pc = this.cf = !1;
				this.ec = null;
				this.readyState = 'loading';
				this.everAttached = !1;
				this.j = this.C = null;
				this.layout_ = 'nodisplay';
				this.Mf = this.wc = -1;
				this.ea = 0;
				this.Mb = this.Fb = this.Wd = !1;
				this.mc = this.Vc = this.Ac = void 0;
				this.warnOnMissingOverflow = !0;
				this.xc = this.fe = this.sizerElement = void 0;
				this.ge = this.Na = null;
				this.layoutScheduleTime = this.na = void 0;
				this.implementation_ = new (a.__AMP_EXTENDED_ELEMENTS && a.__AMP_EXTENDED_ELEMENTS[this.localName])(
					this
				);
				this.lb = 1;
				this.tg = 0;
				this.Eb = this.Ka = void 0;
				this.K = new pi();
				var b = ad(a);
				this.Xf = b && b.isPerformanceTrackingOn();
				this.de = null;
				this.__AMP_UPG_RES && (this.__AMP_UPG_RES(this), delete this.__AMP_UPG_RES, delete this.__AMP_UPG_PRM);
			};
			b.prototype.signals = function() {
				return this.K;
			};
			b.prototype.getAmpDoc = function() {
				return this.C;
			};
			b.prototype.getResources = function() {
				return this.j;
			};
			b.prototype.isUpgraded = function() {
				return 2 == this.lb;
			};
			b.prototype.whenUpgraded = function() {
				return this.K.whenSignal('upgraded');
			};
			b.prototype.upgrade = function(a) {
				this.Eb || 1 != this.lb || ((this.implementation_ = new a(this)), this.everAttached && this.qg());
			};
			b.prototype.getUpgradeDelayMs = function() {
				return this.tg;
			};
			b.prototype.Dd = function(b, c) {
				this.tg = a.Date.now() - c;
				this.lb = 2;
				this.implementation_ = b;
				this.classList.remove('amp-unresolved');
				this.classList.remove('i-amphtml-unresolved');
				this.implementation_.createdCallback();
				this.Dg();
				this.implementation_.layout_ = this.layout_;
				this.implementation_.firstAttachedCallback();
				this.Ca('amp:attached');
				this.getResources().upgraded(this);
				this.K.signal('upgraded');
			};
			b.prototype.Dg = function() {
				'nodisplay' == this.layout_ ||
					this.implementation_.isLayoutSupported(this.layout_) ||
					(G(
						this.getAttribute('layout'),
						'The element did not specify a layout attribute. Check https://amp.dev/documentation/guides-and-tutorials/develop/style_and_layout/control_layout and the respective element documentation for details.'
					),
					G(!1, 'Layout not supported: ' + this.layout_));
			};
			b.prototype.isBuilt = function() {
				return this.cf;
			};
			b.prototype.whenBuilt = function() {
				return this.K.whenSignal('built');
			};
			b.prototype.getLayoutPriority = function() {
				this.isUpgraded();
				return this.implementation_.getLayoutPriority();
			};
			b.prototype.getLayoutWidth = function() {
				return this.wc;
			};
			b.prototype.getDefaultActionAlias = function() {
				this.isUpgraded();
				return this.implementation_.getDefaultActionAlias();
			};
			b.prototype.isBuilding = function() {
				return !!this.ec;
			};
			b.prototype.build = function() {
				var a = this;
				this.isUpgraded();
				return this.ec
					? this.ec
					: (this.ec = new Promise(function(b, c) {
							var d = a.Wg();
							d
								? kd(a, 'consentPolicyManager', 'amp-consent')
										.then(function(a) {
											return a ? a.whenPolicyUnblock(d) : !0;
										})
										.then(function(d) {
											d ? b(a.implementation_.buildCallback()) : c(Error('BLOCK_BY_CONSENT'));
										})
								: b(a.implementation_.buildCallback());
						}).then(
							function() {
								a.preconnect(!1);
								a.cf = !0;
								a.classList.remove('i-amphtml-notbuilt');
								a.classList.remove('amp-notbuilt');
								a.K.signal('built');
								a.Fb && a.rg(!0);
								a.Ka && U(a.ownerDocument.defaultView).delay(a.Qg.bind(a), 1);
								if (!a.getPlaceholder()) {
									var b = a.createPlaceholder();
									b && a.appendChild(b);
								}
							},
							function(b) {
								a.K.rejectSignal('built', b);
								Df(b) || Bf(b, a);
								throw b;
							}
						));
			};
			b.prototype.preconnect = function(a) {
				var b = this;
				a
					? this.implementation_.preconnectCallback(a)
					: Ai(this.getAmpDoc(), function() {
							var c = b.tagName;
							b.ownerDocument
								? b.ownerDocument.defaultView
									? b.implementation_.preconnectCallback(a)
									: F().error(c, 'preconnect without defaultView')
								: F().error(c, 'preconnect without ownerDocument');
						});
			};
			b.prototype.isAlwaysFixed = function() {
				return this.implementation_.isAlwaysFixed();
			};
			b.prototype.updateLayoutBox = function(a, b) {
				b = void 0 === b ? !1 : b;
				this.wc = a.width;
				this.Mf = a.height;
				if (this.isBuilt()) this.onMeasure(b);
			};
			b.prototype.onMeasure = function(a) {
				a = void 0 === a ? !1 : a;
				this.isBuilt();
				try {
					if ((this.implementation_.onLayoutMeasure(), a)) this.implementation_.onMeasureChanged();
				} catch (e) {
					Bf(e, this);
				}
			};
			b.prototype.wf = function() {
				void 0 !== this.sizerElement ||
					('responsive' !== this.layout_ && 'intrinsic' !== this.layout_) ||
					(this.sizerElement = this.querySelector('i-amphtml-sizer'));
				return this.sizerElement || null;
			};
			b.prototype.Mh = function(a) {
				if ('responsive' === this.layout_) X(a, 'paddingTop', '0');
				else if ('intrinsic' === this.layout_) {
					var b = a.querySelector('.i-amphtml-intrinsic-sizer');
					b && b.setAttribute('src', '');
				}
			};
			b.prototype.applySizesAndMediaQuery = function() {
				void 0 === this.Ac && (this.Ac = this.getAttribute('media') || null);
				this.Ac &&
					this.classList.toggle(
						'i-amphtml-hidden-by-media-query',
						!this.ownerDocument.defaultView.matchMedia(this.Ac).matches
					);
				if (void 0 === this.Vc) {
					var a = this.getAttribute('sizes');
					this.Vc = !this.hasAttribute('disable-inline-width') && a ? ui(a) : null;
				}
				this.Vc && X(this, 'width', this.Vc.select(this.ownerDocument.defaultView));
				void 0 === this.mc &&
					'responsive' === this.layout_ &&
					(this.mc = (a = this.getAttribute('heights')) ? ui(a, !0) : null);
				this.mc && (a = this.wf()) && X(a, 'paddingTop', this.mc.select(this.ownerDocument.defaultView));
			};
			b.prototype.applySize = function(a, b, c) {
				var d = this.wf();
				d &&
					((this.sizerElement = null),
					this.Mh(d),
					this.ie(function() {
						d && yb(d);
					}));
				void 0 !== a && X(this, 'height', a, 'px');
				void 0 !== b && X(this, 'width', b, 'px');
				c &&
					(null != c.top && X(this, 'marginTop', c.top, 'px'),
					null != c.right && X(this, 'marginRight', c.right, 'px'),
					null != c.bottom && X(this, 'marginBottom', c.bottom, 'px'),
					null != c.left && X(this, 'marginLeft', c.left, 'px'));
				this.gh() && this.Uh();
				this.dispatchCustomEvent('amp:size-changed');
			};
			b.prototype.connectedCallback = function() {
				void 0 === Ki && (Ki = 'content' in self.document.createElement('template'));
				Ki || void 0 !== this.Eb || (this.Eb = !!Fb(this, 'template'));
				if (!this.Eb && !this.pc && Ab(this)) {
					this.pc = !0;
					this.everAttached ||
						(this.classList.add('i-amphtml-element'),
						this.classList.add('i-amphtml-notbuilt'),
						this.classList.add('amp-notbuilt'));
					if (!this.C) {
						var a = this.ownerDocument.defaultView,
							b = qd(a).getAmpDoc(this);
						this.C = b;
						var c = this.tagName.toLowerCase();
						this.implementation_ instanceof hi &&
							!b.declaresExtension(c) &&
							sd(a).installExtensionForDoc(b, c);
					}
					this.j || (this.j = ud(this.C));
					this.getResources().add(this);
					if (this.everAttached) {
						var h = this.reconstructWhenReparented();
						h && this.bg();
						this.isUpgraded() && (h && this.getResources().upgraded(this), this.Ca('amp:attached'));
					} else {
						this.everAttached = !0;
						try {
							var l = T(this.ownerDocument.defaultView).isIe();
							l = void 0 === l ? !1 : l;
							var k = this.getAttribute('i-amphtml-layout');
							if (k) {
								var n = Ae(k);
								('responsive' != n && 'intrinsic' != n) || !this.firstElementChild
									? 'nodisplay' == n && (re(this, !1), (this.style.display = ''))
									: (this.sizerElement = this.querySelector('i-amphtml-sizer') || void 0) &&
										this.sizerElement.setAttribute('slot', 'i-amphtml-svc');
								var r = n;
							} else {
								var u = this.getAttribute('layout'),
									w = this.getAttribute('width'),
									y = this.getAttribute('height'),
									p = this.getAttribute('sizes'),
									q = this.getAttribute('heights'),
									H = u ? Ae(u) : null;
								G(void 0 !== H, 'Invalid "layout" value: %s, %s', u, this);
								var E = w && 'auto' != w ? Ce(w) : w;
								G(void 0 !== E, 'Invalid "width" value: %s, %s', w, this);
								var ja = y && 'fluid' != y ? Ce(y) : y;
								G(void 0 !== ja, 'Invalid "height" value: %s, %s', y, this);
								var na;
								if (!(na = (H && 'fixed' != H && 'fixed-height' != H) || (E && ja))) {
									var ca = this.tagName;
									ca = ca.toUpperCase();
									na = void 0 === xe[ca];
								}
								if (na) {
									var D = E;
									var W = ja;
								} else {
									var yc = this.tagName.toUpperCase();
									if (!xe[yc]) {
										var Yd = this.ownerDocument,
											Kl = yc.replace(/^AMP\-/, ''),
											jb = Yd.createElement(Kl);
										jb.controls = !0;
										qe(jb, {
											position: 'absolute',
											visibility: 'hidden'
										});
										Yd.body.appendChild(jb);
										xe[yc] = {
											width: (jb.offsetWidth || 1) + 'px',
											height: (jb.offsetHeight || 1) + 'px'
										};
										Yd.body.removeChild(jb);
									}
									var $g = xe[yc];
									D = E || 'fixed-height' == H ? E : $g.width;
									W = ja || $g.height;
								}
								var J = H
									? H
									: D || W
										? 'fluid' == W
											? 'fluid'
											: !W || (D && 'auto' != D)
												? W && D && (p || q) ? 'responsive' : 'fixed'
												: 'fixed-height'
										: 'container';
								('fixed' != J && 'fixed-height' != J && 'responsive' != J && 'intrinsic' != J) ||
									G(W, 'The "height" attribute is missing: %s', this);
								'fixed-height' == J &&
									G(!D || 'auto' == D, 'The "width" attribute must be missing or "auto": %s', this);
								('fixed' != J && 'responsive' != J && 'intrinsic' != J) ||
									G(
										D && 'auto' != D,
										'The "width" attribute must be present and not "auto": %s',
										this
									);
								'responsive' == J || 'intrinsic' == J
									? G(
											Fe(D) == Fe(W),
											'Length units should be the same for "width" and "height": %s, %s, %s',
											w,
											y,
											this
										)
									: G(null === q, '"heights" attribute must be missing: %s', this);
								this.classList.add('i-amphtml-layout-' + J);
								Be(J) && this.classList.add('i-amphtml-layout-size-defined');
								if ('nodisplay' == J) re(this, !1), (this.style.display = '');
								else if ('fixed' == J)
									qe(this, {
										width: D,
										height: W
									});
								else if ('fixed-height' == J) X(this, 'height', W);
								else if ('responsive' == J) {
									var zc = this.ownerDocument.createElement('i-amphtml-sizer');
									zc.setAttribute('slot', 'i-amphtml-svc');
									qe(zc, { paddingTop: Ge(W) / Ge(D) * 100 + '%' });
									this.insertBefore(zc, this.firstChild);
									this.sizerElement = zc;
								} else if ('intrinsic' == J) {
									var Zd = je(this)(ve);
									Zd.firstElementChild.setAttribute(
										'src',
										l && this.ownerDocument
											? ue(this.ownerDocument, Ge(D), Ge(W))
											: 'data:image/svg+xml;charset=utf-8,<svg height="' +
												W +
												'" width="' +
												D +
												'" xmlns="http://www.w3.org/2000/svg" version="1.1"/>'
									);
									this.insertBefore(Zd, this.firstChild);
									this.sizerElement = Zd;
								} else
									'fill' != J &&
										'container' != J &&
										('flex-item' == J
											? (D && X(this, 'width', D), W && X(this, 'height', W))
											: 'fluid' == J &&
												(this.classList.add('i-amphtml-layout-awaiting-size'),
												D && X(this, 'width', D),
												X(this, 'height', 0)));
								this.setAttribute('i-amphtml-layout', J);
								r = J;
							}
							this.layout_ = r;
						} catch (Ll) {
							Bf(Ll, this);
						}
						this.implementation_ instanceof hi || this.qg();
						this.isUpgraded() ||
							(this.classList.add('amp-unresolved'),
							this.classList.add('i-amphtml-unresolved'),
							this.Ca('amp:stubbed'));
						this.getResources().isIntersectionExperimentOn() && this.applySizesAndMediaQuery();
					}
				}
			};
			b.prototype.gh = function() {
				return this.classList.contains('i-amphtml-layout-awaiting-size');
			};
			b.prototype.Uh = function() {
				this.classList.remove('i-amphtml-layout-awaiting-size');
			};
			b.prototype.attachedCallback = function() {
				this.connectedCallback();
			};
			b.prototype.qg = function() {
				var b = this,
					c = this.implementation_;
				if (1 == this.lb) {
					this.lb = 4;
					var g = a.Date.now(),
						h = c.upgradeCallback();
					h
						? 'function' == typeof h.then
							? h
									.then(function(a) {
										b.Dd(a || c, g);
									})
									.catch(function(a) {
										b.lb = 3;
										hb(a);
									})
							: this.Dd(h, g)
						: this.Dd(c, g);
				}
			};
			b.prototype.disconnectedCallback = function() {
				this.disconnect(!1);
			};
			b.prototype.detachedCallback = function() {
				this.disconnectedCallback();
			};
			b.prototype.disconnect = function(a) {
				this.Eb ||
					!this.pc ||
					(!a && Ab(this)) ||
					(a && this.classList.remove('i-amphtml-element'),
					(this.pc = !1),
					this.getResources().remove(this),
					this.implementation_.detachedCallback());
			};
			b.prototype.dispatchCustomEvent = function(a, b) {
				b = b || {};
				var c = this.ownerDocument.createEvent('Event');
				c.data = b;
				c.initEvent(a, !0, !0);
				this.dispatchEvent(c);
			};
			b.prototype.Ca = function() {};
			b.prototype.prerenderAllowed = function() {
				return this.implementation_.prerenderAllowed();
			};
			b.prototype.isBuildRenderBlocking = function() {
				return this.implementation_.isBuildRenderBlocking();
			};
			b.prototype.createPlaceholder = function() {
				return this.implementation_.createPlaceholderCallback();
			};
			b.prototype.createLoaderLogo = function() {
				return this.implementation_.createLoaderLogoCallback();
			};
			b.prototype.renderOutsideViewport = function() {
				return this.implementation_.renderOutsideViewport();
			};
			b.prototype.idleRenderOutsideViewport = function() {
				return this.implementation_.idleRenderOutsideViewport();
			};
			b.prototype.getLayoutBox = function() {
				return this.zb().getLayoutBox();
			};
			b.prototype.getPageLayoutBox = function() {
				return this.zb().getPageLayoutBox();
			};
			b.prototype.getOwner = function() {
				return this.zb().getOwner();
			};
			b.prototype.getIntersectionChangeEntry = function() {
				var a = this.implementation_.getIntersectionElementLayoutBox(),
					b = this.getOwner(),
					c = this.implementation_.getViewport().getRect(),
					h = b && b.getLayoutBox(),
					l = gc(a, h, c) || fc(0, 0, 0, 0);
				b = l.width * l.height;
				var k = a.width * a.height;
				b = 0 === k ? 0 : b / k;
				if ((k = c)) (l = ic(l, -c.left, -c.top)), (a = ic(a, -c.left, -c.top)), (k = ic(k, -c.left, -c.top));
				return {
					time: 'undefined' !== typeof performance && performance.now ? performance.now() : Date.now() - ti,
					rootBounds: k,
					boundingClientRect: a,
					intersectionRect: l,
					intersectionRatio: b
				};
			};
			b.prototype.zb = function() {
				return this.getResources().getResourceForElement(this);
			};
			b.prototype.getResourceId = function() {
				return this.zb().getId();
			};
			b.prototype.isRelayoutNeeded = function() {
				return this.implementation_.isRelayoutNeeded();
			};
			b.prototype.getImpl = function(a) {
				var b = this;
				a = void 0 === a ? !0 : a;
				return (a ? this.whenBuilt() : this.whenUpgraded()).then(function() {
					return b.implementation_;
				});
			};
			b.prototype.getLayout = function() {
				return this.layout_;
			};
			b.prototype.layoutCallback = function() {
				var a = this;
				this.isBuilt();
				this.Ca('amp:load-start');
				var b = 0 == this.ea;
				this.K.reset('unload');
				b && this.K.signal('load-start');
				this.Xf && this.vf().startLayout();
				var c = nb(function() {
					return a.implementation_.layoutCallback();
				});
				this.preconnect(!0);
				this.classList.add('i-amphtml-layout');
				return c.then(
					function() {
						b && a.K.signal('load-end');
						a.readyState = 'complete';
						a.ea++;
						a.toggleLoading(!1, { cleanup: !0 });
						a.Wd || (a.implementation_.firstLayoutCompleted(), (a.Wd = !0), a.Ca('amp:load-end'));
					},
					function(c) {
						b && a.K.rejectSignal('load-end', c);
						a.ea++;
						a.toggleLoading(!1, { cleanup: !0 });
						throw c;
					}
				);
			};
			b.prototype.isInViewport = function() {
				return this.Fb;
			};
			b.prototype.viewportCallback = function(b) {
				var c = this;
				if (b != this.Fb && this.ownerDocument && this.ownerDocument.defaultView) {
					this.Fb = b;
					if (0 == this.ea)
						if (b) {
							var d = a.Date.now();
							U(this.ownerDocument.defaultView).delay(function() {
								c.Fb &&
									c.ownerDocument &&
									c.ownerDocument.defaultView &&
									0 === c.ea &&
									c.toggleLoading(!0, { startTime: d });
							}, 100);
						} else this.toggleLoading(!1);
					this.isBuilt() && this.rg(b);
				}
			};
			b.prototype.rg = function(a) {
				this.implementation_.inViewport_ = a;
				this.implementation_.viewportCallback(a);
				a && this.Xf && this.vf().enterViewport();
			};
			b.prototype.isPaused = function() {
				return this.Mb;
			};
			b.prototype.pauseCallback = function() {
				this.Mb ||
					((this.Mb = !0), this.viewportCallback(!1), this.isBuilt() && this.implementation_.pauseCallback());
			};
			b.prototype.resumeCallback = function() {
				this.Mb && ((this.Mb = !1), this.isBuilt() && this.implementation_.resumeCallback());
			};
			b.prototype.unlayoutCallback = function() {
				if (!this.isBuilt()) return !1;
				this.K.signal('unload');
				var a = this.implementation_.unlayoutCallback();
				a && this.bg();
				this.Ca('amp:unload');
				return a;
			};
			b.prototype.bg = function() {
				this.ea = 0;
				this.Wd = !1;
				this.K.reset('render-start');
				this.K.reset('load-start');
				this.K.reset('load-end');
				this.K.reset('ini-load');
			};
			b.prototype.unlayoutOnPause = function() {
				return this.implementation_.unlayoutOnPause();
			};
			b.prototype.reconstructWhenReparented = function() {
				return this.implementation_.reconstructWhenReparented();
			};
			b.prototype.collapse = function() {
				this.implementation_.collapse();
			};
			b.prototype.collapsedCallback = function(a) {
				this.implementation_.collapsedCallback(a);
			};
			b.prototype.expand = function() {
				this.implementation_.expand();
			};
			b.prototype.expandedCallback = function(a) {
				this.implementation_.expandedCallback(a);
			};
			b.prototype.mutatedAttributesCallback = function(a) {
				this.implementation_.mutatedAttributesCallback(a);
			};
			b.prototype.enqueAction = function(a) {
				this.isBuilt() ? this.sf(a, !1) : (void 0 === this.Ka && (this.Ka = []), this.Ka.push(a));
			};
			b.prototype.Qg = function() {
				var a = this;
				if (this.Ka) {
					var b = this.Ka;
					this.Ka = null;
					b.forEach(function(b) {
						a.sf(b, !0);
					});
				}
			};
			b.prototype.sf = function(a, b) {
				try {
					this.implementation_.executeAction(a, b);
				} catch (g) {
					hb('Action execution failed:', g, a.node.tagName, a.method);
				}
			};
			b.prototype.Wg = function() {
				var a = this.getAttribute('data-block-on-consent');
				if (null === a)
					if (
						((a = this.getAmpDoc().getMetaByName('amp-consent-blocking'))
							? ((a = a.toUpperCase().replace(/\s+/g, '')), (a = a.split(',').includes(this.tagName)))
							: (a = !1),
						a)
					)
						(a = 'default'), this.setAttribute('data-block-on-consent', a);
					else return null;
				return '' == a || 'default' == a ? this.implementation_.getConsentPolicy() : a;
			};
			b.prototype.getRealChildNodes = function() {
				return Jb(this, function(a) {
					return !Ni(a);
				});
			};
			b.prototype.getRealChildren = function() {
				return Hb(this, function(a) {
					return !Ni(a);
				});
			};
			b.prototype.getPlaceholder = function() {
				return Ib(this, function(a) {
					return a.hasAttribute('placeholder') && !('placeholder' in a);
				});
			};
			b.prototype.togglePlaceholder = function(a) {
				if (a) {
					var b = this.getPlaceholder();
					b && b.classList.remove('amp-hidden');
				} else {
					/^[\w-]+$/.test('placeholder');
					b = (void 0 !== qb ? qb : (qb = rb(this)))
						? this.querySelectorAll('> [placeholder]'.replace(/^|,/g, '$&:scope '))
						: Mb(this, '> [placeholder]');
					for (var c = 0; c < b.length; c++) 'placeholder' in b[c] || b[c].classList.add('amp-hidden');
				}
			};
			b.prototype.getFallback = function() {
				return Kb(this, 'fallback');
			};
			b.prototype.toggleFallback = function(a) {
				var b = this.zb().getState();
				if (!a || (0 != b && 1 != b && 2 != b))
					if ((this.classList.toggle('amp-notsupported', a), 1 == a)) {
						var c = this.getFallback();
						c && bd(this.getAmpDoc(), 'owners').scheduleLayout(this, c);
					}
			};
			b.prototype.renderStarted = function() {
				this.K.signal('render-start');
				this.togglePlaceholder(!1);
				this.toggleLoading(!1);
			};
			b.prototype.Xd = function() {
				if (this.isInA4A()) return !1;
				void 0 === this.fe && (this.fe = this.hasAttribute('noloading'));
				var a = 0 < this.ea || this.K.get('render-start'),
					b;
				(b = this.fe || (a && !this.implementation_.isLoadingReused()) || 0 >= this.wc) ||
					((b = this.tagName.toUpperCase()), (b = !(ye[b] || ('AMP-VIDEO' == b ? 0 : ze.test(b)))));
				return b || Ni(this) || 'nodisplay' == this.layout_ ? !1 : !0;
			};
			b.prototype.isInA4A = function() {
				return (this.C && this.C.win != this.ownerDocument.defaultView) || 'inabox' == v().runtime;
			};
			b.prototype.Eh = function(a) {
				if (this.Xd() && !this.Na) {
					var b = je(this.ownerDocument)(Ji),
						c = ri(this.getAmpDoc(), this, this.wc, this.Mf, a);
					b.appendChild(c);
					this.appendChild(b);
					this.Na = b;
					this.ge = c;
				}
			};
			b.prototype.toggleLoading = function(a, b) {
				var c = this,
					d = b && b.cleanup,
					e = b && b.startTime;
				if (a !== this.xc || b)
					if ((this.xc = a) || this.Na)
						a && !this.Xd()
							? (this.xc = !1)
							: this.ie(
									function() {
										var a = c.xc;
										a && !c.Xd() && (a = !1);
										a && c.Eh(e);
										if (
											c.Na &&
											(c.Na.classList.toggle('amp-hidden', !a),
											c.ge.classList.toggle('amp-active', a),
											!a && d && !c.implementation_.isLoadingReused())
										) {
											var b = c.Na;
											c.Na = null;
											c.ge = null;
											c.ie(
												function() {
													yb(b);
												},
												void 0,
												!0
											);
										}
									},
									void 0,
									!0
								);
			};
			b.prototype.vf = function() {
				this.de || (this.de = new ji(this.ownerDocument.defaultView, this.getLayoutPriority()));
				return this.de;
			};
			b.prototype.getOverflowElement = function() {
				void 0 === this.na &&
					(this.na = Kb(this, 'overflow')) &&
					(this.na.hasAttribute('tabindex') || this.na.setAttribute('tabindex', '0'),
					this.na.hasAttribute('role') || this.na.setAttribute('role', 'button'));
				return this.na;
			};
			b.prototype.overflowCallback = function(a, b, c) {
				var d = this;
				this.getOverflowElement();
				this.na
					? (this.na.classList.toggle('amp-visible', a),
						(this.na.onclick = a
							? function() {
									var a = td(d.getAmpDoc());
									a.forceChangeSize(d, b, c);
									a.mutateElement(d, function() {
										d.overflowCallback(!1, b, c);
									});
								}
							: null))
					: a &&
						this.warnOnMissingOverflow &&
						C().warn('CustomElement', 'Cannot resize element and overflow is not available', this);
			};
			b.prototype.ie = function(a, b, c) {
				c = void 0 === c ? !1 : c;
				this.C ? td(this.getAmpDoc()).mutateElement(b || this, a, c) : a();
			};
			a.__AMP_BASE_CE_CLASS = b;
			return a.__AMP_BASE_CE_CLASS;
		}
		function Ni(a) {
			var b = 'string' == typeof a ? a : a.tagName;
			return (b && M(b.toLowerCase(), 'i-')) ||
			(a.tagName && (a.hasAttribute('placeholder') || a.hasAttribute('fallback') || a.hasAttribute('overflow')))
				? !0
				: !1;
		}
		function Oi(a) {
			a.__AMP_EXTENDED_ELEMENTS || (a.__AMP_EXTENDED_ELEMENTS = {});
			return a.__AMP_EXTENDED_ELEMENTS;
		}
		function Pi(a, b) {
			try {
				a.upgrade(b);
			} catch (c) {
				Bf(c, a);
			}
		}
		function Qi(a) {
			od(a.getHeadNode()).forEach(function(b) {
				a.declareExtension(b);
				Ri(a.win, b);
			});
		}
		function Ri(a, b) {
			Oi(a)[b] || Si(a, b, hi);
		}
		function Si(a, b, c) {
			Oi(a)[b] = c;
			var d = Li(a);
			a.customElements.define(b, d);
		}
		var Ti = 'alt aria-describedby aria-label aria-labelledby crossorigin referrerpolicy sizes src srcset title'.split(
			' '
		);
		function Ui(a) {
			Re.call(this, a);
			this.Yf = this.cc = !0;
			this.fd = this.gd = this.I = null;
			this.ig = 0;
		}
		m(Ui, Re);
		f = Ui.prototype;
		f.mutatedAttributesCallback = function(a) {
			if (this.I) {
				var b = Ti.filter(function(b) {
					return void 0 !== a[b];
				});
				a.src &&
					!a.srcset &&
					this.element.hasAttribute('srcset') &&
					(this.element.removeAttribute('srcset'),
					b.push('srcset'),
					this.user().warn(
						'amp-img',
						'Removed [srcset] since [src] was mutated. Recommend adding a [srcset] binding to support responsive images.',
						this.element
					));
				this.propagateAttributes(b, this.I, !0);
				this.propagateDataset(this.I);
				te(this.I);
			}
		};
		f.onMeasureChanged = function() {
			Vi(this, !1);
		};
		f.preconnectCallback = function(a) {
			var b = this.element.getAttribute('src');
			b
				? S(this.win, 'preconnect').url(this.getAmpDoc(), b, a)
				: (b = this.element.getAttribute('srcset')) &&
					(b = /\S+/.exec(b)) &&
					S(this.win, 'preconnect').url(this.getAmpDoc(), b[0], a);
		};
		f.firstAttachedCallback = function() {
			this.element.hasAttribute('noprerender') && (this.Yf = !1);
		};
		f.isLayoutSupported = function(a) {
			return Be(a);
		};
		f.oc = function() {
			if (!this.I) {
				this.cc = !this.element.hasAttribute('fallback');
				this.element.hasAttribute('i-amphtml-ssr') && (this.I = Lb(this.element, '> img:not([placeholder])'));
				this.I = this.I || new Image();
				this.I.setAttribute('decoding', 'async');
				this.element.id && this.I.setAttribute('amp-img-id', this.element.id);
				'img' == this.element.getAttribute('role') &&
					(this.element.removeAttribute('role'),
					this.user().error(
						'amp-img',
						'Setting role=img on amp-img elements breaks screen readers please just set alt or ARIA attributes, they will be correctly propagated for the underlying <img> element.'
					));
				Vi(this, !0);
				this.propagateAttributes(Ti, this.I);
				this.propagateDataset(this.I);
				te(this.I);
				this.applyFillContent(this.I, !0);
				var a = this.element,
					b = this.I;
				a.hasAttribute('object-fit') && X(b, 'object-fit', a.getAttribute('object-fit'));
				a.hasAttribute('object-position') && X(b, 'object-position', a.getAttribute('object-position'));
				this.element.appendChild(this.I);
			}
		};
		function Vi(a, b) {
			if (a.I && !a.element.getAttribute('sizes')) {
				var c = a.element.getAttribute('srcset');
				if (c && !/[0-9]+x(?:,|$)/.test(c) && ((c = a.element.getLayoutWidth()), Wi(a, c))) {
					var d = a.getViewport().getWidth(),
						e = '(max-width: ' + d + 'px) ' + c + 'px, ',
						g = c + 'px';
					'fixed' !== a.getLayout() && (g = Math.max(Math.round(100 * c / d), 100) + 'vw');
					var h = e + g;
					b
						? a.I.setAttribute('sizes', h)
						: a.mutateElement(function() {
								a.I.setAttribute('sizes', h);
							});
					a.ig = c;
				}
			}
		}
		function Wi(a, b) {
			return a.I.hasAttribute('sizes') ? b > a.ig : !0;
		}
		f.prerenderAllowed = function() {
			return this.Yf;
		};
		f.reconstructWhenReparented = function() {
			return !1;
		};
		f.layoutCallback = function() {
			var a = this;
			this.oc();
			var b = this.I;
			this.gd = Le(b, 'load', function() {
				return Xi(a);
			});
			this.fd = Le(b, 'error', function() {
				return Yi(a);
			});
			return 0 >= this.element.getLayoutWidth() ? x() : this.loadPromise(b);
		};
		f.unlayoutCallback = function() {
			this.fd && (this.fd(), (this.fd = null));
			this.gd && (this.gd(), (this.gd = null));
			var a = this.I;
			a &&
				!a.complete &&
				((a.src = 'data:image/gif;base64,R0lGODlhAQABAIAAAP///wAAACwAAAAAAQABAAACAkQBADs='),
				yb(a),
				(this.I = null));
			return !0;
		};
		f.firstLayoutCompleted = function() {
			var a = this.getPlaceholder();
			a && a.classList.contains('i-amphtml-blurry-placeholder')
				? oe(a, { opacity: 0 })
				: this.togglePlaceholder(!1);
		};
		function Xi(a) {
			!a.cc &&
				a.I.classList.contains('i-amphtml-ghost') &&
				a.getVsync().mutate(function() {
					a.I.classList.remove('i-amphtml-ghost');
					a.toggleFallback(!1);
				});
		}
		function Yi(a) {
			a.cc &&
				(a.getVsync().mutate(function() {
					a.I.classList.add('i-amphtml-ghost');
					a.toggleFallback(!0);
					a.togglePlaceholder(!1);
				}),
				(a.cc = !1));
		}
		function Zi(a) {
			this.win = a;
			this.Fg = this.uh.bind(this);
			this.Gg = this.vh.bind(this);
			this.ud = this.Ve = this.vd = null;
			this.lc =
				'ontouchstart' in a ||
				(void 0 !== a.navigator.maxTouchPoints && 0 < a.navigator.maxTouchPoints) ||
				void 0 !== a.DocumentTouch;
			F().fine('Input', 'touch detected:', this.lc);
			this.Hb = !1;
			this.win.document.addEventListener('keydown', this.Fg);
			this.win.document.addEventListener('mousedown', this.Gg);
			this.Nd = !0;
			this.Qf = 0;
			this.$h = new Y();
			this.Rf = new Y();
			this.be = new Y();
			this.lc && ((this.Nd = !this.lc), (this.vd = this.wh.bind(this)), Me(a.document, 'mousemove', this.vd));
		}
		f = Zi.prototype;
		f.setupInputModeClasses = function(a) {
			var b = this;
			this.onTouchDetected(function(c) {
				$i(b, a, 'amp-mode-touch', c);
			}, !0);
			this.onMouseDetected(function(c) {
				$i(b, a, 'amp-mode-mouse', c);
			}, !0);
			this.onKeyboardStateChanged(function(c) {
				$i(b, a, 'amp-mode-keyboard-active', c);
			}, !0);
		};
		f.isTouchDetected = function() {
			return this.lc;
		};
		f.onTouchDetected = function(a, b) {
			b && a(this.isTouchDetected());
			return this.$h.add(a);
		};
		f.isMouseDetected = function() {
			return this.Nd;
		};
		f.onMouseDetected = function(a, b) {
			b && a(this.isMouseDetected());
			return this.Rf.add(a);
		};
		f.isKeyboardActive = function() {
			return this.Hb;
		};
		f.onKeyboardStateChanged = function(a, b) {
			b && a(this.isKeyboardActive());
			return this.be.add(a);
		};
		function $i(a, b, c, d) {
			b.waitForBodyOpen().then(function(b) {
				vd(a.win).mutate(function() {
					b.classList.toggle(c, d);
				});
			});
		}
		f.uh = function(a) {
			this.Hb ||
				a.defaultPrevented ||
				((a = a.target),
				a &&
					('INPUT' == a.tagName ||
						'TEXTAREA' == a.tagName ||
						'SELECT' == a.tagName ||
						'OPTION' == a.tagName ||
						a.hasAttribute('contenteditable'))) ||
				((this.Hb = !0), this.be.fire(!0), F().fine('Input', 'keyboard activated'));
		};
		f.vh = function() {
			this.Hb && ((this.Hb = !1), this.be.fire(!1), F().fine('Input', 'keyboard deactivated'));
		};
		f.wh = function(a) {
			var b = this;
			if (a.sourceCapabilities && a.sourceCapabilities.firesTouchEvents) this.Pf();
			else {
				this.ud || ((this.ud = this.sh.bind(this)), (this.Ve = this.Pf.bind(this)));
				var c,
					d = Ne(this.win.document, function(a) {
						c = a;
					});
				return U(this.win).timeoutPromise(300, d).then(this.Ve, function() {
					c && c();
					b.ud();
				});
			}
		};
		f.sh = function() {
			this.Nd = !0;
			this.Rf.fire(!0);
			F().fine('Input', 'mouse detected');
		};
		f.Pf = function() {
			this.Qf++;
			3 >= this.Qf ? Me(this.win.document, 'mousemove', this.vd) : F().fine('Input', 'mouse detection failed');
		};
		function aj() {
			Re.apply(this, arguments);
		}
		m(aj, Re);
		aj.prototype.isLayoutSupported = function(a) {
			return 'container' == a || Be(a);
		};
		aj.prototype.buildCallback = function() {
			if ('container' != this.getLayout()) {
				var a = this.win.document.createElement('div');
				this.applyFillContent(a);
				this.getRealChildNodes().forEach(function(b) {
					a.appendChild(b);
				});
				this.element.appendChild(a);
			}
		};
		aj.prototype.prerenderAllowed = function() {
			return !0;
		};
		function bj(a) {
			var b = this;
			this.win = a;
			this.Fh = 6e4;
			this.O = [];
			this.Tf = new Y();
			this.ff = function(a) {
				a.target && 1 == a.target.nodeType && cj(b, a.target);
			};
			this.ef = function() {
				U(a).delay(function() {
					b.win.document.activeElement && cj(b, b.win.document.activeElement);
				}, 500);
			};
			this.win.document.addEventListener('focus', this.ff, !0);
			this.win.addEventListener('blur', this.ef);
		}
		f = bj.prototype;
		f.gi = function() {
			this.win.document.removeEventListener('focus', this.ff, !0);
			this.win.removeEventListener('blur', this.ef);
		};
		f.onFocus = function(a) {
			return this.Tf.add(a);
		};
		function cj(a, b) {
			var c = Date.now();
			0 == a.O.length || a.O[a.O.length - 1].el != b
				? a.O.push({ el: b, time: c })
				: (a.O[a.O.length - 1].time = c);
			a.purgeBefore(c - a.Fh);
			a.Tf.fire(b);
		}
		f.getLast = function() {
			return 0 == this.O.length ? null : this.O[this.O.length - 1].el;
		};
		f.purgeBefore = function(a) {
			for (var b = this.O.length - 1, c = 0; c < this.O.length; c++)
				if (this.O[c].time >= a) {
					b = c - 1;
					break;
				}
			-1 != b && this.O.splice(0, b + 1);
		};
		f.hasDescendantsOf = function(a) {
			this.win.document.activeElement && cj(this, this.win.document.activeElement);
			for (var b = 0; b < this.O.length; b++) if (a.contains(this.O[b].el)) return !0;
			return !1;
		};
		function dj(a) {
			var b = this;
			this.ampdoc = a;
			this.win = a.win;
			this.j = ud(a);
			this.H = wd(this.ampdoc);
			this.A = vd(this.win);
			this.od = new bj(this.win);
			this.od.onFocus(function(a) {
				ej(b, a);
			});
			this.Ma = this.j.isIntersectionExperimentOn();
		}
		f = dj.prototype;
		f.forceChangeSize = function(a, b, c, d, e) {
			fj(this, Z(a), b, c, e, void 0, !0, d);
		};
		f.requestChangeSize = function(a, b, c, d, e) {
			var g = this;
			return new Promise(function(h, l) {
				fj(g, Z(a), b, c, d, e, !1, function(a) {
					a ? h() : l(Error('changeSize attempt denied'));
				});
			});
		};
		f.expandElement = function(a) {
			var b = Z(a);
			b.completeExpand();
			var c = b.getOwner();
			c && c.expandedCallback(a);
			this.j.schedulePass(70);
		};
		f.attemptCollapse = function(a) {
			var b = this;
			return new Promise(function(c, d) {
				fj(b, Z(a), 0, 0, void 0, void 0, !1, function(b) {
					b ? (Z(a).completeCollapse(), c()) : d(F().createExpectedError('collapse attempt denied'));
				});
			});
		};
		f.collapseElement = function(a) {
			if (!this.Ma) {
				var b = this.H.getLayoutRect(a);
				0 != b.width &&
					0 != b.height &&
					(P(this.win, 'dirty-collapse-element') ? this.dirtyElement(a) : this.j.setRelayoutTop(b.top));
			}
			Z(a).completeCollapse();
			this.Ma || this.j.schedulePass(70);
		};
		f.measureElement = function(a) {
			return this.A.measurePromise(a);
		};
		f.mutateElement = function(a, b, c) {
			return gj(this, a, null, b, c);
		};
		f.measureMutateElement = function(a, b, c) {
			return gj(this, a, b, c);
		};
		function gj(a, b, c, d, e) {
			function g() {
				var c = a.H.getLayoutRect(b);
				return 0 != c.width && 0 != c.height ? c.top : -1;
			}
			e = void 0 === e ? !1 : e;
			var h = -1;
			return a.A.runPromise({
				measure: function() {
					c && c();
					a.Ma || e || (h = g());
				},
				mutate: function() {
					d();
					if (!e) {
						b.classList.contains('i-amphtml-element') && Z(b).requestMeasure();
						for (var c = b.getElementsByClassName('i-amphtml-element'), k = 0; k < c.length; k++)
							Z(c[k]).requestMeasure();
						a.j.schedulePass(70);
						a.Ma
							? a.j.maybeHeightChanged()
							: (-1 != h && a.j.setRelayoutTop(h),
								a.A.measure(function() {
									var b = g();
									-1 != b && b != h && (a.j.setRelayoutTop(b), a.j.schedulePass(70));
									a.j.maybeHeightChanged();
								}));
					}
				}
			});
		}
		f.dirtyElement = function(a) {
			var b = !1;
			a.classList.contains('i-amphtml-element')
				? ((a = Z(a)), this.j.setRelayoutTop(a.getLayoutBox().top))
				: (b = !0);
			this.j.schedulePass(70, b);
		};
		function ej(a, b) {
			var c = Db(b, function(a) {
				return !!Z(a);
			});
			if (c) {
				b = Z(c);
				var d = b.getPendingChangeSize();
				void 0 !== d && fj(a, b, d.height, d.width, d.margins, void 0, !0);
			}
		}
		function fj(a, b, c, d, e, g, h, l) {
			b.hasBeenMeasured() && !e
				? hj(a, b, c, d, void 0, g, h, l)
				: a.A.measure(function() {
						b.hasBeenMeasured() || b.measure();
						if (e) {
							var k = se(a.win, b.element);
							k = {
								top: parseInt(k.marginTop, 10) || 0,
								right: parseInt(k.marginRight, 10) || 0,
								bottom: parseInt(k.marginBottom, 10) || 0,
								left: parseInt(k.marginLeft, 10) || 0
							};
							k = { newMargins: e, currentMargins: k };
						} else k = void 0;
						hj(a, b, c, d, k, g, h, l);
					});
		}
		function hj(a, b, c, d, e, g, h, l) {
			b.resetPendingChangeSize();
			var k = b.getPageLayoutBox();
			if (!(k = (void 0 !== c && c != k.height) || (void 0 !== d && d != k.width)) && (k = void 0 !== e)) {
				k = e.currentMargins;
				var n = e.newMargins;
				k =
					(void 0 !== n.top && n.top != k.top) ||
					(void 0 !== n.right && n.right != k.right) ||
					(void 0 !== n.bottom && n.bottom != k.bottom) ||
					(void 0 !== n.left && n.left != k.left);
			}
			k
				? (a.j.updateOrEnqueueMutateTask(b, {
						resource: b,
						newHeight: c,
						newWidth: d,
						marginChange: e,
						event: g,
						force: h,
						callback: l
					}),
					a.j.schedulePassVsync())
				: (void 0 === c &&
						void 0 === d &&
						void 0 === e &&
						F().error('Mutator', 'attempting to change size with undefined dimensions', b.debugid),
					l && l(!0));
		}
		function ij(a) {
			return z(a) ? a : [ a ];
		}
		function jj(a) {
			this.j = ud(a);
		}
		f = jj.prototype;
		f.setOwner = function(a, b) {
			b.contains(a);
			Z(a) && Z(a).updateOwner(b);
			a.__AMP__OWNER = b;
			a = a.getElementsByClassName('i-amphtml-element');
			for (b = 0; b < a.length; b++) {
				var c = a[b];
				Z(c) && Z(c).updateOwner(void 0);
			}
		};
		f.schedulePreload = function(a, b) {
			kj(this, this.j.getResourceForElement(a), !1, ij(b));
		};
		f.scheduleLayout = function(a, b) {
			kj(this, this.j.getResourceForElement(a), !0, ij(b));
		};
		f.schedulePause = function(a, b) {
			var c = this.j.getResourceForElement(a);
			b = ij(b);
			lj(this, c, b, function(a) {
				a.pause();
			});
		};
		f.scheduleResume = function(a, b) {
			a = this.j.getResourceForElement(a);
			b = ij(b);
			lj(this, a, b, function(a) {
				a.resume();
			});
		};
		f.scheduleUnlayout = function(a, b) {
			a = this.j.getResourceForElement(a);
			b = ij(b);
			lj(this, a, b, function(a) {
				a.unlayout();
			});
		};
		f.updateInViewport = function(a, b, c) {
			mj(this, this.j.getResourceForElement(a), ij(b), c);
		};
		f.requireLayout = function(a, b) {
			var c = this,
				d = [];
			nj(this, a, function(a) {
				4 != a.getState() &&
					(3 != a.getState()
						? d.push(
								a.whenBuilt().then(function() {
									a.measure();
									if (a.isDisplayed()) return c.j.scheduleLayoutOrPreload(a, !0, b, !0), a.loadedOnce();
								})
							)
						: a.isDisplayed() && d.push(a.loadedOnce()));
			});
			return Promise.all(d);
		};
		function lj(a, b, c, d) {
			c.forEach(function(c) {
				b.element.contains(c);
				nj(a, c, d);
			});
		}
		function nj(a, b, c) {
			if (b.classList.contains('i-amphtml-element'))
				c(a.j.getResourceForElement(b)), (b = b.getPlaceholder()) && nj(a, b, c);
			else {
				b = b.getElementsByClassName('i-amphtml-element');
				for (var d = [], e = 0; e < b.length; e++) {
					for (var g = b[e], h = !1, l = 0; l < d.length; l++)
						if (d[l].contains(g)) {
							h = !0;
							break;
						}
					h || (d.push(g), c(a.j.getResourceForElement(g)));
				}
			}
		}
		function kj(a, b, c, d) {
			lj(a, b, d, function(d) {
				0 === d.getState()
					? d.whenBuilt().then(function() {
							oj(a, d, !c, b.getLayoutPriority());
						})
					: oj(a, d, !c, b.getLayoutPriority());
			});
		}
		function oj(a, b, c, d) {
			b.measure();
			2 === b.getState() && b.isDisplayed() && a.j.scheduleLayoutOrPreload(b, !c, d);
		}
		function mj(a, b, c, d) {
			var e = b.isInViewport() && d;
			lj(a, b, c, function(a) {
				a.setInViewport(e);
			});
		}
		function pj(a, b) {
			if ('referrerPolicy' in Image.prototype) return qj(a, b, !0);
			var c = zb(a.document);
			c.onload = function() {
				qj(c.contentWindow, b);
			};
			a.document.body.appendChild(c);
			return c;
		}
		function qj(a, b, c) {
			c = void 0 === c ? !1 : c;
			a = new a.Image();
			c && (a.referrerPolicy = 'no-referrer');
			a.src = b;
			return a;
		}
		function rj(a) {
			Re.call(this, a);
			this.Ee = null;
		}
		m(rj, Re);
		rj.prototype.isLayoutSupported = function() {
			return !0;
		};
		rj.prototype.buildCallback = function() {
			this.element.setAttribute('aria-hidden', 'true');
			(this.Nc = this.element.getAttribute('referrerpolicy')) &&
				G(
					'no-referrer' == this.Nc,
					'amp-pixel: invalid "referrerpolicy" value "' + this.Nc + '". Only "no-referrer" is supported'
				);
			this.element.hasAttribute('i-amphtml-ssr') && this.element.querySelector('img')
				? F().info('amp-pixel', 'inabox img already present')
				: this.getAmpDoc().whenFirstVisible().then(this.ai.bind(this));
		};
		rj.prototype.ai = function() {
			var a = this;
			if (this.Ee) return F().error('amp-pixel', 'duplicate pixel'), this.Ee;
			this.Ee = U(this.win).promise(1).then(function() {
				var b = a.element.getAttribute('src');
				if (b)
					return Tc(a.element, 'url-replace').expandUrlAsync(sj(b)).then(function(b) {
						if (a.win) {
							var c = a.win;
							var e = a.Nc;
							e && 'no-referrer' !== e && C().error('pixel', 'Unsupported referrerPolicy: %s', e);
							c = 'no-referrer' === e ? pj(c, b) : qj(c, b);
							F().info('amp-pixel', 'pixel triggered: ', b);
							return c;
						}
					});
			});
		};
		function sj(a) {
			G(
				/^(https:\/\/|\/\/)/i.test(a),
				'The <amp-pixel> src attribute must start with "https://" or "//". Invalid value: ' + a
			);
			return a;
		}
		function tj(a) {
			this.T = a.navigator;
			this.w = a;
		}
		f = tj.prototype;
		f.isAndroid = function() {
			return /Android/i.test(this.T.userAgent);
		};
		f.isIos = function() {
			return /iPhone|iPad|iPod/i.test(this.T.userAgent);
		};
		f.isSafari = function() {
			return (
				/Safari/i.test(this.T.userAgent) &&
				!this.isChrome() &&
				!this.isIe() &&
				!this.isEdge() &&
				!this.isFirefox() &&
				!this.isOpera()
			);
		};
		f.isChrome = function() {
			return /Chrome|CriOS/i.test(this.T.userAgent) && !this.isEdge() && !this.isOpera();
		};
		f.isFirefox = function() {
			return /Firefox|FxiOS/i.test(this.T.userAgent) && !this.isEdge();
		};
		f.isOpera = function() {
			return /OPR\/|Opera|OPiOS/i.test(this.T.userAgent);
		};
		f.isIe = function() {
			return /Trident|MSIE|IEMobile/i.test(this.T.userAgent);
		};
		f.isEdge = function() {
			return /Edge/i.test(this.T.userAgent);
		};
		f.isWebKit = function() {
			return /WebKit/i.test(this.T.userAgent) && !this.isEdge();
		};
		f.isWindows = function() {
			return /Windows/i.test(this.T.userAgent);
		};
		f.isStandalone = function() {
			return (
				(this.isIos() && this.T.standalone) ||
				(this.isChrome() && this.w.matchMedia('(display-mode: standalone)').matches)
			);
		};
		f.isBot = function() {
			return /bot/i.test(this.T.userAgent);
		};
		f.getMajorVersion = function() {
			return this.isSafari()
				? this.isIos() ? this.getIosMajorVersion() || 0 : uj(this, /\sVersion\/(\d+)/, 1)
				: this.isChrome()
					? uj(this, /(Chrome|CriOS)\/(\d+)/, 2)
					: this.isFirefox()
						? uj(this, /(Firefox|FxiOS)\/(\d+)/, 2)
						: this.isOpera()
							? uj(this, /(OPR|Opera|OPiOS)\/(\d+)/, 2)
							: this.isIe() ? uj(this, /MSIE\s(\d+)/, 1) : this.isEdge() ? uj(this, /Edge\/(\d+)/, 1) : 0;
		};
		function uj(a, b, c) {
			if (!a.T.userAgent) return 0;
			a = a.T.userAgent.match(b);
			return !a || c >= a.length ? 0 : parseInt(a[c], 10);
		}
		f.getIosVersionString = function() {
			if (!this.T.userAgent || !this.isIos()) return '';
			var a = this.T.userAgent.match(/OS ([0-9]+[_.][0-9]+([_.][0-9]+)?)\b/);
			return a ? (a = a[1].replace(/_/g, '.')) : '';
		};
		f.getIosMajorVersion = function() {
			var a = this.getIosVersionString();
			return '' == a ? null : Number(a.split('.')[0]);
		};
		function vj(a) {
			return 'loading' != a.readyState && 'uninitialized' != a.readyState;
		}
		function wj(a) {
			return 'complete' == a.readyState;
		}
		function xj(a, b) {
			yj(a, vj, b);
		}
		function yj(a, b, c) {
			var d = b(a);
			if (d) c(a);
			else {
				var e = function() {
					b(a) && (d || ((d = !0), c(a)), a.removeEventListener('readystatechange', e));
				};
				a.addEventListener('readystatechange', e);
			}
		}
		function zj(a) {
			return new Promise(function(b) {
				xj(a, b);
			});
		}
		function Aj(a) {
			return new Promise(function(b) {
				yj(a, wj, b);
			});
		}
		var Bj = [ '<link rel=preload referrerpolicy=origin>' ],
			Cj = null;
		function Dj(a) {
			this.Gd = a.document;
			this.Od = a.document.head;
			this.Lb = {};
			this.ug = {};
			this.ta = T(a);
			this.Lb[N(a.location.href).origin] = !0;
			a: {
				if (!Cj) {
					var b = a.document.createElement('link');
					var c = b.relList;
					b.as = 'invalid-value';
					if (!c || !c.supports) {
						b = {};
						break a;
					}
					Cj = {
						preconnect: c.supports('preconnect'),
						preload: c.supports('preload'),
						onlyValidAs: 'invalid-value' != b.as
					};
				}
				b = Cj;
			}
			this.hc = b;
			this.R = U(a);
		}
		Dj.prototype.url = function(a, b, c) {
			var d = this;
			a.whenFirstVisible().then(function() {
				d.Zb(a, b, c);
			});
		};
		Dj.prototype.Zb = function(a, b, c) {
			if (Ej(b)) {
				a = N(b).origin;
				b = Date.now();
				var d = this.Lb[a];
				if (d && b < d) c && (this.Lb[a] = b + 18e4);
				else {
					this.Lb[a] = b + (c ? 18e4 : 1e4);
					if (!this.hc.preconnect) {
						var e = this.Gd.createElement('link');
						e.setAttribute('rel', 'dns-prefetch');
						e.setAttribute('href', a);
						this.Od.appendChild(e);
					}
					var g = this.Gd.createElement('link');
					g.setAttribute('rel', 'preconnect');
					g.setAttribute('href', a);
					g.setAttribute('referrerpolicy', 'origin');
					this.Od.appendChild(g);
					this.R.delay(function() {
						e && e.parentNode && e.parentNode.removeChild(e);
						g.parentNode && g.parentNode.removeChild(g);
					}, 1e4);
					Fj(this, a);
				}
			}
		};
		Dj.prototype.preload = function(a, b, c) {
			var d = this;
			Ej(b) &&
				!this.ug[b] &&
				((this.ug[b] = !0),
				this.url(a, b, !0),
				this.hc.preload &&
					(('document' == c && this.ta.isSafari()) ||
						a.whenFirstVisible().then(function() {
							var a = je(d.Gd)(Bj);
							a.setAttribute('href', b);
							a.as = d.hc.onlyValidAs ? 'fetch' : '';
							d.Od.appendChild(a);
						})));
		};
		function Ej(a) {
			return M(a, 'https:') || M(a, 'http:') ? !0 : !1;
		}
		function Fj(a, b) {
			if (!a.hc.preconnect && (a.ta.isSafari() || a.ta.isIos())) {
				var c = Date.now();
				a.Lb[b] = c + 18e4;
				a = new XMLHttpRequest();
				a.open('HEAD', b + '/robots.txt?_AMP_safari_preconnect_polyfill_cachebust=' + (c - c % 18e4), !0);
				a.withCredentials = !0;
				a.send();
			}
		}
		function Gj() {
			var a = self.document;
			Aj(a).then(function() {
				var b = a.defaultView;
				if (b) {
					b = S(b, 'preconnect');
					var c = rd(a.documentElement),
						d = Xc(a);
					b.url(d, c.sourceUrl);
					b.url(d, c.canonicalUrl);
				}
			});
		}
		function Hj(a) {
			this.D = a;
			this.pg = Object.create(null);
		}
		Hj.prototype.addTransition = function(a, b, c) {
			this.pg[a + '|' + b] = c;
		};
		Hj.prototype.setState = function(a) {
			var b = this.D;
			this.D = a;
			(a = this.pg[b + '|' + a]) && a();
		};
		function Ij() {
			this.L = [];
			this.Vb = {};
			this.If = this.Jf = 0;
		}
		f = Ij.prototype;
		f.getSize = function() {
			return this.L.length;
		};
		f.getLastEnqueueTime = function() {
			return this.Jf;
		};
		f.getLastDequeueTime = function() {
			return this.If;
		};
		f.getTaskById = function(a) {
			return this.Vb[a] || null;
		};
		f.enqueue = function(a) {
			this.L.push(a);
			this.Vb[a.id] = a;
			this.Jf = Date.now();
		};
		f.dequeue = function(a) {
			if (!this.removeAtIndex(a, this.L.indexOf(this.Vb[a.id]))) return !1;
			this.If = Date.now();
			return !0;
		};
		f.peek = function(a) {
			for (var b = 1e6, c = null, d = 0; d < this.L.length; d++) {
				var e = this.L[d],
					g = a(e);
				g < b && ((b = g), (c = e));
			}
			return c;
		};
		f.forEach = function(a) {
			this.L.forEach(a);
		};
		f.removeAtIndex = function(a, b) {
			var c = this.Vb[a.id];
			if (!c || this.L[b] != c) return !1;
			this.L.splice(b, 1);
			delete this.Vb[a.id];
			return !0;
		};
		f.purge = function(a) {
			for (var b = this.L.length; b--; ) a(this.L[b]) && this.removeAtIndex(this.L[b], b);
		};
		function Jj(a) {
			if (T(a).isIe()) {
				a = a.document;
				for (
					var b = a.querySelectorAll('.i-amphtml-intrinsic-sizer[src^=data:image/svg]'), c = 0;
					c < b.length;
					c++
				) {
					var d = b[c],
						e = Fb(d, '.i-amphtml-element');
					if (e) {
						var g = Ge(e.getAttribute('width'));
						e = Ge(e.getAttribute('height'));
						g && e && (d.src = ue(a, g, e));
					}
				}
			}
		}
		function Kj(a) {
			return !T(a).isIe() || Lj(a)
				? null
				: new Promise(function(b) {
						var c = Date.now() + 2e3,
							d = a.setInterval(function() {
								var e = Date.now(),
									g = Lj(a);
								if (g || e > c)
									a.clearInterval(d), b(), g || F().error('ie-media-bug', 'IE media never resolved');
							}, 10);
					});
		}
		function Lj(a) {
			var b = '(min-width: ' + (a.innerWidth - 1) + 'px) AND (max-width: ' + (a.innerWidth + 1 + 'px)');
			try {
				return a.matchMedia(b).matches;
			} catch (c) {
				return F().error('ie-media-bug', 'IE matchMedia failed: ', c), !0;
			}
		}
		function Mj(a) {
			var b = this;
			this.ampdoc = a;
			this.win = a.win;
			this.h = V(a);
			this.la = this.h.isRuntimeOn();
			this.hh = !1;
			this.Ph = 0;
			this.j = [];
			this.zd = this.bf = this.Le = 0;
			this.ja = this.ampdoc.isVisible();
			this.$ = this.h.getPrerenderSize();
			this.ub = !1;
			this.tf = !0;
			this.pd = !1;
			this.yb = -1;
			this.Fa = !0;
			this.ib = -1;
			this.ce = this.vc = 0;
			this.Kc = new si(this.win, function() {
				return b.doPass();
			});
			this.ag = new si(this.win, function() {
				b.Fa = !0;
				b.schedulePass();
			});
			this.ra = new Ij();
			this.F = new Ij();
			this.yd = this.Kg.bind(this);
			this.ha = [];
			this.va = [];
			this.Ud = !1;
			this.H = wd(this.ampdoc);
			this.A = vd(this.win);
			this.od = new bj(this.win);
			this.Ke = !1;
			this.Wa = 0;
			this.ab = !1;
			this.Jc = [];
			this.Hd = [];
			this.Dh = P(this.win, 'build-close-to-viewport');
			this.Jg = P(this.win, 'build-in-chunks');
			this.Kh = P(this.win, 'render-on-idle-fix');
			this.Pc = P(this.win, 'remove-task-timeout');
			this.nf = !1;
			this.uf = new L();
			this.zg = new Hj(this.ampdoc.getVisibilityState());
			this.De = this.kg = 0;
			this.V = null;
			this.Ef = !1;
			if (P(this.win, 'intersect-resources')) {
				var c = Qb(this.win);
				a = this.ampdoc.isSingleDoc() && c ? this.win.document : null;
				try {
					(this.V = new IntersectionObserver(
						function(a) {
							return b.intersect(a);
						},
						{ root: a, rootMargin: '250% 31.25%' }
					)),
						(this.Fa = !1);
				} catch (d) {
					F().warn('Resources', 'Falling back to classic Resources:', d);
				}
			}
			this.H.onChanged(function(a) {
				b.vc = Date.now();
				b.ce = a.velocity;
				a.relayoutAll && ((b.Fa = !0), (b.ab = !0));
				(!b.Fa && b.V) || b.schedulePass();
			});
			this.H.onScroll(function() {
				b.vc = Date.now();
			});
			this.ampdoc.onVisibilityChanged(function() {
				-1 == b.yb && b.ampdoc.isVisible() && (b.yb = Date.now());
				b.schedulePass();
			});
			this.h.onRuntimeState(function(a) {
				F().fine('Resources', 'Runtime state:', a);
				b.la = a;
				b.schedulePass(1);
			});
			Ai(this.ampdoc, function() {
				Nj(b, b.zg);
				b.schedulePass(0);
			});
			Oj(this);
			!this.V &&
				P(this.win, 'layoutbox-invalidate-on-scroll') &&
				((this.bd = rf(
					this.win,
					function(a) {
						a = a.target;
						a.nodeType !== Node.ELEMENT_NODE ||
							a === b.H.getScrollingElement() ||
							b.Hd.includes(a) ||
							(b.Hd.push(a), b.schedulePass(70));
					},
					250
				)),
				Le(this.win.document, 'scroll', this.bd, { capture: !0, passive: !0 }));
		}
		f = Mj.prototype;
		f.isIntersectionExperimentOn = function() {
			return !!this.V;
		};
		f.intersect = function(a) {
			this.Ef = !0;
			a.forEach(function(a) {
				var b = a.boundingClientRect;
				Z(a.target).premeasure(b);
			});
			this.schedulePass();
		};
		function Oj(a) {
			a.ampdoc.whenReady().then(function() {
				a.ub = !0;
				Pj(a);
				a.va = null;
				S(a.win, 'input').setupInputModeClasses(a.ampdoc);
				Jj(a.win);
				if (!a.V) {
					var b = Kj(a.win),
						c = function() {
							return a.ag.schedule();
						};
					b ? b.then(c) : c();
					Promise.race([ Qe(a.win), U(a.win).promise(3100) ]).then(c);
					a.win.document.fonts &&
						'loaded' != a.win.document.fonts.status &&
						a.win.document.fonts.ready.then(c);
				}
			});
		}
		f.get = function() {
			return this.j.slice(0);
		};
		f.getAmpdoc = function() {
			return this.ampdoc;
		};
		f.getResourceForElement = function(a) {
			return Z(a);
		};
		f.getResourceForElementOptional = function(a) {
			return Z(a);
		};
		f.getScrollDirection = function() {
			return Math.sign(this.ce) || 1;
		};
		f.add = function(a) {
			this.Le++;
			1 == this.Le && this.H.ensureReadyForElements();
			var b = Z(a);
			b && 0 != b.getState() && !a.reconstructWhenReparented()
				? (this.V || b.requestMeasure(), F().fine('Resources', 'resource reused:', b.debugid))
				: ((b = new li(++this.Ph, a, this)), F().fine('Resources', 'resource added:', b.debugid));
			this.j.push(b);
			this.V ? this.V.observe(a) : this.ag.schedule(1e3);
		};
		function Qj(a, b, c, d) {
			c = void 0 === c ? !1 : c;
			d = void 0 === d ? !1 : d;
			if (a.la || a.hh)
				if ('prerender' != a.ampdoc.getVisibilityState() || b.prerenderAllowed())
					if (
						!a.Dh ||
						d ||
						b.isBuildRenderBlocking() ||
						b.renderOutsideViewport() ||
						(Rj(a) && b.idleRenderOutsideViewport())
					)
						a.ub
							? Sj(a, b, d)
							: b.isBuilt() || b.isBuilding() || (c && a.va.includes(b)) || (a.va.push(b), Pj(a));
		}
		function Pj(a) {
			if (!a.Ud)
				try {
					a.Ud = !0;
					for (var b = 0; b < a.va.length; b++) {
						var c = a.va[b],
							d;
						if (!(d = a.ub))
							a: {
								var e = a.ampdoc.getRootNode(),
									g = c.element;
								do
									if (g.nextSibling) {
										d = !0;
										break a;
									}
								while ((g = g.parentNode) && g != e);
								d = !1;
							}
						d && (a.va.splice(b--, 1), Sj(a, c));
					}
				} finally {
					a.Ud = !1;
				}
		}
		function Sj(a, b, c) {
			if (
				(void 0 === c ? 0 : c) ||
				(a.Jg && 10 <= a.zd ? 0 : 20 > a.bf || a.ampdoc.hasBeenVisible()) ||
				b.isBuildRenderBlocking()
			)
				if ((c = b.build()))
					F().fine('Resources', 'build resource:', b.debugid),
						a.bf++,
						a.zd++,
						c.then(
							function() {
								return a.schedulePass();
							},
							function(c) {
								Tj(a, b);
								if (!Df(c)) throw c;
							}
						);
		}
		f.remove = function(a) {
			(a = Z(a)) && Tj(this, a);
		};
		function Tj(a, b) {
			var c = a.j.indexOf(b);
			-1 != c && a.j.splice(c, 1);
			b.isBuilt() && b.pauseOnRemove();
			a.V && a.V.unobserve(b.element);
			Uj(a, b, !0);
			F().fine('Resources', 'resource removed:', b.debugid);
		}
		f.upgraded = function(a) {
			a = Z(a);
			Qj(this, a);
			F().fine('Resources', 'resource upgraded:', a.debugid);
		};
		f.updateLayoutPriority = function(a, b) {
			var c = Z(a);
			c.updateLayoutPriority(b);
			this.F.forEach(function(a) {
				a.resource == c && (a.priority = b);
			});
			this.schedulePass();
		};
		f.schedulePass = function(a) {
			return this.Kc.schedule(a);
		};
		f.updateOrEnqueueMutateTask = function(a, b) {
			for (var c = null, d = 0; d < this.ha.length; d++)
				if (this.ha[d].resource == a) {
					c = this.ha[d];
					break;
				}
			c
				? ((c.newHeight = b.newHeight),
					(c.newWidth = b.newWidth),
					(c.marginChange = b.marginChange),
					(c.event = b.event),
					(c.force = b.force || c.force),
					(c.callback = b.callback))
				: this.ha.push(b);
		};
		f.schedulePassVsync = function() {
			var a = this;
			this.Ke ||
				((this.Ke = !0),
				this.A.mutate(function() {
					return a.doPass();
				}));
		};
		f.ampInitComplete = function() {
			this.pd = !0;
			F().fine('Resources', 'ampInitComplete');
			this.schedulePass();
		};
		f.setRelayoutTop = function(a) {
			this.ib = -1 == this.ib ? a : Math.min(a, this.ib);
		};
		f.maybeHeightChanged = function() {
			this.ab = !0;
		};
		f.onNextPass = function(a) {
			this.Jc.push(a);
		};
		f.doPass = function() {
			var a = this;
			if (this.la) {
				this.ja = this.ampdoc.isVisible();
				this.$ = this.h.getPrerenderSize();
				this.zd = 0;
				if (this.ub && this.tf && this.pd) {
					this.tf = !1;
					var b = this.win.document,
						c = rd(this.ampdoc);
					this.h.sendMessage(
						'documentLoaded',
						K({
							title: b.title,
							sourceUrl: Jc(this.ampdoc.getUrl()),
							serverLayout: b.documentElement.hasAttribute('i-amphtml-element'),
							linkRels: c.linkRels,
							metaTags: { viewport: c.viewport },
							viewport: c.viewport
						}),
						!0
					);
					this.Wa = this.H.getContentHeight();
					this.h.sendMessage('documentHeight', K({ height: this.Wa }), !0);
					F().fine('Resources', 'document height on load: %s', this.Wa);
				}
				var d = this.H.getSize();
				F().fine(
					'Resources',
					'PASS: visible=',
					this.ja,
					', relayoutAll=',
					this.Fa,
					', relayoutTop=',
					this.ib,
					', viewportSize=',
					d.width,
					d.height,
					', prerenderSize=',
					this.$
				);
				this.Kc.cancel();
				this.Ke = !1;
				this.zg.setState(this.ampdoc.getVisibilityState());
				!this.ub ||
					!this.pd ||
					(this.V && !this.Ef) ||
					this.ampdoc.signals().get('ready-scan') ||
					(this.ampdoc.signals().signal('ready-scan'), F().fine('Resources', 'signal: ready-scan'));
				this.ab &&
					((this.ab = !1),
					this.A.measure(function() {
						var b = a.H.getContentHeight();
						b != a.Wa &&
							(a.h.sendMessage('documentHeight', K({ height: b }), !0),
							(a.Wa = b),
							F().fine('Resources', 'document height changed: %s', a.Wa),
							a.H.contentHeightChanged());
					}));
				for (b = 0; b < this.Jc.length; b++) (0, this.Jc[b])();
				this.Jc.length = 0;
			} else F().fine('Resources', 'runtime is off');
		};
		f.getSlowElementRatio = function() {
			return 0 === this.De ? 0 : this.kg / this.De;
		};
		function Vj(a) {
			var b = Date.now(),
				c = a.H.getRect(),
				d = c.height / 10,
				e = c.height / 10,
				g = (0.01 > Math.abs(a.ce) && 500 < b - a.vc) || 1e3 < b - a.vc;
			if (0 < a.ha.length) {
				F().fine('Resources', 'change size requests:', a.ha.length);
				var h = a.ha;
				a.ha = [];
				var l = -1,
					k = [],
					n = 0;
				b = {};
				for (var r = 0; r < h.length; b = { Ua: b.Ua, ac: b.ac, G: b.G, S: b.S }, r++) {
					b.G = h[r];
					var u = b.G;
					b.Ua = u.resource;
					u = u.event;
					var w = b.Ua.getLayoutBox(),
						y = 0,
						p = 0,
						q = 0,
						H = 0,
						E = w,
						ja = E.top,
						na = E.bottom;
					b.S = void 0;
					b.G.marginChange &&
						((b.S = b.G.marginChange.newMargins),
						(E = b.G.marginChange.currentMargins),
						void 0 != b.S.top && (y = b.S.top - E.top),
						void 0 != b.S.bottom && (p = b.S.bottom - E.bottom),
						void 0 != b.S.left && (q = b.S.left - E.left),
						void 0 != b.S.right && (H = b.S.right - E.right),
						y && (ja = w.top - E.top),
						p && (na = w.bottom + E.bottom));
					var ca = b.G.newHeight - w.height;
					b.ac = b.G.newWidth - w.width;
					var D = !1;
					if (0 != ca || 0 != y || 0 != p || 0 != b.ac || 0 != q || 0 != H)
						if (b.G.force || !a.ja) D = !0;
						else if (
							a.od.hasDescendantsOf(b.Ua.element) ||
							(u && u.userActivation && u.userActivation.hasBeenActive)
						)
							D = !0;
						else if (ja >= c.bottom - e || (0 == y && w.bottom + Math.min(ca, 0) >= c.bottom - e)) D = !0;
						else if (1 < c.top && na <= c.top + d) {
							if (0 > ca && c.top + n < -ca) continue;
							g ? ((n += ca), k.push(b.G)) : a.ha.push(b.G);
							continue;
						} else
							Wj(a, b.Ua, w)
								? (D = !0)
								: 0 > ca ||
									0 > y ||
									0 > p ||
									(b.G.newHeight == w.height
										? a.A.run(
												{
													measure: (function(a) {
														return function(b) {
															b.resize = !1;
															var c = a.Ua.element.parentElement;
															if (c) {
																for (
																	var d =
																			(c.getLayoutWidth && c.getLayoutWidth()) ||
																			c.offsetWidth,
																		e = a.ac,
																		g = 0;
																	g < c.childElementCount;
																	g++
																)
																	if (((e += c.children[g].offsetWidth), e > d)) return;
																b.resize = !0;
															}
														};
													})(b),
													mutate: (function(a) {
														return function(b) {
															b.resize &&
																a.G.resource.changeSize(a.G.newHeight, a.G.newWidth, a.S);
															a.G.resource.overflowCallback(
																!b.resize,
																a.G.newHeight,
																a.G.newWidth,
																a.S
															);
														};
													})(b)
												},
												{}
											)
										: b.G.resource.overflowCallback(!0, b.G.newHeight, b.G.newWidth, b.S));
					D &&
						(0 <= w.top && (l = -1 == l ? w.top : Math.min(l, w.top)),
						b.G.resource.changeSize(b.G.newHeight, b.G.newWidth, b.S),
						b.G.resource.overflowCallback(!1, b.G.newHeight, b.G.newWidth, b.S),
						(a.ab = !0));
					b.G.callback && b.G.callback(D);
				}
				-1 != l && a.setRelayoutTop(l);
				0 < k.length &&
					a.A.run(
						{
							measure: function(b) {
								b.scrollHeight = a.H.getScrollHeight();
								b.scrollTop = a.H.getScrollTop();
							},
							mutate: function(b) {
								var c = -1;
								k.forEach(function(a) {
									var b = a.resource.getLayoutBox();
									c = -1 == c ? b.top : Math.min(c, b.top);
									a.resource.changeSize(
										a.newHeight,
										a.newWidth,
										a.marginChange ? a.marginChange.newMargins : void 0
									);
									a.callback && a.callback(!0);
								});
								-1 != c && a.setRelayoutTop(c);
								var d = a.H.getScrollHeight();
								d != b.scrollHeight && a.H.setScrollTop(b.scrollTop + (d - b.scrollHeight));
								a.ab = !0;
							}
						},
						{}
					);
			}
		}
		function Wj(a, b, c) {
			var d = a.H.getContentHeight();
			a = Math.max(0.85 * d, d - 1e3);
			var e = c || b.getLayoutBox(),
				g = b.getInitialLayoutBox();
			return e.bottom >= a || g.bottom >= a;
		}
		function Xj(a, b) {
			b = void 0 === b ? !1 : b;
			var c = a.isDisplayed();
			a.measure(b);
			return !(c && !a.isDisplayed());
		}
		function Yj(a, b) {
			b.length &&
				a.A.mutate(function() {
					b.forEach(function(b) {
						b.unload();
						Uj(a, b);
					});
					F().fine('Resources', 'unload:', b);
				});
		}
		function Zj(a) {
			a.nf ||
				((a.nf = !0),
				Qc(a.win, [
					{
						experimentId: 'render-on-idle-fix',
						isTrafficEligible: function() {
							return !0;
						},
						branches: [ '21066311', '21066312' ]
					}
				]));
		}
		function Rj(a, b) {
			b = void 0 === b ? Date.now() : b;
			Zj(a);
			var c = a.ra.getLastDequeueTime();
			(b = 0 == a.ra.getSize() && 0 == a.F.getSize() && b > c + 5e3) &&
				!(b = 0 < c || !a.Kh) &&
				((a = a.win),
				(b =
					'21066311' ===
					(a.__AMP_EXPERIMENT_BRANCHES ? a.__AMP_EXPERIMENT_BRANCHES['render-on-idle-fix'] : null)));
			return b;
		}
		f.Kg = function(a) {
			var b = this.H.getRect(),
				c = a.resource.getLayoutBox(),
				d = Math.floor((c.top - b.top) / b.height);
			Math.sign(d) != this.getScrollDirection() && (d *= 2);
			d = Math.abs(d);
			return 10 * a.priority + d;
		};
		function ak(a, b) {
			var c = Date.now();
			if (0 == a.ra.getSize()) return -1 === a.yb ? 0 : Math.max(1e3 * b.priority - (c - a.yb), 0);
			var d = 0;
			a.ra.forEach(function(a) {
				d = Math.max(d, Math.max(1e3 * (b.priority - a.priority), 0) - (c - a.startTime));
			});
			return d;
		}
		f.Lh = function(a) {
			this.F.getTaskById(a.id) || this.F.enqueue(a);
		};
		f.mg = function(a, b, c) {
			this.De++;
			a.resource.isInViewport() && 0 <= this.yb && this.kg++;
			this.ra.dequeue(a);
			this.schedulePass(1e3);
			if (!b) return F().info('Resources', 'task failed:', a.id, a.resource.debugid, c), Promise.reject(c);
		};
		function bk(a, b, c) {
			return 0 != b.getState() &&
			b.isDisplayed() &&
			(a.ja || ('prerender' == a.ampdoc.getVisibilityState() && b.prerenderAllowed())) &&
			(c || b.isInViewport() || b.renderOutsideViewport() || b.idleRenderOutsideViewport())
				? !0
				: !1;
		}
		f.scheduleLayoutOrPreload = function(a, b, c, d) {
			a.getState();
			a.isDisplayed();
			d = d || !1;
			bk(this, a, d) &&
				(b
					? this.xa(a, 'L', 0, c || 0, d, a.startLayout.bind(a))
					: this.xa(a, 'P', 2, c || 0, d, a.startLayout.bind(a)));
		};
		f.xa = function(a, b, c, d, e, g) {
			b = a.getTaskId(b);
			a = {
				id: b,
				resource: a,
				priority: Math.max(a.getLayoutPriority(), d) + c,
				forceOutsideViewport: e,
				callback: g,
				scheduleTime: Date.now(),
				startTime: 0,
				promise: null
			};
			F().fine('Resources', 'schedule:', a.id, 'at', a.scheduleTime);
			var h = this.F.getTaskById(b);
			if (!h || a.priority < h.priority)
				h && this.F.dequeue(h),
					this.F.enqueue(a),
					this.Pc ? this.schedulePass() : this.schedulePass(ak(this, a));
			a.resource.layoutScheduled(a.scheduleTime);
		};
		f.whenFirstPass = function() {
			return this.uf.promise;
		};
		function Nj(a, b) {
			function c() {
				a.j.forEach(function(a) {
					return a.resume();
				});
				h();
			}
			function d() {
				a.j.forEach(function(b) {
					b.unload();
					Uj(a, b);
				});
				try {
					a.win.getSelection().removeAllRanges();
				} catch (l) {}
			}
			function e() {
				a.j.forEach(function(a) {
					return a.pause();
				});
			}
			function g() {}
			function h() {
				var b = a.H.getSize();
				if (0 < b.height && 0 < b.width) {
					0 < a.ha.length && Vj(a);
					b = Date.now();
					var c = a.Fa,
						d = a.ib,
						e = a.Hd;
					a.Fa = !1;
					a.ib = -1;
					for (var g = 0, h = 0, y = 0; y < a.j.length; y++) {
						var p = a.j[y];
						0 != p.getState() || p.isBuilding() || Qj(a, p, !0);
						if (a.V)
							c &&
								(p.applySizesAndMediaQuery(),
								F().fine('Resources', 'apply sizes/media query:', p.debugid));
						else if (c || !p.hasBeenMeasured() || 1 == p.getState())
							p.applySizesAndMediaQuery(),
								F().fine('Resources', 'apply sizes/media query:', p.debugid),
								g++;
						p.isMeasureRequested() && h++;
					}
					var q;
					if (a.V)
						for (c = 0; c < a.j.length; c++)
							(d = a.j[c]),
								d.hasOwner() ||
									((g = d.isMeasureRequested()) &&
										F().fine('Resources', 'force remeasure:', d.debugid),
									((h = d.hasBeenPremeasured()) || g || a.Fa) &&
										!Xj(d, h) &&
										(d.getState(), q || (q = []), q.push(d)));
					else if (0 < g || 0 < h || c || -1 != d || 0 < e.length)
						for (g = 0; g < a.j.length; g++)
							if (((h = a.j[g]), !h.hasOwner() || h.isMeasureRequested())) {
								y =
									c ||
									1 == h.getState() ||
									!h.hasBeenMeasured() ||
									h.isMeasureRequested() ||
									(-1 != d && h.getLayoutBox().bottom >= d);
								if (!y)
									for (p = 0; p < e.length; p++)
										if (e[p].contains(h.element)) {
											y = !0;
											break;
										}
								y && !Xj(h) && (q || (q = []), q.push(h));
							}
					e.length = 0;
					q && Yj(a, q);
					e = a.H.getRect();
					q = a.ja ? hc(e, 0.25, 2) : 0 < a.$ ? hc(e, 0, a.$ - 1) : null;
					e = a.ja ? hc(e, 0.25, 0.25) : e;
					for (c = 0; c < a.j.length; c++)
						(d = a.j[c]),
							0 == d.getState() ||
								d.hasOwner() ||
								((g = a.ja && d.isDisplayed() && d.overlaps(e)), d.setInViewport(g));
					if (q)
						for (e = 0; e < a.j.length; e++)
							(c = a.j[e]),
								!c.isBuilt() &&
									!c.isBuilding() &&
									!c.hasOwner() &&
									c.hasBeenMeasured() &&
									c.isDisplayed() &&
									c.overlaps(q) &&
									Qj(a, c, !0, !0),
								2 != c.getState() ||
									c.hasOwner() ||
									(c.isDisplayed() && c.overlaps(q) && a.scheduleLayoutOrPreload(c, !0));
					if (a.ja && Rj(a, b)) {
						for (q = b = 0; q < a.j.length && 4 > b; q++)
							(e = a.j[q]),
								2 == e.getState() &&
									!e.hasOwner() &&
									e.isDisplayed() &&
									e.idleRenderOutsideViewport() &&
									(F().fine('Resources', 'idleRenderOutsideViewport layout:', e.debugid),
									a.scheduleLayoutOrPreload(e, !1),
									b++);
						for (q = 0; q < a.j.length && 4 > b; q++)
							(e = a.j[q]),
								2 == e.getState() &&
									!e.hasOwner() &&
									e.isDisplayed() &&
									(F().fine('Resources', 'idle layout:', e.debugid),
									a.scheduleLayoutOrPreload(e, !1),
									b++);
					}
					b = Date.now();
					e = -1;
					for (q = a.F.peek(a.yd); q; ) {
						a.Pc || (e = ak(a, q));
						F().fine(
							'Resources',
							'peek from queue:',
							q.id,
							'sched at',
							q.scheduleTime,
							'score',
							a.yd(q),
							'timeout',
							e
						);
						if (!a.Pc && 16 < e) break;
						a.F.dequeue(q);
						(e = a.ra.getTaskById(q.id))
							? ((q = a.Lh.bind(a, q)), e.promise.then(q, q))
							: ((e = q.resource),
								(c = !0),
								a.V ? e.hasBeenPremeasured() && (c = e.isDisplayed(!0)) : e.measure(),
								c && bk(a, e, q.forceOutsideViewport)
									? ((q.promise = q.callback()),
										(q.startTime = b),
										F().fine('Resources', 'exec:', q.id, 'at', q.startTime),
										a.ra.enqueue(q),
										q.promise.then(a.mg.bind(a, q, !0), a.mg.bind(a, q, !1)).catch(Bf))
									: (F().fine('Resources', 'cancelled', q.id), e.layoutCanceled()));
						q = a.F.peek(a.yd);
						e = -1;
					}
					F().fine('Resources', 'queue size:', a.F.getSize(), 'exec size:', a.ra.getSize());
					!a.Pc && 0 <= e
						? (b = e)
						: ((b = 2 * (b - a.ra.getLastDequeueTime())), (b = Math.max(Math.min(3e4, b), 5e3)));
					0 < a.ha.length && (b = Math.min(b, 500));
					a.ja
						? a.schedulePass(b)
							? F().fine('Resources', 'next pass:', b)
							: F().fine('Resources', 'pass already scheduled')
						: F().fine('Resources', 'document is not visible: no scheduling');
					a.uf.resolve();
				}
			}
			b.addTransition('prerender', 'prerender', h);
			b.addTransition('prerender', 'visible', h);
			b.addTransition('prerender', 'hidden', h);
			b.addTransition('prerender', 'inactive', h);
			b.addTransition('prerender', 'paused', h);
			b.addTransition('visible', 'visible', h);
			b.addTransition('visible', 'hidden', h);
			b.addTransition('visible', 'inactive', d);
			b.addTransition('visible', 'paused', e);
			b.addTransition('hidden', 'visible', h);
			b.addTransition('hidden', 'hidden', h);
			b.addTransition('hidden', 'inactive', d);
			b.addTransition('hidden', 'paused', e);
			b.addTransition('inactive', 'visible', c);
			b.addTransition('inactive', 'hidden', c);
			b.addTransition('inactive', 'inactive', g);
			b.addTransition('inactive', 'paused', h);
			b.addTransition('paused', 'visible', c);
			b.addTransition('paused', 'hidden', h);
			b.addTransition('paused', 'inactive', d);
			b.addTransition('paused', 'paused', g);
		}
		function Uj(a, b, c) {
			1 == b.getState() &&
				(a.F.purge(function(a) {
					return a.resource == b;
				}),
				a.ra.purge(function(a) {
					return a.resource == b;
				}),
				kg(a.ha, function(a) {
					return a.resource === b;
				}));
			if (0 == b.getState() && c && a.va) {
				var d = a.va.indexOf(b);
				-1 != d && a.va.splice(d, 1);
			}
		}
		var ck = /^i-amphtml-/;
		function dk(a, b) {
			this.ampdoc = a;
			b = b ? b.document.documentElement : a.getHeadNode();
			this.fb = td(a);
			this.H = wd(a);
			a = Tc(b, 'action');
			a.addGlobalTarget('AMP', this.Xg.bind(this));
			a.addGlobalMethodHandler('hide', this.yf.bind(this));
			a.addGlobalMethodHandler('show', this.Bf.bind(this));
			a.addGlobalMethodHandler('toggleVisibility', this.ah.bind(this));
			a.addGlobalMethodHandler('scrollTo', this.Af.bind(this));
			a.addGlobalMethodHandler('focus', this.Yg.bind(this));
			a.addGlobalMethodHandler('toggleClass', this.$g.bind(this));
		}
		dk.installInEmbedWindow = function(a, b) {
			Zc(a, 'standard-actions', new dk(b, a));
		};
		f = dk.prototype;
		f.Xg = function(a) {
			if (!a.satisfiesTrust(2)) return null;
			var b = a.node,
				c = a.method,
				d = a.args,
				e = (b.ownerDocument || b).defaultView;
			switch (c) {
				case 'pushState':
				case 'setState':
					return md(b.nodeType === Node.DOCUMENT_NODE ? b.documentElement : b).then(function(b) {
						G(b, 'AMP-BIND is not installed.');
						return b.invoke(a);
					});
				case 'navigateTo':
					return ek(this, a);
				case 'closeOrNavigateTo':
					return fk(this, a);
				case 'scrollTo':
					return (
						G(d.id, 'AMP.scrollTo must provide element ID'),
						(a.node = Xc(b).getElementById(d.id)),
						this.Af(a)
					);
				case 'goBack':
					return bd(this.ampdoc, 'history').goBack(!(!d || !0 !== d.navigate)), null;
				case 'print':
					return e.print(), null;
				case 'optoutOfCid':
					return gd(Yc(this.ampdoc), 'cid')
						.then(function(a) {
							return a.optOut();
						})
						.catch(function(a) {
							F().error('STANDARD-ACTIONS', 'Failed to opt out of CID', a);
						});
			}
			throw C().createError('Unknown AMP action ', c);
		};
		function ek(a, b) {
			var c = b.node,
				d = b.caller,
				e = b.method,
				g = b.args,
				h = (c.ownerDocument || c).defaultView;
			b = x();
			M(d.tagName, 'AMP-') &&
				(b = d.getImpl().then(function(a) {
					'function' == typeof a.throwIfCannotNavigate && a.throwIfCannotNavigate();
				}));
			return b.then(
				function() {
					bd(a.ampdoc, 'navigation').navigateTo(h, g.url, 'AMP.' + e, { target: g.target, opener: g.opener });
				},
				function(a) {
					C().error('STANDARD-ACTIONS', a.message);
				}
			);
		}
		function fk(a, b) {
			var c = b.node;
			c = (c.ownerDocument || c).defaultView;
			var d = c.parent != c,
				e = !1;
			c.opener && a.ampdoc.isSingleDoc() && !d && (c.close(), (e = c.closed));
			return e ? x() : ek(a, b);
		}
		f.Af = function(a) {
			var b = a.node,
				c = (a = a.args) && a.position,
				d = a && a.duration;
			c && ![ 'top', 'bottom', 'center' ].includes(c) && (c = void 0);
			Pa(d) || (d = void 0);
			return this.H.animateScrollIntoView(b, c, d);
		};
		f.Yg = function(a) {
			Pb(a.node);
			return null;
		};
		f.yf = function(a) {
			var b = a.node;
			b.classList.contains('i-amphtml-element')
				? this.fb.mutateElement(
						b,
						function() {
							return b.collapse();
						},
						!0
					)
				: this.fb.mutateElement(b, function() {
						return re(b, !1);
					});
			return null;
		};
		f.Bf = function(a) {
			var b = a.node,
				c = b.ownerDocument.defaultView;
			if (b.classList.contains('i-amphtml-layout-nodisplay'))
				return (
					C().warn('STANDARD-ACTIONS', 'Elements with layout=nodisplay cannot be dynamically shown.', b), null
				);
			this.fb.measureElement(function() {
				'none' != se(c, b).display ||
					b.hasAttribute('hidden') ||
					C().warn(
						'STANDARD-ACTIONS',
						'Elements can only be dynamically shown when they have the "hidden" attribute set or when they were dynamically hidden.',
						b
					);
			});
			var d = b.hasAttribute('autofocus') ? b : b.querySelector('[autofocus]');
			d && T(c).isIos()
				? (gk(b, d), this.fb.mutateElement(b, function() {}))
				: this.fb.mutateElement(b, function() {
						gk(b, d);
					});
			return null;
		};
		function gk(a, b) {
			a.classList.contains('i-amphtml-element') ? a.expand() : re(a, !0);
			b && Pb(b);
		}
		f.ah = function(a) {
			return a.node.hasAttribute('hidden') ? this.Bf(a) : this.yf(a);
		};
		f.$g = function(a) {
			var b = a.node,
				c = a.args,
				d = C().assertString(c['class'], "Argument 'class' must be a string.");
			if (ck.test(d)) return null;
			this.fb.mutateElement(b, function() {
				if (void 0 !== c.force) {
					var a = C().assertBoolean(c.force, "Optional argument 'force' must be a boolean.");
					b.classList.toggle(d, a);
				} else b.classList.toggle(d);
			});
			return null;
		};
		function hk(a, b, c) {
			this.ampdoc = a;
			this.h = b;
			this.o = c;
			this.Gc = Kc(this.ampdoc.win.location);
			this.Xc = null;
		}
		f = hk.prototype;
		f.get = function(a) {
			return ik(this).then(function(b) {
				return b.get(a);
			});
		};
		f.set = function(a, b, c) {
			return this.setNonBoolean(a, b, c);
		};
		f.setNonBoolean = function(a, b, c) {
			return jk(this, function(d) {
				return d.set(a, b, c);
			});
		};
		f.remove = function(a) {
			return jk(this, function(b) {
				return b.remove(a);
			});
		};
		function ik(a) {
			a.Xc ||
				(a.Xc = a.o
					.loadBlob(a.Gc)
					.then(function(a) {
						return a ? Tb(atob(a)) : {};
					})
					.catch(function(a) {
						F().expectedError('Storage', 'Failed to load store: ', a);
						return {};
					})
					.then(function(a) {
						return new kk(a);
					}));
			return a.Xc;
		}
		function jk(a, b) {
			return ik(a)
				.then(function(c) {
					b(c);
					c = btoa(JSON.stringify(c.obj));
					return a.o.saveBlob(a.Gc, c);
				})
				.then(a.Ig.bind(a));
		}
		function lk(a) {
			a.h.onBroadcast(function(b) {
				'amp-storage-reset' == b.type &&
					b.origin == a.Gc &&
					(F().fine('Storage', 'Received reset message'), (a.Xc = null));
			});
		}
		f.Ig = function() {
			F().fine('Storage', 'Broadcasted reset message');
			this.h.broadcast({ type: 'amp-storage-reset', origin: this.Gc });
		};
		function kk(a) {
			this.obj = Rb(a);
			this.qh = 8;
			this.Aa = this.obj.vv || Object.create(null);
			this.obj.vv || (this.obj.vv = this.Aa);
		}
		kk.prototype.get = function(a) {
			return (a = this.Aa[a]) ? a.v : void 0;
		};
		kk.prototype.set = function(a, b, c) {
			if (void 0 !== this.Aa[a]) {
				a = this.Aa[a];
				var d = Date.now();
				c && (d = a.t);
				a.v = b;
				a.t = d;
			} else this.Aa[a] = K({ v: b, t: Date.now() });
			b = Object.keys(this.Aa);
			if (b.length > this.qh) {
				var e = Infinity,
					g = null;
				for (c = 0; c < b.length; c++) (a = this.Aa[b[c]]), a.t < e && ((g = b[c]), (e = a.t));
				g && delete this.Aa[g];
			}
		};
		kk.prototype.remove = function(a) {
			delete this.Aa[a];
		};
		function mk(a) {
			this.win = a;
			try {
				if ('localStorage' in this.win) {
					this.win.localStorage.getItem('test');
					var b = !0;
				} else b = !1;
			} catch (c) {
				b = !1;
			}
			this.Yd = b;
			this.Yd || ((a = Error('localStorage not supported.')), F().expectedError('Storage', a));
		}
		mk.prototype.loadBlob = function(a) {
			var b = this;
			return new Promise(function(c) {
				b.Yd ? c(b.win.localStorage.getItem('amp-store:' + a)) : c(null);
			});
		};
		mk.prototype.saveBlob = function(a, b) {
			var c = this;
			return new Promise(function(d) {
				c.Yd && c.win.localStorage.setItem('amp-store:' + a, b);
				d();
			});
		};
		function nk(a) {
			this.h = a;
		}
		nk.prototype.loadBlob = function(a) {
			return this.h.sendMessageAwaitResponse('loadStore', K({ origin: a })).then(function(a) {
				return a.blob;
			});
		};
		nk.prototype.saveBlob = function(a, b) {
			return this.h.sendMessageAwaitResponse('saveStore', K({ origin: a, blob: b })).catch(function(a) {
				throw F().createExpectedError('Storage', 'Failed to save store: ', a);
			});
		};
		function ok(a) {
			R(
				a,
				'storage',
				function() {
					var b = V(a),
						c = parseInt(b.getParam('storage'), 10) ? new nk(b) : new mk(a.win);
					b = new hk(a, b, c);
					lk(b);
					return b;
				},
				!0
			);
		}
		function pk(a) {
			this.win = a;
			this.Oh = this.win.Promise.resolve();
			this.Zh = 0;
			this.Ad = {};
			this.ze = Date.now();
		}
		f = pk.prototype;
		f.timeSinceStart = function() {
			return Date.now() - this.ze;
		};
		f.delay = function(a, b) {
			var c = this;
			if (!b) {
				var d = 'p' + this.Zh++;
				this.Oh
					.then(function() {
						c.Ad[d] ? delete c.Ad[d] : a();
					})
					.catch(Bf);
				return d;
			}
			return this.win.setTimeout(function() {
				try {
					a();
				} catch (e) {
					throw (Bf(e), e);
				}
			}, b);
		};
		f.cancel = function(a) {
			'string' == typeof a ? (this.Ad[a] = !0) : this.win.clearTimeout(a);
		};
		f.promise = function(a) {
			var b = this;
			return new this.win.Promise(function(c) {
				if (-1 == b.delay(c, a)) throw Error('Failed to schedule timer.');
			});
		};
		f.timeoutPromise = function(a, b, c) {
			function d() {
				e.cancel(g);
			}
			var e = this,
				g,
				h = new this.win.Promise(function(b, d) {
					g = e.delay(function() {
						d(C().createError(c || 'timeout'));
					}, a);
					if (-1 == g) throw Error('Failed to schedule timer.');
				});
			if (!b) return h;
			b.then(d, d);
			return this.win.Promise.race([ h, b ]);
		};
		f.poll = function(a, b) {
			var c = this;
			return new this.win.Promise(function(d) {
				var e = c.win.setInterval(function() {
					b() && (c.win.clearInterval(e), d());
				}, a);
			});
		};
		function qk(a, b) {
			a = b || a.getRootNode();
			this.Cg = (a.ownerDocument || a).createElement('a');
			this.Va = new nc();
		}
		qk.installInEmbedWindow = function(a, b) {
			Zc(a, 'url', new qk(b, a.document));
		};
		f = qk.prototype;
		f.parse = function(a, b) {
			return xc(this.Cg, a, b ? null : this.Va);
		};
		function rk(a, b) {
			return 'string' !== typeof b ? b : a.parse(b);
		}
		f.isProtocolValid = function(a) {
			return Gc(a);
		};
		f.getSourceOrigin = function(a) {
			return Kc(rk(this, a));
		};
		f.getSourceUrl = function(a) {
			return Jc(rk(this, a));
		};
		f.assertHttpsUrl = function(a, b, c) {
			return Ec(a, b, void 0 === c ? 'source' : c);
		};
		f.assertAbsoluteHttpOrHttpsUrl = function(a) {
			G(/^https?:/i.test(a), 'URL must start with "http://" or "https://". Invalid value: %s', a);
			return N(a).href;
		};
		f.isProxyOrigin = function(a) {
			return O(rk(this, a));
		};
		f.isSecure = function(a) {
			return Dc(rk(this, a));
		};
		f.getWinOrigin = function(a) {
			return a.origin || rk(this, a.location.href).origin;
		};
		f.getCdnUrlOnOrigin = function(a) {
			if (O(a)) return a;
			var b = rk(this, a),
				c = b.hash,
				d = b.pathname,
				e = b.search,
				g = encodeURIComponent(b.host);
			return B.cdn + '/c/' + g + d + e + c;
		};
		var sk = {
			navigationStart: 1,
			redirectStart: 1,
			redirectEnd: 1,
			fetchStart: 1,
			domainLookupStart: 1,
			domainLookupEnd: 1,
			connectStart: 1,
			secureConnectionStart: 1,
			connectEnd: 1,
			requestStart: 1,
			responseStart: 1,
			responseEnd: 1,
			domLoading: 2,
			domInteractive: 2,
			domContentLoaded: 2,
			domComplete: 2,
			loadEventStart: 3,
			loadEventEnd: 4
		};
		function tk(a, b, c) {
			var d = sk[b] || 3,
				e = Math.max(d, c ? sk[c] || 3 : d);
			if (1 === e) var g = x();
			else if (2 === e) g = Aj(a.document);
			else if (3 === e) g = Qe(a);
			else if (4 === e) {
				var h = U(a);
				g = Qe(a).then(function() {
					return h.promise(1);
				});
			}
			return g.then(function() {
				return uk(a, b, c);
			});
		}
		function uk(a, b, c) {
			var d = a.performance && a.performance.timing;
			if (d && 0 != d.navigationStart) {
				var e = void 0 === c ? d[b] : d[c] - d[b];
				if (Pa(e) && !(0 > e)) return e;
			}
		}
		function vk(a, b) {
			var c = a.performance && a.performance.navigation;
			if (c && void 0 !== c[b]) return c[b];
		}
		function wk(a) {
			this.ampdoc = a;
			this.Ga = Object.create(null);
			this.Td = !1;
			xk(this);
		}
		f = wk.prototype;
		f.oc = function() {
			this.initialize();
			this.Td = !0;
		};
		f.initialize = function() {};
		f.get = function(a) {
			this.Td || this.oc();
			return this.Ga[a];
		};
		f.set = function(a, b) {
			a.indexOf('RETURN');
			this.Ga[a] = this.Ga[a] || { sync: void 0, async: void 0 };
			this.Ga[a].sync = b;
			return this;
		};
		f.setAsync = function(a, b) {
			a.indexOf('RETURN');
			this.Ga[a] = this.Ga[a] || { sync: void 0, async: void 0 };
			this.Ga[a].async = b;
			return this;
		};
		f.setBoth = function(a, b, c) {
			return this.set(a, b).setAsync(a, c);
		};
		f.getExpr = function(a, b) {
			this.Td || this.oc();
			var c = Object.assign({}, this.Ga, a);
			return yk(this, Object.keys(c), b);
		};
		function yk(a, b, c) {
			xk(a) &&
				(b = b.filter(function(b) {
					return xk(a).includes(b);
				}));
			c &&
				(b = b.filter(function(a) {
					return c[a];
				}));
			if (0 === b.length) return /_^/g;
			b.sort(function(a, b) {
				return b.length - a.length;
			});
			var d =
				'\\$?(' +
				b
					.map(function(a) {
						return '$' === a[0] ? '\\' + a : a;
					})
					.join('|') +
				')';
			return new RegExp(d, 'g');
		}
		function xk(a) {
			if (a.He) return a.He;
			if (a.ampdoc.isSingleDoc()) {
				var b = a.ampdoc.getRootNode();
				if (tf([ '\u26a14email', 'amp4email' ], b)) return (a.He = [ '' ]), a.He;
			}
		}
		function zk(a, b, c, d, e, g) {
			this.ia = a;
			this.ob = b;
			this.jf = c;
			this.jb = d;
			this.ka = e;
			this.Tg = !g;
		}
		zk.prototype.expand = function(a) {
			if (!a.length) return this.jb ? a : Promise.resolve(a);
			var b = this.ia.getExpr(this.ob, this.ka);
			b = Ak(a, b);
			return b.length ? Bk(this, a, b) : this.jb ? a : Promise.resolve(a);
		};
		zk.prototype.getMacroNames = function(a) {
			var b = this.ia.getExpr(this.ob, this.ka);
			return (a = a.match(b)) ? a : [];
		};
		function Ak(a, b) {
			var c = [];
			a.replace(b, function(a, b, g) {
				a = a.length;
				c.push({ start: g, stop: a + g - 1, name: b, length: a });
			});
			return c;
		}
		function Bk(a, b, c) {
			function d(r) {
				for (var u = '', w = [], y = []; g < b.length && h <= c.length; ) {
					var p = u.trim();
					if (l && g === l.start)
						p && w.push(k ? tb(u) : u),
							(u = void 0),
							(u =
								a.ob && mb.call(a.ob, l.name)
									? { name: l.name, prioritized: a.ob[l.name], encode: r }
									: Object.assign({}, a.ia.get(l.name), { name: l.name, encode: r })),
							(g = l.stop + 1),
							(l = c[++h]),
							'(' === b[g] ? (g++, k++, e.push(u), w.push(d(!1))) : w.push(Ck(a, u)),
							(u = '');
					else {
						if ('`' === b[g]) n ? ((n = !1), u.length && w.push(u)) : ((n = !0), p && w.push(p)), (u = '');
						else if (k && ',' === b[g] && !n)
							p && w.push(p), y.push(w), (w = []), ',' === b[g + 1] && (y.push([ '' ]), g++), (u = '');
						else {
							if (k && ')' === b[g] && !n)
								return g++, k--, (u = e.pop()), p && w.push(p), y.push(w), Ck(a, u, y);
							u += b[g];
						}
						g++;
					}
					g === b.length && u.length && w.push(u);
				}
				return a.jb
					? w.join('')
					: Promise.all(w)
							.then(function(a) {
								return a.join('');
							})
							.catch(function(a) {
								hb(a);
								return '';
							});
			}
			var e = [],
				g = 0,
				h = 0,
				l = c[h],
				k = 0,
				n = !1;
			return d(a.Tg);
		}
		function Ck(a, b, c) {
			var d = b.encode,
				e = b.name;
			if (void 0 != b.prioritized) var g = b.prioritized;
			else
				a.jb && void 0 != b.sync
					? (g = b.sync)
					: a.jb
						? (C().error('Expander', 'ignoring async replacement key: ', b.name), (g = ''))
						: (g = b.async || b.sync);
			return a.jb
				? ((a = Dk(a, g, e, c)), d ? encodeURIComponent(a) : a)
				: Ek(a, g, e, c).then(function(a) {
						return d ? encodeURIComponent(a) : a;
					});
		}
		function Ek(a, b, c, d) {
			try {
				var e =
					'function' === typeof b
						? d
							? Fk(d).then(function(a) {
									return b.apply(null, a);
								})
							: nb(b)
						: Promise.resolve(b);
				return e
					.then(function(b) {
						Gk(a, c, b, d);
						return null == b ? '' : b;
					})
					.catch(function(b) {
						hb(b);
						Gk(a, c, '', d);
						return Promise.resolve('');
					});
			} catch (g) {
				return hb(g), Gk(a, c, '', d), Promise.resolve('');
			}
		}
		function Fk(a) {
			return Promise.all(
				a.map(function(a) {
					return Promise.all(a).then(function(a) {
						return a.join('');
					});
				})
			);
		}
		function Dk(a, b, c, d) {
			try {
				var e = b;
				'function' === typeof b && (e = b.apply(null, Hk(d)));
				if (e && e.then) {
					C().error('Expander', 'ignoring async macro resolution');
					var g = '';
				} else
					'string' === typeof e || 'number' === typeof e || 'boolean' === typeof e
						? (Gk(a, c, e, d), (g = e.toString()))
						: (Gk(a, c, '', d), (g = ''));
				return g;
			} catch (h) {
				return hb(h), Gk(a, c, '', d), '';
			}
		}
		function Hk(a) {
			return a
				? a.map(function(a) {
						return a.join('');
					})
				: a;
		}
		function Gk(a, b, c, d) {
			if (a.jf) {
				var e = '';
				d &&
					(e =
						'(' +
						d
							.filter(function(a) {
								return '' !== a;
							})
							.join(',') +
						')');
				a.jf['' + b + e] = c || '';
			}
		}
		function Ik(a) {
			return function() {
				return new Date()[a]();
			};
		}
		function Jk(a, b) {
			return function() {
				return a[b];
			};
		}
		function Kk() {
			wk.apply(this, arguments);
		}
		m(Kk, wk);
		function Lk(a, b, c, d) {
			a.setBoth(
				b,
				function() {
					return uk(a.ampdoc.win, c, d);
				},
				function() {
					return tk(a.ampdoc.win, c, d);
				}
			);
		}
		Kk.prototype.initialize = function() {
			function a() {
				var a = Mk(b);
				return Fc(Nk(b, a.sourceUrl));
			}
			var b = this,
				c = this.ampdoc.win,
				d = this.ampdoc.getHeadNode(),
				e = wd(this.ampdoc);
			this.set('RANDOM', function() {
				return Math.random();
			});
			var g = Object.create(null);
			this.set('COUNTER', function(a) {
				return (g[a] = (g[a] | 0) + 1);
			});
			this.set('CANONICAL_URL', function() {
				return Mk(b).canonicalUrl;
			});
			this.set('CANONICAL_HOST', function() {
				return N(Mk(b).canonicalUrl).host;
			});
			this.set('CANONICAL_HOSTNAME', function() {
				return N(Mk(b).canonicalUrl).hostname;
			});
			this.set('CANONICAL_PATH', function() {
				return N(Mk(b).canonicalUrl).pathname;
			});
			this.setAsync('DOCUMENT_REFERRER', function() {
				return V(b.ampdoc).getReferrerUrl();
			});
			this.setAsync('EXTERNAL_REFERRER', function() {
				return V(b.ampdoc).getReferrerUrl().then(function(a) {
					return a ? (N(Jc(a)).hostname === c.location.hostname ? null : a) : null;
				});
			});
			this.set('TITLE', function() {
				var a = c.document;
				return a.originalTitle || a.title;
			});
			this.set('AMPDOC_URL', function() {
				return Fc(Nk(b, c.location.href));
			});
			this.set('AMPDOC_HOST', function() {
				var a = N(c.location.href);
				return a && a.host;
			});
			this.set('AMPDOC_HOSTNAME', function() {
				var a = N(c.location.href);
				return a && a.hostname;
			});
			this.setBoth(
				'SOURCE_URL',
				function() {
					return a();
				},
				function() {
					return sh().then(function() {
						return a();
					});
				}
			);
			this.set('SOURCE_HOST', function() {
				return N(Mk(b).sourceUrl).host;
			});
			this.set('SOURCE_HOSTNAME', function() {
				return N(Mk(b).sourceUrl).hostname;
			});
			this.set('SOURCE_PATH', function() {
				return N(Mk(b).sourceUrl).pathname;
			});
			this.set('PAGE_VIEW_ID', function() {
				return Mk(b).pageViewId;
			});
			this.setAsync('PAGE_VIEW_ID_64', function() {
				return Mk(b).pageViewId64;
			});
			this.setBoth(
				'QUERY_PARAM',
				function(a, c) {
					return Ok(b, a, void 0 === c ? '' : c);
				},
				function(a, c) {
					c = void 0 === c ? '' : c;
					return sh().then(function() {
						return Ok(b, a, c);
					});
				}
			);
			this.set('FRAGMENT_PARAM', function(a, c) {
				c = void 0 === c ? '' : c;
				G(a, 'The first argument to FRAGMENT_PARAM, the fragment string param is required');
				G('string' == typeof a, 'param should be a string');
				var d = t(b.ampdoc.win.location.originalHash);
				return void 0 === d[a] ? c : d[a];
			});
			var h = null;
			this.setBoth(
				'CLIENT_ID',
				function(a) {
					return h ? h[a] : null;
				},
				function(a, c, e) {
					G(a, 'The first argument to CLIENT_ID, the fallback Cookie name, is required');
					var g = x();
					c &&
						(g = jd(d, 'userNotificationManager', 'amp-user-notification').then(function(a) {
							return a.get(c);
						}));
					return gd(Yc(b.ampdoc), 'cid')
						.then(function(b) {
							return b.get({ scope: a, createCookieIfNotPresent: !0, cookieName: e }, g);
						})
						.then(function(b) {
							h || (h = Object.create(null));
							var c = e || a;
							b &&
								'_ga' == c &&
								('string' === typeof b
									? (b = b.replace(/^(GA1|1)\.[\d-]+\./, ''))
									: F().error('UrlReplacements', 'non-string cid, what is it?', Object.keys(b)));
							return (h[a] = b);
						});
				}
			);
			this.setAsync('VARIANT', function(a) {
				return Pk(
					b,
					function(b) {
						var c = b[a];
						G(
							void 0 !== c,
							'The value passed to VARIANT() is not a valid experiment in <amp-experiment>:' + a
						);
						return null === c ? 'none' : c;
					},
					'VARIANT'
				);
			});
			this.setAsync('VARIANTS', function() {
				return Pk(
					b,
					function(a) {
						var b = [],
							c;
						for (c in a) b.push(c + '.' + (a[c] || 'none'));
						return b.join('!');
					},
					'VARIANTS'
				);
			});
			this.setAsync('AMP_GEO', function(a) {
				return Qk(b, function(b) {
					return a
						? (G('ISOCountry' === a, 'The value passed to AMP_GEO() is not valid name:' + a),
							b[a] || 'unknown')
						: b.matchedISOCountryGroups.join(',');
				});
			});
			this.set('TIMESTAMP', Ik('getTime'));
			this.set('TIMESTAMP_ISO', Ik('toISOString'));
			this.set('TIMEZONE', Ik('getTimezoneOffset'));
			this.set('SCROLL_HEIGHT', function() {
				return e.getScrollHeight();
			});
			this.set('SCROLL_WIDTH', function() {
				return e.getScrollWidth();
			});
			this.set('VIEWPORT_HEIGHT', function() {
				return e.getHeight();
			});
			this.set('VIEWPORT_WIDTH', function() {
				return e.getWidth();
			});
			var l = c.screen;
			this.set('SCREEN_WIDTH', Jk(l, 'width'));
			this.set('SCREEN_HEIGHT', Jk(l, 'height'));
			this.set('AVAILABLE_SCREEN_HEIGHT', Jk(l, 'availHeight'));
			this.set('AVAILABLE_SCREEN_WIDTH', Jk(l, 'availWidth'));
			this.set('SCREEN_COLOR_DEPTH', Jk(l, 'colorDepth'));
			this.set('DOCUMENT_CHARSET', function() {
				var a = c.document;
				return a.characterSet || a.charset;
			});
			this.set('BROWSER_LANGUAGE', function() {
				var a = c.navigator;
				return (a.language || a.userLanguage || a.browserLanguage || '').toLowerCase();
			});
			this.set('USER_AGENT', function() {
				return c.navigator.userAgent;
			});
			Lk(this, 'PAGE_LOAD_TIME', 'navigationStart', 'loadEventStart');
			Lk(this, 'DOMAIN_LOOKUP_TIME', 'domainLookupStart', 'domainLookupEnd');
			Lk(this, 'TCP_CONNECT_TIME', 'connectStart', 'connectEnd');
			Lk(this, 'SERVER_RESPONSE_TIME', 'requestStart', 'responseStart');
			Lk(this, 'PAGE_DOWNLOAD_TIME', 'responseStart', 'responseEnd');
			Lk(this, 'REDIRECT_TIME', 'navigationStart', 'fetchStart');
			Lk(this, 'DOM_INTERACTIVE_TIME', 'navigationStart', 'domInteractive');
			Lk(this, 'CONTENT_LOAD_TIME', 'navigationStart', 'domContentLoadedEventStart');
			this.setAsync('ACCESS_READER_ID', function() {
				return Rk(
					b,
					function(a) {
						return a.getAccessReaderId();
					},
					'ACCESS_READER_ID'
				);
			});
			this.setAsync('AUTHDATA', function(a) {
				G(a, 'The first argument to AUTHDATA, the field, is required');
				return Rk(
					b,
					function(b) {
						return b.getAuthdataField(a);
					},
					'AUTHDATA'
				);
			});
			this.setAsync('VIEWER', function() {
				return V(b.ampdoc).getViewerOrigin().then(function(a) {
					return void 0 == a ? '' : a;
				});
			});
			this.setAsync('TOTAL_ENGAGED_TIME', function() {
				return jd(d, 'activity', 'amp-analytics').then(function(a) {
					return a.getTotalEngagedTime();
				});
			});
			this.setAsync('INCREMENTAL_ENGAGED_TIME', function(a, b) {
				return jd(d, 'activity', 'amp-analytics').then(function(c) {
					return c.getIncrementalEngagedTime(a, 'false' !== b);
				});
			});
			this.set('NAV_TIMING', function(a, b) {
				G(a, 'The first argument to NAV_TIMING, the start attribute name, is required');
				return uk(c, a, b);
			});
			this.setAsync('NAV_TIMING', function(a, b) {
				G(a, 'The first argument to NAV_TIMING, the start attribute name, is required');
				return tk(c, a, b);
			});
			this.set('NAV_TYPE', function() {
				return vk(c, 'type');
			});
			this.set('NAV_REDIRECT_COUNT', function() {
				return vk(c, 'redirectCount');
			});
			this.set('AMP_VERSION', function() {
				return '2007242032002';
			});
			this.set('BACKGROUND_STATE', function() {
				return b.ampdoc.isVisible() ? '0' : '1';
			});
			this.setAsync('VIDEO_STATE', function(a, c) {
				return bd(b.ampdoc, 'video-manager').getVideoStateProperty(a, c);
			});
			this.setAsync('AMP_STATE', function(a) {
				var c = b.ampdoc.getRootNode();
				return md(c.documentElement || c).then(function(b) {
					return b ? b.getStateValue(a) || '' : '';
				});
			});
		};
		function Nk(a, b) {
			if ((a = Mk(a).replaceParams)) {
				b = Hc(b);
				var c = N(b);
				c = t(c.search);
				for (var d = K({}), e = Object.keys(a), g = 0; g < e.length; g++)
					mb.call(c, e[g]) || (d[e[g]] = a[e[g]]);
				a = Bc(b, d);
			} else a = b;
			return a;
		}
		function Mk(a) {
			return rd(a.ampdoc);
		}
		function Rk(a, b, c) {
			a = a.ampdoc.getHeadNode();
			return Promise.all([
				kd(a, 'access', 'amp-access'),
				kd(a, 'subscriptions', 'amp-subscriptions')
			]).then(function(a) {
				a = a[0] || a[1];
				return a
					? b(a)
					: (C().error('UrlReplacements', 'Access or subsciptions service is not installed to access: ', c),
						null);
			});
		}
		function Ok(a, b, c) {
			G(b, 'The first argument to QUERY_PARAM, the query string param is required');
			var d = N(Hc(a.ampdoc.win.location.href));
			d = t(d.search);
			a = Mk(a).replaceParams;
			return 'undefined' !== typeof d[b] ? d[b] : a && 'undefined' !== typeof a[b] ? a[b] : c;
		}
		function Pk(a, b, c) {
			return kd(a.ampdoc.getHeadNode(), 'variant', 'amp-experiment', !0)
				.then(function(a) {
					G(a, 'To use variable %s, amp-experiment should be configured', c);
					return a.getVariants();
				})
				.then(function(a) {
					return b(a);
				});
		}
		function Qk(a, b) {
			a = a.ampdoc.getHeadNode();
			return kd(a, 'geo', 'amp-geo', !0).then(function(a) {
				G(a, 'To use variable %s, amp-geo should be configured', 'AMP_GEO');
				return b(a);
			});
		}
		function Sk(a, b) {
			this.ampdoc = a;
			this.ia = b;
		}
		f = Sk.prototype;
		f.expandStringSync = function(a, b, c) {
			return new zk(this.ia, b, void 0, !0, c, !0).expand(a);
		};
		f.expandStringAsync = function(a, b, c) {
			return new zk(this.ia, b, void 0, void 0, c, !0).expand(a);
		};
		f.expandUrlSync = function(a, b, c) {
			return Tk(a, new zk(this.ia, b, void 0, !0, c).expand(a));
		};
		f.expandUrlAsync = function(a, b, c, d) {
			return new zk(this.ia, b, void 0, void 0, c, d).expand(a).then(function(b) {
				return Tk(a, b);
			});
		};
		f.expandInputValueAsync = function(a) {
			return Uk(this, a, !1);
		};
		f.expandInputValueSync = function(a) {
			return Uk(this, a, !0);
		};
		function Uk(a, b, c) {
			'INPUT' == b.tagName && (b.getAttribute('type') || '').toLowerCase();
			var d = Vk(b);
			if (!d) return c ? b.value : Promise.resolve(b.value);
			void 0 === b['amp-original-value'] && (b['amp-original-value'] = b.value);
			a = new zk(a.ia, void 0, void 0, c, d).expand(b['amp-original-value'] || b.value);
			return c
				? (b.value = a)
				: a.then(function(a) {
						return (b.value = a);
					});
		}
		function Vk(a, b) {
			if ((a = a.getAttribute('data-amp-replace'))) {
				var c = {};
				a.trim().split(/\s+/).forEach(function(a) {
					!b || mb.call(b, a) ? (c[a] = !0) : C().warn('URL', 'Ignoring unsupported replacement', a);
				});
				return c;
			}
		}
		f.maybeExpandLink = function(a, b) {
			var c = a.getAttribute('data-amp-addparams') || '',
				d = Vk(a, { CLIENT_ID: !0, QUERY_PARAM: !0, PAGE_VIEW_ID: !0, PAGE_VIEW_ID_64: !0, NAV_TIMING: !0 });
			if (d || c || b) {
				var e = a['amp-original-href'] || a.getAttribute('href'),
					g = N(e);
				null == a['amp-original-href'] && (a['amp-original-href'] = e);
				a: {
					var h = rd(this.ampdoc);
					if (g.origin == N(h.canonicalUrl).origin || g.origin == N(h.sourceUrl).origin) g = !0;
					else {
						if ((h = this.ampdoc.getMetaByName('amp-link-variable-allowed-origin'))) {
							h = h.trim().split(/\s+/);
							for (var l = 0; l < h.length; l++)
								if (g.origin == N(h[l]).origin) {
									g = !0;
									break a;
								}
						}
						g = !1;
					}
				}
				var k = g;
				c &&
					(k ? ((g = c), (g = d ? this.expandUrlSync(g, void 0, d) : g)) : (g = c),
					(c = g),
					(e = Bc(e, t(c))));
				if (!k)
					return (
						d &&
							C().warn(
								'URL',
								"Ignoring link replacement %s because the link does not go to the document's source, canonical, or allowlisted origin.",
								e
							),
						(a.href = e)
					);
				b &&
					((d && d.QUERY_PARAM) || (b = this.expandUrlSync(b, void 0, { QUERY_PARAM: !0 })),
					(e = Bc(e, t(b))));
				e = d ? this.expandUrlSync(e, void 0, d) : e;
				return (a.href = e);
			}
		};
		f.collectVars = function(a, b) {
			var c = Object.create(null);
			return new zk(this.ia, b, c).expand(a).then(function() {
				return c;
			});
		};
		f.collectDisallowedVarsSync = function(a) {
			var b = a.getAttribute('src'),
				c = new zk(this.ia).getMacroNames(b),
				d = Vk(a);
			return d
				? c.filter(function(a) {
						return !d[a];
					})
				: c;
		};
		function Tk(a, b) {
			var c = N(b, !0).protocol,
				d = N(a, !0).protocol;
			if (c != d) return C().error('UrlReplacements', 'Illegal replacement of the protocol: ', a), a;
			G(Gc(b), 'The replacement url has invalid protocol: %s', b);
			return b;
		}
		f.getVariableSource = function() {
			return this.ia;
		};
		function Wk(a) {
			R(a, 'url-replace', function(a) {
				return new Sk(a, new Kk(a));
			});
		}
		var Xk = /^(https?:\/\/)((www[0-9]*|web|ftp|wap|home|mobile|amp|m)\.)+/i;
		function Yk(a) {
			var b = this;
			this.ampdoc = a;
			this.win = a.win;
			this.Db = Qb(this.win);
			this.la = !0;
			this.Hc = !1;
			this.$ = 1;
			this.he = I();
			this.Bc = I();
			this.dg = new Y();
			this.af = new Y();
			this.Dc = this.bb = null;
			this.cb = [];
			this.Ab = I();
			a.isSingleDoc() && Object.assign(this.Ab, t(this.win.location.hash));
			this.la = !parseInt(a.getParam('off'), 10);
			F().fine('Viewer', '- runtimeOn:', this.la);
			this.Hc = !(!parseInt(a.getParam('history'), 10) && !this.Hc);
			F().fine('Viewer', '- history:', this.Hc);
			F().fine('Viewer', '- visibilityState:', this.ampdoc.getVisibilityState());
			this.$ = parseInt(a.getParam('prerenderSize'), 10) || this.$;
			F().fine('Viewer', '- prerenderSize:', this.$);
			Zk(this);
			this.Cb = null;
			this.mh = O(N(this.ampdoc.win.location.href));
			var c = new L();
			this.rh = c.resolve;
			this.Oa = $k(this, c.promise);
			this.Ie = this.Za = null;
			var d = a.getParam('referrer');
			this.ed = this.isEmbedded() && null != d && !1 !== al(this) ? d : this.win.document.referrer;
			this.Ih = new Promise(function(c) {
				b.isEmbedded() && null != a.getParam('referrer')
					? b.isTrustedViewer().then(function(d) {
							d
								? c(a.getParam('referrer'))
								: (c(b.win.document.referrer),
									b.ed != b.win.document.referrer &&
										(F().expectedError(
											'Viewer',
											'Untrusted viewer referrer override: ' + b.ed + ' at ' + b.Dc
										),
										(b.ed = b.win.document.referrer)));
						})
					: c(b.win.document.referrer);
			});
			this.Rc = Fc(this.win.location.href || '');
			this.fi = new Promise(function(c) {
				var d = a.getParam('viewerUrl');
				b.isEmbedded() && d
					? b.isTrustedViewer().then(function(a) {
							a
								? (b.Rc = d)
								: F().expectedError('Viewer', 'Untrusted viewer url override: ' + d + ' at ' + b.Dc);
							c(b.Rc);
						})
					: c(b.Rc);
			});
			if (this.Ab.click) {
				var e = Fc(this.win.location.href);
				e != this.win.location.href &&
					this.win.history.replaceState &&
					(this.win.location.originalHash || (this.win.location.originalHash = this.win.location.hash),
					this.win.history.replaceState({}, '', e),
					delete this.Ab.click,
					F().fine('Viewer', 'replace fragment:' + this.win.location.href));
			}
			this.ampdoc.whenFirstVisible().then(function() {
				b.maybeUpdateFragmentForCct();
			});
			bl(this);
		}
		function Zk(a) {
			1 !== a.$ && F().expectedError('Viewer', 'prerenderSize (' + a.$ + ') is deprecated (#27167)');
		}
		function $k(a, b) {
			return (a.Db &&
				!a.win.__AMP_TEST_IFRAME &&
				(a.ampdoc.getParam('origin') ||
					a.ampdoc.getParam('visibilityState') ||
					-1 != a.win.location.search.indexOf('amp_js_v'))) ||
			a.isWebviewEmbedded() ||
			a.isCctEmbedded() ||
			!a.ampdoc.isSingleDoc()
				? U(a.win).timeoutPromise(2e4, b, 'initMessagingChannel timeout').catch(function(a) {
						(a = cl(a)) && sb(a.message, 'initMessagingChannel timeout') && (a = F().createExpectedError(a));
						Bf(a);
						throw a;
					})
				: null;
		}
		f = Yk.prototype;
		f.getAmpDoc = function() {
			return this.ampdoc;
		};
		f.getParam = function(a) {
			return this.ampdoc.getParam(a);
		};
		f.hasCapability = function(a) {
			var b = this.ampdoc.getParam('cap');
			return b ? -1 != b.split(',').indexOf(a) : !1;
		};
		f.isEmbedded = function() {
			return !!this.Oa;
		};
		f.isWebviewEmbedded = function() {
			return !this.Db && '1' == this.ampdoc.getParam('webview');
		};
		f.isCctEmbedded = function() {
			if (null != this.Cb) return this.Cb;
			this.Cb = !1;
			if (!this.Db) {
				var a = t(this.win.location.search);
				this.Cb = '1' === a.amp_gsa && M(a.amp_js_v || '', 'a');
			}
			return this.Cb;
		};
		f.isProxyOrigin = function() {
			return this.mh;
		};
		f.maybeUpdateFragmentForCct = function() {
			if (this.isCctEmbedded() && this.win.history.replaceState) {
				var a = Kc(this.win.location.href),
					b = rd(this.ampdoc).canonicalUrl,
					c = Kc(b);
				dl(a, c) && ((this.Ab.ampshare = b), this.win.history.replaceState({}, '', '#' + Cc(this.Ab)));
			}
		};
		function dl(a, b) {
			function c(a) {
				return 2 < a.split('.').length ? a.replace(Xk, '$1') : a;
			}
			return c(a) == c(b);
		}
		f.isRuntimeOn = function() {
			return this.la;
		};
		f.toggleRuntime = function() {
			this.la = !this.la;
			F().fine('Viewer', 'Runtime state:', this.la);
			this.dg.fire(this.la);
		};
		f.onRuntimeState = function(a) {
			return this.dg.add(a);
		};
		f.isOvertakeHistory = function() {
			return this.Hc;
		};
		f.getVisibilityState = function() {
			return this.ampdoc.getVisibilityState();
		};
		f.isVisible = function() {
			return this.ampdoc.isVisible();
		};
		f.hasBeenVisible = function() {
			return this.ampdoc.hasBeenVisible();
		};
		f.whenFirstVisible = function() {
			return this.ampdoc.whenFirstVisible();
		};
		f.whenNextVisible = function() {
			return this.ampdoc.whenNextVisible();
		};
		f.getFirstVisibleTime = function() {
			return this.ampdoc.getFirstVisibleTime();
		};
		f.getLastVisibleTime = function() {
			return this.ampdoc.getLastVisibleTime();
		};
		f.onVisibilityChanged = function(a) {
			return this.ampdoc.onVisibilityChanged(a);
		};
		function el(a, b) {
			b &&
				((b = F().assertEnumValue(Xe, b, 'VisibilityState')),
				'hidden' === b && (b = null != a.ampdoc.getLastVisibleTime() ? 'inactive' : 'prerender'),
				a.ampdoc.overrideVisibilityState(b),
				F().fine('Viewer', 'visibilitychange event:', a.ampdoc.getVisibilityState()));
		}
		f.getPrerenderSize = function() {
			return this.$;
		};
		f.getResolvedViewerUrl = function() {
			return this.Rc;
		};
		f.getViewerUrl = function() {
			return this.fi;
		};
		f.maybeGetMessagingOrigin = function() {
			return this.Dc;
		};
		f.getUnconfirmedReferrerUrl = function() {
			return this.ed;
		};
		f.getReferrerUrl = function() {
			return this.Ih;
		};
		f.isTrustedViewer = function() {
			if (!this.Za) {
				var a = al(this);
				this.Za =
					void 0 !== a
						? Promise.resolve(a)
						: this.Oa.then(function(a) {
								return a ? fl(a) : !1;
							});
			}
			return this.Za;
		};
		function al(a) {
			if (!a.isEmbedded()) return !1;
			if (a.win.location.ancestorOrigins && !a.isWebviewEmbedded() && !a.isCctEmbedded())
				return 0 < a.win.location.ancestorOrigins.length && fl(a.win.location.ancestorOrigins[0]);
		}
		f.getViewerOrigin = function() {
			if (!this.Ie) {
				var a;
				this.isEmbedded()
					? this.win.location.ancestorOrigins &&
						0 < this.win.location.ancestorOrigins.length &&
						(a = this.win.location.ancestorOrigins[0])
					: (a = '');
				this.Ie =
					void 0 !== a
						? Promise.resolve(a)
						: U(this.win).timeoutPromise(1e3, this.Oa).catch(function() {
								return '';
							});
			}
			return this.Ie;
		};
		function fl(a) {
			var b = N(a);
			a = b.protocol;
			return 'x-thread:' == a
				? !0
				: 'https:' != a
					? !1
					: B.trustedViewerHosts.some(function(a) {
							return a.test(b.hostname);
						});
		}
		f.onMessage = function(a, b) {
			var c = this.he[a];
			c || ((c = new Y()), (this.he[a] = c));
			return c.add(b);
		};
		f.onMessageRespond = function(a, b) {
			var c = this;
			this.Bc[a] = b;
			return function() {
				c.Bc[a] === b && delete c.Bc[a];
			};
		};
		f.receiveMessage = function(a, b) {
			if ('visibilitychange' == a)
				return (
					void 0 !== b.prerenderSize &&
						((this.$ = b.prerenderSize), F().fine('Viewer', '- prerenderSize change:', this.$), Zk(this)),
					el(this, b.state),
					x()
				);
			if ('broadcast' == a) return this.af.fire(b), x();
			var c = this.he[a];
			c && c.fire(b);
			var d = this.Bc[a];
			if (d) return d(b);
			if (c) return x();
			F().fine('Viewer', 'unknown message:', a);
		};
		f.setMessageDeliverer = function(a, b) {
			var c = this;
			if (this.bb) throw Error('message channel can only be initialized once');
			if (null == b) throw Error('message channel must have an origin');
			F().fine('Viewer', 'message channel established with origin: ', b);
			this.bb = a;
			this.Dc = b;
			this.rh(b);
			0 < this.cb.length &&
				((a = this.cb.slice(0)),
				(this.cb = []),
				a.forEach(function(a) {
					var b = c.bb(a.eventType, a.data, a.awaitResponse);
					a.awaitResponse && a.responseResolver(b);
				}));
		};
		f.sendMessage = function(a, b, c) {
			gl(this, a, b, void 0 === c ? !1 : c, !1);
		};
		f.sendMessageAwaitResponse = function(a, b, c) {
			return gl(this, a, b, void 0 === c ? !1 : c, !0);
		};
		function gl(a, b, c, d, e) {
			if (a.bb)
				return nb(function() {
					return a.bb(b, c, e);
				});
			if (!a.Oa) return e ? Promise.reject(cl()) : x();
			if (!d)
				return a.Oa.then(function() {
					return a.bb(b, c, e);
				});
			var g = lg(a.cb, function(a) {
				return a.eventType == b;
			});
			-1 != g
				? ((d = a.cb.splice(g, 1)[0]), (d.data = c), (d.awaitResponse = d.awaitResponse || e))
				: ((d = new L()),
					(d = {
						eventType: b,
						data: c,
						awaitResponse: e,
						responsePromise: d.promise,
						responseResolver: d.resolve
					}));
			a.cb.push(d);
			return d.responsePromise;
		}
		f.broadcast = function(a) {
			return this.Oa
				? gl(this, 'broadcast', a, !1, !1).then(
						function() {
							return !0;
						},
						function() {
							return !1;
						}
					)
				: Promise.resolve(!1);
		};
		f.onBroadcast = function(a) {
			return this.af.add(a);
		};
		f.whenMessagingReady = function() {
			return this.Oa;
		};
		f.replaceUrl = function(a) {
			if (a && this.ampdoc.isSingleDoc() && this.win.history.replaceState)
				try {
					var b = N(this.win.location.href),
						c = N(Fc(a) + this.win.location.hash);
					b.origin == c.origin &&
						Kc(b) == Kc(c) &&
						(this.win.history.replaceState({}, '', c.href),
						(this.win.location.originalHref = b.href),
						F().fine('Viewer', 'replace url:' + c.href));
				} catch (d) {
					F().error('Viewer', 'replaceUrl failed', d);
				}
		};
		function bl(a) {
			if ('visible' != a.ampdoc.getVisibilityState()) {
				var b = [],
					c = function() {
						return b.forEach(function(a) {
							return a();
						});
					},
					d = function() {
						el(a, 'visible');
						c();
						F().expectedError('Viewer', 'Received user action in non-visible doc');
					},
					e = { capture: !0, passive: !0 };
				b.push(Ie(a.win, 'keydown', d, e), Ie(a.win, 'touchstart', d, e), Ie(a.win, 'mousedown', d, e));
				a.whenFirstVisible().then(c);
			}
		}
		function cl(a) {
			if (a instanceof Error) {
				a = gb(a);
				a.message = 'No messaging channel: ' + a.message;
				var b = a;
			} else b = Error('No messaging channel: ' + a);
			b.message = b.message.replace('\u200b\u200b\u200b', '');
			return b;
		}
		function hl(a, b, c, d) {
			var e = new il(a, b, c, d);
			return e.solveYValueFromXValue.bind(e);
		}
		function il(a, b, c, d) {
			this.y0 = this.x0 = 0;
			this.x1 = a;
			this.y1 = b;
			this.x2 = c;
			this.y2 = d;
			this.y3 = this.x3 = 1;
		}
		f = il.prototype;
		f.solveYValueFromXValue = function(a) {
			return this.getPointY(this.solvePositionFromXValue(a));
		};
		f.solvePositionFromXValue = function(a) {
			var b = (a - this.x0) / (this.x3 - this.x0);
			if (0 >= b) return 0;
			if (1 <= b) return 1;
			for (var c = 0, d = 1, e = 0, g = 0; 8 > g; g++) {
				e = this.getPointX(b);
				var h = (this.getPointX(b + 1e-6) - e) / 1e-6;
				if (1e-6 > Math.abs(e - a)) return b;
				if (1e-6 > Math.abs(h)) break;
				else e < a ? (c = b) : (d = b), (b -= (e - a) / h);
			}
			for (g = 0; 1e-6 < Math.abs(e - a) && 8 > g; g++)
				e < a ? ((c = b), (b = (b + d) / 2)) : ((d = b), (b = (b + c) / 2)), (e = this.getPointX(b));
			return b;
		};
		f.getPointX = function(a) {
			if (0 == a) return this.x0;
			if (1 == a) return this.x3;
			var b = this.lerp(this.x0, this.x1, a),
				c = this.lerp(this.x1, this.x2, a),
				d = this.lerp(this.x2, this.x3, a);
			b = this.lerp(b, c, a);
			c = this.lerp(c, d, a);
			return this.lerp(b, c, a);
		};
		f.getPointY = function(a) {
			if (0 == a) return this.y0;
			if (1 == a) return this.y3;
			var b = this.lerp(this.y0, this.y1, a),
				c = this.lerp(this.y1, this.y2, a),
				d = this.lerp(this.y2, this.y3, a);
			b = this.lerp(b, c, a);
			c = this.lerp(c, d, a);
			return this.lerp(b, c, a);
		};
		f.lerp = function(a, b, c) {
			return a + c * (b - a);
		};
		var jl = hl(0.25, 0.1, 0.25, 1),
			kl = hl(0.42, 0, 1, 1),
			ll = hl(0, 0, 0.58, 1),
			ml = hl(0.42, 0, 0.58, 1),
			nl = {
				linear: function(a) {
					return a;
				},
				ease: jl,
				'ease-in': kl,
				'ease-out': ll,
				'ease-in-out': ml
			};
		function ol(a) {
			if (!a) return null;
			if ('string' == typeof a) {
				if (-1 != a.indexOf('cubic-bezier')) {
					var b = a.match(/cubic-bezier\((.+)\)/);
					if (b && ((b = b[1].split(',').map(parseFloat)), 4 == b.length)) {
						for (var c = 0; 4 > c; c++) if (isNaN(b[c])) return null;
						return hl(b[0], b[1], b[2], b[3]);
					}
					return null;
				}
				return nl[a];
			}
			return a;
		}
		function pl() {}
		function ql(a) {
			this.tb = a;
			this.A = vd(self);
			this.lf = null;
			this.X = [];
		}
		function rl(a, b, c, d) {
			return new ql(a).setCurve(d).add(0, b, 1).start(c);
		}
		ql.prototype.setCurve = function(a) {
			a && (this.lf = ol(a));
			return this;
		};
		ql.prototype.add = function(a, b, c, d) {
			this.X.push({ delay: a, func: b, duration: c, curve: ol(d) });
			return this;
		};
		ql.prototype.start = function(a) {
			return new sl(this.A, this.tb, this.X, this.lf, a);
		};
		function sl(a, b, c, d, e) {
			this.A = a;
			this.tb = b;
			this.X = [];
			for (a = 0; a < c.length; a++) {
				var g = c[a];
				this.X.push({
					delay: g.delay,
					func: g.func,
					duration: g.duration,
					curve: g.curve || d,
					started: !1,
					completed: !1
				});
			}
			this.Sg = e;
			this.ze = Date.now();
			this.Qa = !0;
			this.D = {};
			c = new L();
			this.Zf = c.promise;
			this.Nh = c.resolve;
			this.Jh = c.reject;
			this.ng = this.A.createAnimTask(this.tb, { mutate: this.Wh.bind(this) });
			this.A.canAnimate(this.tb) ? this.ng(this.D) : (F().warn('Animation', 'cannot animate'), tl(this, !1, 0));
		}
		sl.prototype.then = function(a, b) {
			return a || b ? this.Zf.then(a, b) : this.Zf;
		};
		sl.prototype.thenAlways = function(a) {
			a = a || pl;
			return this.then(a, a);
		};
		sl.prototype.halt = function(a) {
			tl(this, !1, a || 0);
		};
		function tl(a, b, c) {
			if (a.Qa) {
				a.Qa = !1;
				if (0 != c) {
					1 < a.X.length &&
						a.X.sort(function(a, b) {
							return a.delay + a.duration - (b.delay + b.duration);
						});
					try {
						if (0 < c) for (c = 0; c < a.X.length; c++) a.X[c].func(1, !0);
						else for (var d = a.X.length - 1; 0 <= d; d--) a.X[d].func(0, !1);
					} catch (e) {
						F().error('Animation', 'completion failed: ' + e, e), (b = !1);
					}
				}
				b ? a.Nh() : a.Jh();
			}
		}
		sl.prototype.Wh = function() {
			if (this.Qa) {
				for (var a = Date.now(), b = Math.min((a - this.ze) / this.Sg, 1), c = 0; c < this.X.length; c++) {
					var d = this.X[c];
					!d.started && b >= d.delay && (d.started = !0);
				}
				for (c = 0; c < this.X.length; c++)
					if (((d = this.X[c]), d.started && !d.completed))
						a: {
							var e;
							if (0 < d.duration) {
								var g = (e = Math.min((b - d.delay) / d.duration, 1));
								if (d.curve && 1 != g)
									try {
										g = d.curve(e);
									} catch (h) {
										F().error('Animation', 'step curve failed: ' + h, h);
										tl(this, !1, 0);
										break a;
									}
							} else g = e = 1;
							1 == e && (d.completed = !0);
							try {
								d.func(g, d.completed);
							} catch (h) {
								F().error('Animation', 'step mutate failed: ' + h, h), tl(this, !1, 0);
							}
						}
				1 == b
					? tl(this, !0, 0)
					: this.A.canAnimate(this.tb)
						? this.ng(this.D)
						: (F().warn('Animation', 'cancel animation'), tl(this, !1, 0));
			}
		};
		function ul(a) {
			return -1 !== a.tagName.indexOf('LIGHTBOX');
		}
		function vl(a, b, c, d, e) {
			var g = this;
			this.ampdoc = a;
			this.A = b;
			this.Eg = c;
			this.fc = this.P = d;
			this.Yb = e && a.isSingleDoc();
			this.Ja = null;
			this.Og = 0;
			this.J = [];
			this.hd = new si(a.win, function() {
				return g.update();
			});
			this.nc = null;
			this.kc = [];
			this.Wc = [];
		}
		f = vl.prototype;
		f.enterLightbox = function(a, b) {
			var c = this,
				d = wl(this);
			d && d.setLightboxMode(!0);
			a &&
				b &&
				b.then(function() {
					xl(c, a, !0);
					yl(c);
					c.update();
				});
		};
		f.leaveLightbox = function() {
			var a = wl(this);
			a && a.setLightboxMode(!1);
			var b = kg(this.J, function(a) {
				return !!a.lightboxed;
			});
			zl(this, b);
			this.J.length || Al(this);
		};
		f.setup = function() {
			if (!V(this.ampdoc).isEmbedded()) return !1;
			var a = this.ampdoc.getRootNode(),
				b = a.styleSheets;
			if (!b) return !0;
			this.kc.length = 0;
			for (var c = (this.Wc.length = 0); c < b.length; c++) {
				var d = b[c];
				if (!d) return F().error('FixedLayer', 'Aborting setup due to null stylesheet.'), !0;
				var e = d,
					g = e.ownerNode;
				e.disabled ||
					!g ||
					'STYLE' != g.tagName ||
					g.hasAttribute('amp-boilerplate') ||
					g.hasAttribute('amp-runtime') ||
					g.hasAttribute('amp-extension') ||
					Bl(this, d.cssRules);
			}
			xl(this, a, void 0);
			yl(this);
			this.update();
			0 < this.J.length && this.observeHiddenMutations();
			a = T(this.ampdoc.win);
			0 < this.J.length &&
				!this.Yb &&
				a.isIos() &&
				C().warn(
					'FixedLayer',
					"Please test this page inside of an AMP Viewer such as Google's because the fixed or sticky positioning might have slightly different layout."
				);
			return !0;
		};
		f.observeHiddenMutations = function() {
			P(this.ampdoc.win, 'hidden-mutation-observer') && Cl(this);
		};
		function Al(a) {
			a.hd.cancel();
			var b = a.nc;
			b && (b(), (a.nc = null));
		}
		function Cl(a) {
			if (!a.nc) {
				var b = a.ampdoc.getRootNode();
				a.nc = Tc(b.documentElement || b, 'hidden-observer').add(function() {
					a.hd.isPending() || a.hd.schedule(16);
				});
			}
		}
		f.updatePaddingTop = function(a, b) {
			this.P = a;
			b || (this.fc = a);
			this.update();
		};
		f.transformMutate = function(a) {
			a
				? this.J.forEach(function(b) {
						b.fixedNow &&
							b.top &&
							(X(b.element, 'transition', 'none'),
							b.transform && 'none' != b.transform
								? X(b.element, 'transform', b.transform + ' ' + a)
								: X(b.element, 'transform', a));
					})
				: this.J.forEach(function(a) {
						a.fixedNow && a.top && qe(a.element, { transform: '', transition: '' });
					});
		};
		f.addElement = function(a, b) {
			if (!Dl(this, a, '*', 'fixed', b)) return x();
			yl(this);
			this.observeHiddenMutations();
			return this.update();
		};
		f.removeElement = function(a) {
			a = El(this, a);
			zl(this, a);
		};
		function zl(a, b) {
			0 < b.length &&
				a.Ja &&
				a.A.mutate(function() {
					for (var c = 0; c < b.length; c++) {
						var d = b[c];
						'fixed' == d.position && a.Ja.returnFrom(d);
					}
				});
		}
		f.isDeclaredFixed = function(a) {
			return !!a.__AMP_DECLFIXED;
		};
		f.isDeclaredSticky = function(a) {
			return !!a.__AMP_DECLSTICKY;
		};
		f.update = function() {
			var a = this;
			this.J
				.filter(function(b) {
					return !a.ampdoc.contains(b.element);
				})
				.forEach(function(b) {
					return El(a, b.element);
				});
			if (0 == this.J.length) return x();
			this.hd.cancel();
			var b = !1;
			return this.A
				.runPromise(
					{
						measure: function(c) {
							for (var d = a.J, e = [], g = a.ampdoc.win, h = 0; h < d.length; h++)
								oe(d[h].element, { top: '', bottom: '-9999vh', transition: 'none' });
							for (h = 0; h < d.length; h++) e.push(se(g, d[h].element).top);
							for (h = 0; h < d.length; h++) X(d[h].element, 'bottom', '');
							for (h = 0; h < d.length; h++) {
								var l = d[h],
									k = l,
									n = k.element,
									r = k.forceTransfer;
								k = se(g, n);
								var u = n.offsetWidth,
									w = n.offsetHeight,
									y = n.offsetTop,
									p = k,
									q = void 0 === p.position ? '' : p.position,
									H = void 0 === p.display ? '' : p.display;
								n = p.bottom;
								var E = p.zIndex,
									ja = parseFloat(k.opacity);
								p = k[ne(k, 'transform')];
								k = k.top;
								var na = 'fixed' === q && (r || (0 < u && 0 < w)),
									ca = sb(q, 'sticky');
								if ('none' === H || (!na && !ca))
									c[l.id] = { fixed: !1, sticky: !1, transferrable: !1, top: '', zIndex: '' };
								else {
									if ('auto' === k || e[h] !== k) k = na && y === a.fc + a.Eg ? '0px' : '';
									var D = !1;
									na && (D = !0 === r ? !0 : !1 === r ? !1 : 0 < ja && 300 > w && !(!k && !n));
									D && (b = !0);
									c[l.id] = {
										fixed: na,
										sticky: ca,
										transferrable: D,
										top: k,
										zIndex: E,
										transform: p
									};
								}
							}
						},
						mutate: function(c) {
							b && a.Yb && wl(a).update();
							for (var d = a.J, e = 0; e < d.length; e++) {
								var g = d[e],
									h = c[g.id];
								X(g.element, 'transition', 'none');
								X(g.element, 'transition', '');
								if (h) {
									var l = e,
										k = h,
										n = g.element,
										r = g.fixedNow;
									g.fixedNow = k.fixed;
									g.stickyNow = k.sticky;
									g.top = k.fixed || k.sticky ? k.top : '';
									g.transform = k.transform;
									!r || (k.fixed && k.transferrable) || !a.Ja || a.Ja.returnFrom(g);
									k.top &&
										(k.fixed || k.sticky) &&
										!g.lightboxed &&
										(k.fixed || !a.Yb
											? X(n, 'top', 'calc(' + k.top + ' + ' + a.P + 'px)')
											: a.fc === a.P
												? X(n, 'top', k.top)
												: X(n, 'top', 'calc(' + k.top + ' - ' + a.fc + 'px)'));
									a.Yb && k.fixed && k.transferrable && wl(a).transferTo(g, l, k);
								}
							}
						}
					},
					{}
				)
				.catch(function(a) {
					F().error('FixedLayer', 'Failed to mutate fixed elements:', a);
				});
		};
		function xl(a, b, c) {
			try {
				for (var d = 0; d < a.kc.length; d++)
					for (var e = a.kc[d], g = b.querySelectorAll(e), h = 0; h < g.length && !(10 < a.J.length); h++)
						Dl(a, g[h], e, 'fixed', void 0, c);
				for (d = 0; d < a.Wc.length; d++) {
					var l = a.Wc[d],
						k = b.querySelectorAll(l);
					for (e = 0; e < k.length; e++) Dl(a, k[e], l, 'sticky', void 0, c);
				}
			} catch (n) {
				F().error('FixedLayer', 'Failed to setup fixed elements:', n);
			}
		}
		function Dl(a, b, c, d, e, g) {
			e ||
				(b.hasAttribute('style') &&
					(pe(b, 'top') || pe(b, 'bottom')) &&
					C().error(
						'FixedLayer',
						'Inline styles with `top`, `bottom` and other CSS rules are not supported yet for fixed or sticky elements (#14186). Unexpected behavior may occur.',
						b
					));
			if (ul(b)) return !1;
			var h = Db(b, ul);
			if (!g && h) return !1;
			g = a.J;
			for (var l = [], k = 0; k < g.length; k++) {
				var n = g[k].element;
				if (n === b) break;
				if (n.contains(b)) return !1;
				b.contains(n) && l.push(n);
			}
			for (k = 0; k < l.length; k++) a.removeElement(l[k]);
			k = null;
			for (n = 0; n < g.length; n++) {
				var r = g[n];
				if (r.element == b && r.position == d) {
					k = r;
					break;
				}
			}
			n = 'fixed' == d;
			k
				? k.selectors.includes(c) || k.selectors.push(c)
				: ((a = 'F' + a.Og++),
					b.setAttribute('i-amphtml-fixedid', a),
					n ? (b.__AMP_DECLFIXED = !0) : (b.__AMP_DECLSTICKY = !0),
					(k = {
						id: a,
						element: b,
						position: d,
						selectors: [ c ],
						fixedNow: !1,
						stickyNow: !1,
						lightboxed: !!h
					}),
					g.push(k));
			k.forceTransfer = n ? e : !1;
			return !0;
		}
		function El(a, b) {
			for (var c = [], d = 0; d < a.J.length; d++) {
				var e = a.J[d];
				e.element === b &&
					(e.lightboxed ||
						a.A.mutate(function() {
							X(b, 'top', '');
						}),
					a.J.splice(d, 1),
					c.push(e));
			}
			a.J.length || Al(a);
			return c;
		}
		function yl(a) {
			a.J.sort(function(a, c) {
				var b = a.element,
					e = c.element;
				return b === e
					? 0
					: b.compareDocumentPosition(e) &
						(Node.DOCUMENT_POSITION_PRECEDING | Node.DOCUMENT_POSITION_CONTAINS)
						? 1
						: -1;
			});
		}
		function wl(a) {
			if (!a.Yb || a.Ja) return a.Ja;
			a.Ja = new Fl(a.ampdoc.win.document, a.A);
			return a.Ja;
		}
		function Bl(a, b) {
			for (var c = 0; c < b.length; c++) {
				var d = b[c];
				if (4 == d.type || 12 == d.type) Bl(a, d.cssRules);
				else if (1 == d.type) {
					var e = d.selectorText;
					d = d.style.position;
					'*' !== e && d && ('fixed' === d ? a.kc.push(e) : sb(d, 'sticky') && a.Wc.push(e));
				}
			}
		}
		function Fl(a, b) {
			this.Z = a;
			this.A = b;
			this.Da = a.body.cloneNode(!1);
			this.Da.removeAttribute('style');
			b = this.Da;
			var c = {
				position: 'absolute',
				top: 0,
				left: 0,
				height: 0,
				width: 0,
				pointerEvents: 'none',
				overflow: 'hidden',
				animation: 'none',
				background: 'none',
				border: 'none',
				borderImage: 'none',
				boxSizing: 'border-box',
				boxShadow: 'none',
				float: 'none',
				margin: 0,
				opacity: 1,
				outline: 'none',
				padding: 'none',
				transform: 'none',
				transition: 'none'
			};
			'display' in c && F().error('STYLE', '`display` style detected in styles. You must use toggle instead.');
			qe(b, c);
			this.Da.style.display = 'block';
			a.documentElement.appendChild(this.Da);
		}
		f = Fl.prototype;
		f.getRoot = function() {
			return this.Da;
		};
		f.setLightboxMode = function(a) {
			var b = this;
			this.A.mutate(function() {
				var c = b.getRoot();
				a ? c.setAttribute('i-amphtml-lightbox', '') : c.removeAttribute('i-amphtml-lightbox');
			});
		};
		f.update = function() {
			for (var a = this.Z.body, b = this.Da, c = a.attributes, d = b.attributes, e = 0; e < c.length; e++) {
				var g = c[e];
				'style' !== g.name && d.setNamedItem(g.cloneNode(!1));
			}
			for (e = 0; e < d.length; e++)
				(g = d[e].name),
					'style' === g || 'i-amphtml-lightbox' === g || a.hasAttribute(g) || (b.removeAttribute(g), e--);
		};
		f.transferTo = function(a, b, c) {
			var d = a.element;
			if (d.parentElement != this.Da) {
				F().fine('FixedLayer', 'transfer to fixed:', a.id, a.element);
				C().warn(
					'FixedLayer',
					'In order to improve scrolling performance in Safari, we now move the element to a fixed positioning layer:',
					a.element
				);
				if (!a.placeholder) {
					X(d, 'pointer-events', 'initial');
					var e = (a.placeholder = this.Z.createElement('i-amphtml-fpa'));
					re(e, !1);
					e.setAttribute('i-amphtml-fixedid', a.id);
				}
				X(d, 'zIndex', 'calc(' + (1e4 + b) + ' + ' + (c.zIndex || 0) + ')');
				a.lightboxed && d.classList.add('i-amphtml-lightbox-element');
				d.parentElement.replaceChild(a.placeholder, d);
				this.Da.appendChild(d);
				a.selectors.some(function(a) {
					try {
						var b = Gb(d, a);
					} catch (l) {
						F().error('FixedLayer', 'Failed to test query match:', l), (b = !1);
					}
					return b;
				}) ||
					(C().warn(
						'FixedLayer',
						'Failed to move the element to the fixed position layer. This is most likely due to the compound CSS selector:',
						a.element
					),
					this.returnFrom(a));
			}
		};
		f.returnFrom = function(a) {
			if (a.placeholder && this.Z.contains(a.placeholder)) {
				var b = a.element,
					c = a.placeholder;
				F().fine('FixedLayer', 'return from fixed:', a.id, b);
				a.lightboxed && b.classList.remove('i-amphtml-lightbox-element');
				this.Z.contains(b)
					? (X(a.element, 'zIndex', ''), c.parentElement.replaceChild(b, c))
					: c.parentElement.removeChild(c);
			}
		};
		function Gl(a, b) {
			for (b = b.lastElementChild; b; b = b.previousElementSibling)
				if (0 < b.getBoundingClientRect().height) {
					var c = se(a, b);
					if ('static' == c.position || 'relative' == c.position) {
						var d = c;
						break;
					}
				}
			return d ? parseInt(d.marginBottom, 10) : 0;
		}
		function Hl(a) {
			var b = this;
			this.win = a;
			this.A = vd(a);
			a = this.win.document;
			var c = a.documentElement,
				d = c.className;
			c.classList.add('i-amphtml-ios-embed');
			var e = a.createElement('html');
			this.Y = e;
			e.id = 'i-amphtml-wrapper';
			e.className = d;
			this.Ia = new Y();
			this.Ha = new Y();
			this.sb = this.Uf.bind(this);
			this.rb = function() {
				return b.Ha.fire();
			};
			this.P = 0;
			this.fg = !1;
			wb(a, this.gg.bind(this));
			zj(a).then(function() {
				c.classList.add('i-amphtml-ios-overscroll');
			});
			F().fine('Viewport', 'initialized ios-embed-wrapper viewport');
		}
		f = Hl.prototype;
		f.ensureReadyForElements = function() {
			this.gg();
		};
		f.gg = function() {
			if (!this.fg) {
				this.fg = !0;
				var a = this.win.document,
					b = a.body;
				a.documentElement.appendChild(this.Y);
				this.Y.appendChild(b);
				Object.defineProperty(a, 'body', {
					get: function() {
						return b;
					}
				});
				this.Uf();
			}
		};
		f.connect = function() {
			this.win.addEventListener('resize', this.rb);
			this.Y.addEventListener('scroll', this.sb);
		};
		f.disconnect = function() {
			this.win.removeEventListener('resize', this.rb);
			this.Y.removeEventListener('scroll', this.sb);
		};
		f.getBorderTop = function() {
			return 1;
		};
		f.requiresFixedLayerTransfer = function() {
			return P(this.win, 'ios-fixed-no-transfer') ? 12.2 > parseFloat(T(this.win).getIosVersionString()) : !0;
		};
		f.overrideGlobalScrollTo = function() {
			return !0;
		};
		f.supportsPositionFixed = function() {
			return !0;
		};
		f.onScroll = function(a) {
			this.Ia.add(a);
		};
		f.onResize = function(a) {
			this.Ha.add(a);
		};
		f.updatePaddingTop = function(a) {
			this.P = a;
			oe(this.Y, { 'padding-top': a + 'px' });
		};
		f.hideViewerHeader = function(a) {
			a || this.updatePaddingTop(0);
		};
		f.showViewerHeader = function(a, b) {
			a || this.updatePaddingTop(b);
		};
		f.disableScroll = function() {
			this.Y.classList.add('i-amphtml-scroll-disabled');
		};
		f.resetScroll = function() {
			this.Y.classList.remove('i-amphtml-scroll-disabled');
		};
		f.updateLightboxMode = function() {
			return x();
		};
		f.getSize = function() {
			return { width: this.win.innerWidth, height: this.win.innerHeight };
		};
		f.getScrollTop = function() {
			return this.Y.scrollTop;
		};
		f.getScrollLeft = function() {
			return 0;
		};
		f.getScrollWidth = function() {
			return this.Y.scrollWidth;
		};
		f.getScrollHeight = function() {
			return this.Y.scrollHeight;
		};
		f.getContentHeight = function() {
			var a = this.win.document.body,
				b = a.getBoundingClientRect().height,
				c = Gl(this.win, a);
			a = se(this.win, a);
			return parseInt(a.marginTop, 10) + this.P + b + c + parseInt(a.marginBottom, 10);
		};
		f.contentHeightChanged = function() {};
		f.getLayoutRect = function(a, b, c, d) {
			a = d || a.getBoundingClientRect();
			var e = void 0 != c ? c : this.getScrollTop(),
				g = void 0 != b ? b : this.getScrollLeft();
			return fc(Math.round(a.left + g), Math.round(a.top + e), Math.round(a.width), Math.round(a.height));
		};
		f.getRootClientRectAsync = function() {
			return Promise.resolve(null);
		};
		f.setScrollTop = function(a) {
			this.Y.scrollTop = a || 1;
		};
		f.Uf = function(a) {
			0 == this.Y.scrollTop && ((this.Y.scrollTop = 1), a && a.preventDefault());
			a && this.Ia.fire();
		};
		f.getScrollingElement = function() {
			return this.Y;
		};
		f.getScrollingElementScrollsLikeViewport = function() {
			return !1;
		};
		function Il(a) {
			var b = this;
			this.ampdoc = a;
			this.win = a.win;
			this.ta = T(this.win);
			this.Ia = new Y();
			this.Ha = new Y();
			this.sb = this.Zg.bind(this);
			this.rb = function() {
				return b.Ha.fire();
			};
			F().fine('Viewport', 'initialized natural viewport');
		}
		f = Il.prototype;
		f.Zg = function() {
			this.Ia.fire();
		};
		f.connect = function() {
			this.win.addEventListener('scroll', this.sb);
			this.win.addEventListener('resize', this.rb);
		};
		f.disconnect = function() {
			this.win.removeEventListener('scroll', this.sb);
			this.win.removeEventListener('resize', this.rb);
		};
		f.ensureReadyForElements = function() {};
		f.getBorderTop = function() {
			return 0;
		};
		f.requiresFixedLayerTransfer = function() {
			return !1;
		};
		f.overrideGlobalScrollTo = function() {
			return !1;
		};
		f.supportsPositionFixed = function() {
			return !0;
		};
		f.onScroll = function(a) {
			this.Ia.add(a);
		};
		f.onResize = function(a) {
			this.Ha.add(a);
		};
		f.updatePaddingTop = function(a) {
			oe(this.win.document.documentElement, { 'padding-top': a + 'px' });
		};
		f.hideViewerHeader = function(a) {
			a || this.updatePaddingTop(0);
		};
		f.showViewerHeader = function(a, b) {
			a || this.updatePaddingTop(b);
		};
		f.disableScroll = function() {
			this.win.document.documentElement.classList.add('i-amphtml-scroll-disabled');
		};
		f.resetScroll = function() {
			this.win.document.documentElement.classList.remove('i-amphtml-scroll-disabled');
		};
		f.updateLightboxMode = function() {
			return x();
		};
		f.getSize = function() {
			var a = this.win.innerWidth,
				b = this.win.innerHeight;
			if (a && b) return { width: a, height: b };
			var c = this.win.document.documentElement;
			return { width: c.clientWidth, height: c.clientHeight };
		};
		f.getScrollTop = function() {
			var a = this.getScrollingElement().scrollTop || this.win.pageYOffset,
				b = this.ampdoc.getRootNode().host;
			return b ? a - b.offsetTop : a;
		};
		f.getScrollLeft = function() {
			return 0;
		};
		f.getScrollWidth = function() {
			return this.getScrollingElement().scrollWidth;
		};
		f.getScrollHeight = function() {
			return this.getScrollingElement().scrollHeight;
		};
		f.getContentHeight = function() {
			var a = this.getScrollingElement(),
				b = a.getBoundingClientRect(),
				c = b.top + this.getScrollTop(),
				d = T(this.win).isSafari() ? Gl(this.win, a) : 0;
			a = se(this.win, a);
			return c + parseInt(a.marginTop, 10) + b.height + d + parseInt(a.marginBottom, 10);
		};
		f.contentHeightChanged = function() {};
		f.getLayoutRect = function(a, b, c, d) {
			a = d || a.getBoundingClientRect();
			c = void 0 != c ? c : this.getScrollTop();
			b = void 0 != b ? b : this.getScrollLeft();
			return fc(Math.round(a.left + b), Math.round(a.top + c), Math.round(a.width), Math.round(a.height));
		};
		f.getRootClientRectAsync = function() {
			return Promise.resolve(null);
		};
		f.setScrollTop = function(a) {
			this.getScrollingElement().scrollTop = a;
		};
		f.getScrollingElement = function() {
			var a = this.win.document;
			return a.scrollingElement ? a.scrollingElement : a.body && this.ta.isWebKit() ? a.body : a.documentElement;
		};
		f.getScrollingElementScrollsLikeViewport = function() {
			return !0;
		};
		function Jl(a, b) {
			return function(c) {
				return a + (b - a) * c;
			};
		}
		function Ml(a, b, c) {
			var d = this,
				e = a.win;
			this.ampdoc = a;
			this.Ld = this.ampdoc.win.document;
			this.o = b;
			this.h = c;
			this.ya = this.aa = this.Sb = null;
			this.ve = !1;
			this.Tc = null;
			this.P = Number(c.getParam('paddingTop') || 0);
			this.uc = 0;
			this.R = U(e);
			this.A = vd(e);
			this.we = !1;
			this.xe = null;
			this.Rh = 0;
			this.gf = new Y();
			this.Ia = new Y();
			this.Ha = new Y();
			this.oe = this.$b = void 0;
			this.N = null;
			this.createFixedLayer(vl);
			this.h.onMessage('viewport', this.ci.bind(this));
			this.h.onMessage('scroll', this.ei.bind(this));
			this.h.onMessage('disableScroll', this.Rg.bind(this));
			this.h.isEmbedded() && this.o.updatePaddingTop(this.P);
			this.o.onScroll(this.Sh.bind(this));
			this.o.onResize(this.cg.bind(this));
			this.onScroll(this.Th.bind(this));
			this.ja = !1;
			this.ampdoc.onVisibilityChanged(this.sg.bind(this));
			this.sg();
			var g = this.Ld.documentElement;
			a.isSingleDoc() && g.classList.add('i-amphtml-singledoc');
			c.isEmbedded() ? g.classList.add('i-amphtml-embedded') : g.classList.add('i-amphtml-standalone');
			Qb(e) && g.classList.add('i-amphtml-iframed');
			'1' === c.getParam('webview') && g.classList.add('i-amphtml-webview');
			Qb(e) && 'scrollRestoration' in e.history && (e.history.scrollRestoration = 'manual');
			if (this.o.overrideGlobalScrollTo())
				try {
					Object.defineProperty(e, 'scrollTo', {
						value: function(a, b) {
							return d.setScrollTop(b);
						}
					}),
						[ 'pageYOffset', 'scrollY' ].forEach(function(a) {
							Object.defineProperty(e, a, {
								get: function() {
									return d.getScrollTop();
								}
							});
						});
				} catch (h) {}
		}
		f = Ml.prototype;
		f.dispose = function() {
			this.o.disconnect();
		};
		f.ensureReadyForElements = function() {
			this.o.ensureReadyForElements();
		};
		f.sg = function() {
			var a = this.ampdoc.isVisible();
			a != this.ja &&
				((this.ja = a)
					? (this.o.connect(), this.aa && this.cg(), this.ya && ((this.ya = null), this.getScrollTop()))
					: this.o.disconnect());
		};
		f.getPaddingTop = function() {
			return this.P;
		};
		f.getScrollTop = function() {
			null == this.ya && (this.ya = this.o.getScrollTop());
			return this.ya;
		};
		f.getScrollLeft = function() {
			null == this.Tc && (this.Tc = this.o.getScrollLeft());
			return this.Tc;
		};
		f.setScrollTop = function(a) {
			this.ya = null;
			this.o.setScrollTop(a);
		};
		f.updatePaddingBottom = function(a) {
			this.ampdoc.waitForBodyOpen().then(function(b) {
				X(b, 'borderBottom', a + 'px solid transparent');
			});
		};
		f.getSize = function() {
			if (this.aa) return this.aa;
			this.aa = this.o.getSize();
			if (0 == this.aa.width || 0 == this.aa.height) {
				var a = this.ampdoc.getVisibilityState();
				('prerender' == a || 'visible' == a) &&
					0.01 > Math.random() &&
					F().error('Viewport', 'viewport has zero dimensions');
			}
			return this.aa;
		};
		f.getHeight = function() {
			return this.getSize().height;
		};
		f.getWidth = function() {
			return this.getSize().width;
		};
		f.getScrollWidth = function() {
			return this.o.getScrollWidth();
		};
		f.getScrollHeight = function() {
			return this.o.getScrollHeight();
		};
		f.getContentHeight = function() {
			return this.o.getContentHeight();
		};
		f.contentHeightChanged = function() {
			this.o.contentHeightChanged();
		};
		f.getRect = function() {
			if (null == this.Sb) {
				var a = this.getScrollTop(),
					b = this.getScrollLeft(),
					c = this.getSize();
				this.Sb = fc(b, a, c.width, c.height);
			}
			return this.Sb;
		};
		f.getLayoutRect = function(a, b) {
			var c = this.getScrollLeft(),
				d = this.getScrollTop(),
				e = ed(a, this.ampdoc.win);
			return e
				? ((a = this.o.getLayoutRect(a, 0, 0, b)),
					(c = this.o.getLayoutRect(e, c, d)),
					fc(Math.round(a.left + c.left), Math.round(a.top + c.top), Math.round(a.width), Math.round(a.height)))
				: this.o.getLayoutRect(a, c, d, b);
		};
		f.getClientRectAsync = function(a) {
			var b = this.A.measurePromise(function() {
					return a.getBoundingClientRect();
				}),
				c = this.o.getRootClientRectAsync(),
				d = ed(a, this.ampdoc.win);
			d &&
				(c = this.A.measurePromise(function() {
					return d.getBoundingClientRect();
				}));
			return Promise.all([ b, c ]).then(function(a) {
				var b = a[0];
				return (a = a[1])
					? ic(b, a.left, a.top)
					: fc(Number(b.left), Number(b.top), Number(b.width), Number(b.height));
			});
		};
		f.supportsPositionFixed = function() {
			return this.o.supportsPositionFixed();
		};
		f.isDeclaredFixed = function(a) {
			return this.N ? this.N.isDeclaredFixed(a) : !1;
		};
		f.scrollIntoView = function(a) {
			var b = this;
			return Nl(this, a).then(function(c) {
				return Ol(b, a, c);
			});
		};
		function Ol(a, b, c) {
			var d = a.o.getLayoutRect(b).top;
			nb(function() {
				return Math.max(0, d - a.P);
			}).then(function(b) {
				return Pl(a, c, b);
			});
		}
		f.animateScrollIntoView = function(a, b, c, d) {
			var e = this;
			b = void 0 === b ? 'top' : b;
			return Nl(this, a).then(function(g) {
				return e.animateScrollWithinParent(a, g, b, c, d);
			});
		};
		f.animateScrollWithinParent = function(a, b, c, d, e) {
			var g = this,
				h = this.o.getLayoutRect(a),
				l = (b == this.o.getScrollingElement() ? this.getSize() : this.getLayoutRect(b)).height;
			switch (c) {
				case 'bottom':
					var k = -l + h.height;
					break;
				case 'center':
					k = -l / 2 + h.height / 2;
					break;
				default:
					k = 0;
			}
			return Ql(this, b).then(function(a) {
				var c = Math.max(0, h.top - g.P + k);
				if (c != a) return Rl(g, b, a, c, d, e);
			});
		};
		function Rl(a, b, c, d, e, g) {
			g = void 0 === g ? 'ease-in' : g;
			e = void 0 !== e ? e : Math.floor(Math.min(Math.max(0.65 * Math.abs(c - d), 0), 500));
			var h = Jl(c, d);
			return rl(
				b,
				function(c) {
					Pl(a, b, h(c));
				},
				e,
				g
			).thenAlways(function() {
				Pl(a, b, d);
			});
		}
		function Nl(a, b) {
			return a.A.measurePromise(function() {
				return Fb(b, '.i-amphtml-scrollable') || a.o.getScrollingElement();
			});
		}
		function Pl(a, b, c) {
			b == a.o.getScrollingElement()
				? a.o.setScrollTop(c)
				: a.A.mutate(function() {
						b.scrollTop = c;
					});
		}
		function Ql(a, b) {
			return b == a.o.getScrollingElement()
				? nb(function() {
						return a.getScrollTop();
					})
				: a.A.measurePromise(function() {
						return b.scrollTop;
					});
		}
		f.getScrollingElement = function() {
			return this.xe ? this.xe : (this.xe = this.o.getScrollingElement());
		};
		f.onChanged = function(a) {
			return this.gf.add(a);
		};
		f.onScroll = function(a) {
			return this.Ia.add(a);
		};
		f.onResize = function(a) {
			return this.Ha.add(a);
		};
		f.enterLightboxMode = function(a, b) {
			this.h.sendMessage('requestFullOverlay', {}, !0);
			this.enterOverlayMode();
			this.N && this.N.enterLightbox(a, b);
			a && this.maybeEnterFieLightboxMode(a);
			return this.o.updateLightboxMode(!0);
		};
		f.leaveLightboxMode = function(a) {
			this.h.sendMessage('cancelFullOverlay', {}, !0);
			this.N && this.N.leaveLightbox();
			this.leaveOverlayMode();
			a && this.maybeLeaveFieLightboxMode(a);
			return this.o.updateLightboxMode(!1);
		};
		f.isLightboxExperimentOn = function() {
			return P(this.ampdoc.win, 'amp-lightbox-a4a-proto');
		};
		f.maybeEnterFieLightboxMode = function(a) {
			var b = Sl(this, a);
			b && (this.isLightboxExperimentOn(), b.enterFullOverlayMode());
		};
		f.maybeLeaveFieLightboxMode = function(a) {
			(a = Sl(this, a)) && a.leaveFullOverlayMode();
		};
		function Sl(a, b) {
			var c = ed(b, a.ampdoc.win);
			return c && c.__AMP_EMBED__;
		}
		f.enterOverlayMode = function() {
			this.disableTouchZoom();
			this.disableScroll();
		};
		f.leaveOverlayMode = function() {
			this.resetScroll();
			this.restoreOriginalTouchZoom();
		};
		f.disableScroll = function() {
			var a = this,
				b = this.ampdoc.win,
				c = b.document.documentElement,
				d;
			this.A.measure(function() {
				var e = se(b, c).marginRight;
				var g = a.ampdoc.win;
				g = g.innerWidth - g.document.documentElement.clientWidth;
				d = parseInt(e, 10) + g;
			});
			this.A.mutate(function() {
				X(c, 'margin-right', d, 'px');
				a.o.disableScroll();
			});
		};
		f.resetScroll = function() {
			var a = this,
				b = this.ampdoc.win.document.documentElement;
			this.A.mutate(function() {
				X(b, 'margin-right', '');
				a.o.resetScroll();
			});
		};
		f.resetTouchZoom = function() {
			var a = this,
				b = this.ampdoc.win.innerHeight,
				c = this.Ld.documentElement.clientHeight;
			(b && c && b === c) ||
				(this.disableTouchZoom() &&
					this.R.delay(function() {
						a.restoreOriginalTouchZoom();
					}, 50));
		};
		f.disableTouchZoom = function() {
			var a = Tl(this);
			if (!a) return !1;
			var b = a.content,
				c = { 'maximum-scale': '1', 'user-scalable': 'no' };
			var d = Object.create(null);
			if (b)
				for (var e = b.split(/,|;/), g = 0; g < e.length; g++) {
					var h = e[g].split('='),
						l = h[0].trim();
					h = h[1];
					h = (h || '').trim();
					l && (d[l] = h);
				}
			e = !1;
			for (var k in c) d[k] !== c[k] && ((e = !0), void 0 !== c[k] ? (d[k] = c[k]) : delete d[k]);
			if (e) {
				b = '';
				for (var n in d) 0 < b.length && (b += ','), (b = d[n] ? b + (n + '=' + d[n]) : b + n);
				d = b;
			} else d = b;
			return Ul(this, d);
		};
		f.restoreOriginalTouchZoom = function() {
			return void 0 !== this.oe ? Ul(this, this.oe) : !1;
		};
		f.updateFixedLayer = function() {
			return this.N ? this.N.update() : x();
		};
		f.addToFixedLayer = function(a, b) {
			return this.N ? this.N.addElement(a, b) : x();
		};
		f.removeFromFixedLayer = function(a) {
			this.N && this.N.removeElement(a);
		};
		f.createFixedLayer = function(a) {
			var b = this;
			this.N = new a(this.ampdoc, this.A, this.o.getBorderTop(), this.P, this.o.requiresFixedLayerTransfer());
			this.ampdoc.whenReady().then(function() {
				return b.N.setup();
			});
		};
		function Ul(a, b) {
			return (a = Tl(a)) && a.content != b
				? (F().fine('Viewport', 'changed viewport meta to:', b), (a.content = b), !0)
				: !1;
		}
		function Tl(a) {
			if (Qb(a.ampdoc.win)) return null;
			void 0 === a.$b && ((a.$b = a.Ld.querySelector('meta[name=viewport]')), a.$b && (a.oe = a.$b.content));
			return a.$b;
		}
		f.ei = function(a) {
			this.setScrollTop(a.scrollTop);
		};
		f.ci = function(a) {
			var b = this,
				c = a.paddingTop,
				d = a.duration || 0,
				e = a.curve,
				g = a['transient'];
			if (void 0 != c && c != this.P) {
				this.uc = this.P;
				this.P = c;
				var h = Vl(this, d, e, g);
				c < this.uc
					? this.o.hideViewerHeader(g, this.uc)
					: h.then(function() {
							b.o.showViewerHeader(g, c);
						});
			}
		};
		f.Rg = function(a) {
			a ? this.disableScroll() : this.resetScroll();
		};
		function Vl(a, b, c, d) {
			a.N.updatePaddingTop(a.P, d);
			if (0 >= b) return x();
			var e = Jl(a.uc - a.P, 0);
			return rl(
				a.ampdoc.getRootNode(),
				function(b) {
					b = e(b);
					a.N.transformMutate('translateY(' + b + 'px)');
				},
				b,
				c
			).thenAlways(function() {
				a.N.transformMutate(null);
			});
		}
		function Wl(a, b, c) {
			var d = a.getSize(),
				e = a.getScrollTop(),
				g = a.getScrollLeft();
			F().fine(
				'Viewport',
				'changed event:',
				'relayoutAll=',
				b,
				'top=',
				e,
				'left=',
				g,
				'bottom=',
				e + d.height,
				'velocity=',
				c
			);
			a.gf.fire({ relayoutAll: b, top: e, left: g, width: d.width, height: d.height, velocity: c });
		}
		f.Sh = function() {
			var a = this;
			this.Sb = null;
			this.Rh++;
			this.Tc = this.o.getScrollLeft();
			var b = this.o.getScrollTop();
			if (!(0 > b)) {
				this.ya = b;
				if (!this.we) {
					this.we = !0;
					var c = Date.now();
					this.R.delay(function() {
						a.A.measure(function() {
							a.bd(c, b);
						});
					}, 36);
				}
				this.Ia.fire();
			}
		};
		f.bd = function(a, b) {
			var c = this,
				d = (this.ya = this.o.getScrollTop()),
				e = Date.now(),
				g = 0;
			e != a && (g = (d - b) / (e - a));
			F().fine('Viewport', 'scroll: scrollTop=' + d + '; velocity=' + g);
			0.03 > Math.abs(g)
				? (Wl(this, !1, g), (this.we = !1))
				: this.R.delay(function() {
						return c.A.measure(c.bd.bind(c, e, d));
					}, 20);
		};
		f.Th = function() {
			var a = this;
			this.ve ||
				((this.ve = !0),
				this.A.measure(function() {
					a.ve = !1;
					a.h.sendMessage('scroll', K({ scrollTop: a.getScrollTop() }), !0);
				}));
		};
		f.cg = function() {
			var a = this;
			this.Sb = null;
			var b = this.aa;
			this.aa = null;
			var c = this.getSize();
			this.updateFixedLayer().then(function() {
				var d = !b || b.width != c.width;
				Wl(a, d, 0);
				(d || b.height != c.height) && a.Ha.fire({ relayoutAll: d, width: c.width, height: c.height });
			});
		};
		function Xl(a) {
			var b = V(a),
				c = a.win;
			c =
				a.isSingleDoc() &&
				(T(c).isIos() && Qb(c) && b.isEmbedded() && !b.hasCapability('iframeScroll') ? Yl : Zl) == Yl
					? new Hl(c)
					: new Il(a);
			return new Ml(a, c, b);
		}
		var Zl = 'natural',
			Yl = 'natural-ios-embed';
		var $l = [ '<div class=i-amphtml-jank-meter></div>' ];
		function am(a) {
			this.w = a;
			this.zc = this.yc = this.Xb = this.dc = 0;
			this.Tb = null;
			this.wa = ad(a);
			this.Ib = this.Qe = this.Re = null;
			bm(this);
		}
		am.prototype.onScheduled = function() {
			cm(this) && null == this.Tb && (this.Tb = this.w.Date.now());
		};
		am.prototype.onRun = function() {
			if (cm(this) && null != this.Tb) {
				var a = this.w.Date.now() - this.Tb;
				this.Tb = null;
				this.Xb++;
				16 < a && (this.dc++, F().info('JANK', 'Paint latency: ' + a + 'ms'));
				if (this.wa && 200 == this.Xb) {
					var b = this.w.Math.floor((this.Xb - this.dc) / this.Xb * 100);
					this.wa.tickDelta('gfp', b);
					this.wa.tickDelta('bf', this.dc);
					this.Ib &&
						(this.wa.tickDelta('lts', this.zc),
						this.wa.tickDelta('ltc', this.yc),
						this.Ib.disconnect(),
						(this.Ib = null));
					var c = 0;
					this.Re &&
						null != this.Qe &&
						((c = this.w.Math.max(0, this.w.Math.floor(100 * this.Re.level - this.Qe))),
						this.wa.tickDelta('bd', c));
					this.wa.flush();
					if (P(this.w, 'jank-meter')) {
						var d = c,
							e = this.w.document,
							g = je(e)($l);
						g.textContent = 'bf:' + this.dc + ', lts: ' + this.zc + ', ltc:' + (this.yc + ', bd:' + d);
						e.body.appendChild(g);
					}
				}
			}
		};
		function cm(a) {
			return P(a.w, 'jank-meter') || (a.wa && a.wa.isPerformanceTrackingOn() && 200 > a.Xb);
		}
		function bm(a) {
			cm(a) &&
				dm(a.w) &&
				((a.Ib = new a.w.PerformanceObserver(function(b) {
					for (var c = b.getEntries(), d = 0; d < c.length; d++)
						if ('longtask' == c[d].entryType) {
							var e = a.w.Math.floor(c[d].duration / 50);
							'cross-origin-descendant' == c[d].name
								? ((a.yc += e), C().info('LONGTASK', 'from child frame ' + c[d].duration + 'ms'))
								: ((a.zc += e), F().info('LONGTASK', 'from self frame ' + c[d].duration + 'ms'));
						}
				})),
				a.Ib.observe({ entryTypes: [ 'longtask' ] }));
		}
		function dm(a) {
			return (
				!!a.PerformanceObserver &&
				!!a.TaskAttributionTiming &&
				'containerName' in a.TaskAttributionTiming.prototype
			);
		}
		function em(a) {
			var b = ne(a, 'visibilityState', !0);
			if (a[b]) return a[b];
			var c = ne(a, 'hidden', !0);
			return a[c] ? (a[c] ? 'hidden' : 'visible') : 'visible';
		}
		function fm(a, b) {
			if (a.addEventListener) {
				var c = gm(a);
				c && a.addEventListener(c, b);
			}
		}
		function hm(a, b) {
			if (a.removeEventListener) {
				var c = gm(a);
				c && a.removeEventListener(c, b);
			}
		}
		function gm(a) {
			a = ne(a, 'hidden', !0);
			var b = a.indexOf('Hidden');
			return -1 != b ? a.substring(0, b) + 'Visibilitychange' : 'visibilitychange';
		}
		function im(a) {
			this.win = a;
			this.Ba = qd(this.win);
			this.Hh = jm(this);
			this.L = [];
			this.le = [];
			this.Ae = [];
			this.ke = [];
			this.ua = !1;
			this.je = this.Ec = null;
			this.xd = this.Qh.bind(this);
			this.fh = new si(this.win, this.xd, 16);
			this.Pe = new si(this.win, this.xd, 40);
			this.wd = this.Ch.bind(this);
			if (this.Ba.isSingleDoc()) this.Ba.getSingleDoc().onVisibilityChanged(this.wd);
			else fm(this.win.document, this.wd);
			this.Hf = new am(this.win);
		}
		f = im.prototype;
		f.dispose = function() {
			hm(this.win.document, this.wd);
		};
		f.Ch = function() {
			this.ua && km(this);
		};
		f.run = function(a, b) {
			this.L.push(a);
			this.Ae.push(b || void 0);
			this.xa();
		};
		f.runPromise = function(a, b) {
			this.run(a, b);
			if (this.Ec) return this.Ec;
			a = new L();
			this.je = a.resolve;
			return (this.Ec = a.promise);
		};
		f.createTask = function(a) {
			var b = this;
			return function(c) {
				b.run(a, c);
			};
		};
		f.mutate = function(a) {
			this.run({ measure: void 0, mutate: a });
		};
		f.mutatePromise = function(a) {
			return this.runPromise({ measure: void 0, mutate: a });
		};
		f.measure = function(a) {
			this.run({ measure: a, mutate: void 0 });
		};
		f.measurePromise = function(a) {
			var b = this;
			return new Promise(function(c) {
				b.measure(function() {
					c(a());
				});
			});
		};
		f.canAnimate = function(a) {
			return lm(this, a);
		};
		function lm(a, b) {
			return 'visible' != em(a.win.document)
				? !1
				: a.Ba.isSingleDoc()
					? a.Ba.getSingleDoc().isVisible()
					: b ? ((a = a.Ba.getAmpDocIfAvailable(b)), !a || a.isVisible()) : !0;
		}
		f.runAnim = function(a, b, c) {
			if (!lm(this, a))
				return F().warn('VSYNC', 'Did not schedule a vsync request, because document was invisible'), !1;
			this.run(b, c);
			return !0;
		};
		f.createAnimTask = function(a, b) {
			var c = this;
			return function(d) {
				return c.runAnim(a, b, d);
			};
		};
		f.runAnimMutateSeries = function(a, b, c) {
			var d = this;
			return lm(this, a)
				? new Promise(function(e, g) {
						var h = Date.now(),
							l = 0,
							k = d.createAnimTask(a, {
								mutate: function(a) {
									var d = Date.now() - h;
									b(d, d - l, a) ? (c && d > c ? g(Error('timeout')) : ((l = d), k(a))) : e();
								}
							});
						k({});
					})
				: Promise.reject(Error('CANCELLED'));
		};
		f.xa = function() {
			this.ua || ((this.ua = !0), this.Hf.onScheduled(), km(this));
		};
		function km(a) {
			lm(a) ? (a.Hh(a.xd), a.Pe.schedule()) : a.fh.schedule();
		}
		f.Qh = function() {
			this.Pe.cancel();
			this.ua = !1;
			this.Hf.onRun();
			var a = this.L,
				b = this.Ae,
				c = this.je;
			this.Ec = this.je = null;
			this.L = this.le;
			this.Ae = this.ke;
			for (var d = 0; d < a.length; d++) a[d].measure && !mm(a[d].measure, b[d]) && (a[d].mutate = void 0);
			for (d = 0; d < a.length; d++) a[d].mutate && mm(a[d].mutate, b[d]);
			this.le = a;
			this.ke = b;
			this.le.length = 0;
			this.ke.length = 0;
			c && c();
		};
		function jm(a) {
			var b = a.win.requestAnimationFrame || a.win.webkitRequestAnimationFrame;
			if (b) return b.bind(a.win);
			var c = 0;
			return function(b) {
				var d = Date.now(),
					g = Math.max(0, 16 - (d - c));
				c = d + g;
				a.win.setTimeout(b, g);
			};
		}
		function mm(a, b) {
			try {
				void 0 !== a(b) &&
					F().error('VSYNC', 'callback returned a value but vsync cannot propogate it: %s', a.toString());
			} catch (c) {
				return hb(c), !1;
			}
			return !0;
		}
		function nm(a) {
			Q(a, 'crypto', ih);
			Q(a, 'batched-xhr', zg);
			Q(a, 'platform', tj);
			Q(a, 'templates', Ue);
			Q(a, 'timer', pk);
			Q(a, 'timer', pk);
			Q(a, 'vsync', im);
			Q(a, 'xhr', xg);
			Q(a, 'input', Zi);
			Q(a, 'preconnect', Dj);
		}
		function om(a) {
			var b = !!a.getParent();
			R(a, 'url', qk, !0);
			b ? id(a, 'documentInfo') : R(a, 'documentInfo', lh);
			b ? id(a, 'cid') : R(a, 'cid', Pg);
			b ? id(a, 'viewer') : R(a, 'viewer', Yk, !0);
			b ? id(a, 'viewport') : R(a, 'viewport', Xl, !0);
			R(a, 'hidden-observer', Ph);
			b ? id(a, 'history') : R(a, 'history', fi);
			b ? id(a, 'resources') : R(a, 'resources', Mj);
			b ? id(a, 'owners') : R(a, 'owners', jj);
			b ? id(a, 'mutator') : R(a, 'mutator', dj);
			b ? id(a, 'url-replace') : Wk(a);
			R(a, 'action', Pf, !0);
			R(a, 'standard-actions', dk, !0);
			b ? id(a, 'storage') : ok(a);
			R(a, 'navigation', Bh, !0);
			Mh(a);
		}
		var pm = [ 'amp-ad', 'amp-embed', 'amp-video' ],
			qm = [ 'amp-mustache' ];
		function rm(a) {
			this.win = a;
			this.Ba = qd(a);
			this.Id = {};
			this.Xa = null;
		}
		f = rm.prototype;
		f.registerExtension = function(a, b, c) {
			var d = sm(this, a, !0);
			try {
				(this.Xa = a), b(c, c._), (d.loaded = !0), d.resolve && d.resolve(d.extension);
			} catch (e) {
				throw ((d.error = e), d.reject && d.reject(e), e);
			} finally {
				this.Xa = null;
			}
		};
		f.waitForExtension = function(a, b, c) {
			return U(a).timeoutPromise(
				c || 16e3,
				tm(sm(this, b, !1)),
				'Render timeout waiting for extension ' + b + ' to be load.'
			);
		};
		f.preloadExtension = function(a, b) {
			'amp-embed' == a && (a = 'amp-ad');
			var c = sm(this, a, !1);
			if (c.loaded || c.error) var d = !1;
			else
				void 0 === c.scriptPresent && ((d = um(this, a)), (c.scriptPresent = 0 < d.length)),
					(d = !c.scriptPresent);
			if (d) {
				d = b;
				b = this.win.document.createElement('script');
				b.async = !0;
				M(a, '_') ? (d = '') : b.setAttribute(0 <= qm.indexOf(a) ? 'custom-template' : 'custom-element', a);
				b.setAttribute('data-script', a);
				b.setAttribute('i-amphtml-inserted', '');
				var e = this.win.document.head.querySelector('script[nonce]');
				e && b.setAttribute('nonce', e.getAttribute('nonce'));
				b.setAttribute('crossorigin', 'anonymous');
				e = v().esm ? '.mjs' : '.js';
				var g = B.cdn;
				var h = v().rtvVersion;
				null == d && (d = '0.1');
				b.src = g + '/rtv/' + h + '/v0/' + a + (d ? '-' + d : '') + e;
				this.win.document.head.appendChild(b);
				c.scriptPresent = !0;
			}
			return tm(c);
		};
		f.installExtensionForDoc = function(a, b, c) {
			var d = this,
				e = a.getRootNode(),
				g = e.__AMP_EXT_LDR;
			g || (g = e.__AMP_EXT_LDR = I());
			if (g[b]) return g[b];
			Ri(a.win, b);
			return (g[b] = this.preloadExtension(b, c).then(function() {
				return d.installExtensionInDoc(a, b);
			}));
		};
		f.reloadExtension = function(a) {
			var b = um(this, a, !1);
			if (!b.length)
				return (
					C().error('reloadExtension', 'Extension script for "%s" is missing or was already reloaded.', a),
					null
				);
			var c = this.Id[a];
			c && (c.scriptPresent = !1);
			b.forEach(function(b) {
				return b.setAttribute('i-amphtml-loaded-new-version', a);
			});
			c = of(b[0].src);
			return this.preloadExtension(a, c.extensionVersion);
		};
		function um(a, b, c) {
			c = void 0 === c ? !0 : c;
			a = a.win.document.head.querySelectorAll(
				'script[src*="/' +
					b +
					'-"]:not([i-amphtml-loaded-new-version])' +
					(c ? '' : ':not([i-amphtml-inserted])')
			);
			for (var d = [], e = 0; e < a.length; e++) {
				var g = a[e];
				of(g.src).extensionId === b && d.push(g);
			}
			return d;
		}
		f.loadElementClass = function(a) {
			return this.preloadExtension(a).then(function(b) {
				return b.elements[a].implementationClass;
			});
		};
		f.addElement = function(a, b, c) {
			vm(this, a).extension.elements[a] = { implementationClass: b, css: c };
			this.addDocFactory(function(d) {
				wm(d, a, b, c);
			});
		};
		function wm(a, b, c, d) {
			d
				? cf(
						a,
						d,
						function() {
							xm(a.win, b, c);
						},
						!1,
						b
					)
				: xm(a.win, b, c);
		}
		function xm(a, b, c) {
			var d = Oi(a);
			if (!d[b]) Si(a, b, c);
			else if (d[b] != c)
				for (
					G(
						d[b] == hi,
						'%s is already registered. The script tag for %s is likely included twice in the page.',
						b,
						b
					),
						d[b] = c,
						d = 0;
					d < gi.length;
					d++
				) {
					var e = gi[d].element;
					e.tagName.toLowerCase() == b && e.ownerDocument.defaultView == a && (Pi(e, c), gi.splice(d--, 1));
				}
			Q(a, b, ym);
		}
		f.addService = function(a, b) {
			vm(this).extension.services.push({ serviceName: a, serviceClass: b });
			this.addDocFactory(function(c) {
				R(c, a, b, !0);
			});
		};
		f.addDocFactory = function(a, b) {
			var c = vm(this, b);
			c.docFactories.push(a);
			if (this.Xa && this.Ba.isSingleDoc()) {
				var d = this.Ba.getAmpDoc(this.win.document);
				(d.declaresExtension(this.Xa) || c.auto) && a(d);
			}
		};
		f.preinstallEmbed = function(a, b) {
			var c = a.win;
			zm(this.win, c);
			Am(c);
			b.forEach(function(a) {
				pm.includes(a) || Ri(c, a);
			});
		};
		f.installExtensionsInDoc = function(a, b) {
			var c = this;
			return Promise.all(
				b.map(function(b) {
					return c.installExtensionInDoc(a, b);
				})
			);
		};
		f.installExtensionInDoc = function(a, b) {
			var c = sm(this, b, !1);
			return tm(c).then(function() {
				a.declareExtension(b);
				c.docFactories.forEach(function(c) {
					try {
						c(a);
					} catch (e) {
						hb('Doc factory failed: ', e, b);
					}
				});
			});
		};
		function sm(a, b, c) {
			var d = a.Id[b];
			d ||
				((d = {
					extension: { elements: {}, services: [] },
					auto: c,
					docFactories: [],
					promise: void 0,
					resolve: void 0,
					reject: void 0,
					loaded: void 0,
					error: void 0,
					scriptPresent: void 0
				}),
				(a.Id[b] = d));
			return d;
		}
		function vm(a, b) {
			a.Xa || F().error('extensions', 'unknown extension for ', b);
			return sm(a, a.Xa || '_UNKNOWN_', !0);
		}
		function tm(a) {
			if (!a.promise)
				if (a.loaded) a.promise = Promise.resolve(a.extension);
				else if (a.error) a.promise = Promise.reject(a.error);
				else {
					var b = new L();
					a.promise = b.promise;
					a.resolve = b.resolve;
					a.reject = b.reject;
				}
			return a.promise;
		}
		function Am(a) {
			pm.forEach(function(b) {
				Ri(a, b);
			});
		}
		function zm(a, b) {
			var c = Oi(a)['amp-img'];
			Si(b, 'amp-img', c || hi);
			a = Oi(a)['amp-pixel'];
			Si(b, 'amp-pixel', a || hi);
		}
		function ym() {
			return {};
		}
		(function() {
			kb = $a;
			F();
			C();
		})();
		(function(a) {
			self.__AMP_REPORT_ERROR = a;
		})(
			function(a, b, c) {
				Bf(b, c);
				b &&
					a &&
					Va(b.message) &&
					!(0 <= b.message.indexOf('\u200b\u200b\u200b\u200b')) &&
					qd(a).isSingleDoc() &&
					((b = K({ errorName: b.name, errorMessage: b.message })),
					(a = qd(a).getSingleDoc().getRootNode()),
					wf(a.documentElement || a.body || a, b));
			}.bind(null, self)
		);
		function Bm(a) {
			function b(a) {
				function b() {
					g.then(function() {
						'function' == typeof a ? a(c.AMP, c.AMP._) : e.registerExtension(a.n, a.f, c.AMP);
					});
				}
				'function' != typeof a && a.i
					? Cm(e, a).then(function() {
							return Dm(c, a, b);
						})
					: Dm(c, a, b);
			}
			var c = self;
			if (c.__AMP_TAG) x();
			else {
				c.__AMP_TAG = !0;
				var d = c.AMP || [];
				Q(c, 'extensions', rm);
				var e = sd(c);
				nm(c);
				Am(c);
				c.AMP = { win: c, _: c.AMP ? c.AMP._ : void 0 };
				c.AMP.config = Ta;
				c.AMP.BaseElement = Re;
				c.AMP.BaseTemplate = Te;
				c.AMP.registerElement = e.addElement.bind(e);
				c.AMP.registerTemplate = function(a, b) {
					var d = S(c, 'templates');
					if (d.Wb[a]) {
						var e = d.Be[a];
						G(e, 'Duplicate template type: %s', a);
						delete d.Be[a];
						e(b);
					} else d.Wb[a] = Promise.resolve(b);
				};
				c.AMP.registerServiceForDoc = e.addService.bind(e);
				c.AMP.isExperimentOn = P.bind(null, c);
				c.AMP.toggleExperiment = Oc.bind(null, c);
				c.AMP.setLogLevel = Xa.bind(null);
				c.AMP.setTickFunction = function() {};
				var g = a(c, e);
				for (a = 0; a < d.length; a++) {
					var h = d[a];
					if (Em(c, h)) d.splice(a--, 1);
					else if ('function' == typeof h || 'high' == h.p) {
						try {
							b(h);
						} catch (l) {
							F().error('runtime', 'Extension failed: ', l, h.n);
						}
						d.splice(a--, 1);
					}
				}
				Fm(c, function() {
					c.AMP.push = function(a) {
						Em(c, a) || b(a);
					};
					for (var a = 0; a < d.length; a++) {
						var e = d[a];
						if (!Em(c, e))
							try {
								b(e);
							} catch (n) {
								F().error('runtime', 'Extension failed: ', n, e.n);
							}
					}
					d.length = 0;
				});
				c.AMP.push || (c.AMP.push = d.push.bind(d));
				T(c).isIos() && X(c.document.documentElement, 'cursor', 'pointer');
				(c.IntersectionObserver && c.IntersectionObserver !== xd && c.IntersectionObserverEntry) ||
					sd(c).preloadExtension('amp-intersection-observer-polyfill');
			}
		}
		function Cm(a, b) {
			if (Array.isArray(b.i))
				return (
					(b = b.i.map(function(b) {
						return a.preloadExtension(b);
					})),
					Promise.all(b)
				);
			if ('string' == typeof b.i) return a.preloadExtension(b.i);
			F().error('RUNTIME', 'dependency is neither an array or a string', b.i);
			return x();
		}
		function Dm(a, b, c) {
			'function' == typeof b || 'high' == b.p ? x().then(c) : ((c.displayName = b.n), Ai(a.document, c));
		}
		function Gm() {
			Bm(function(a) {
				Hm(a);
				Im(a);
				return xb(a.document).then(function() {
					Qi(a.AMP.ampdoc);
				});
			});
		}
		function Hm(a) {
			var b = a.document.documentElement,
				c = qd(a).getSingleDoc();
			a.AMP.ampdoc = c;
			c = V(b);
			a.AMP.viewer = c;
			v().development && ((a.AMP.toggleRuntime = c.toggleRuntime.bind(c)), (a.AMP.resources = ud(b)));
			b = wd(b);
			a.AMP.viewport = {};
			a.AMP.viewport.getScrollLeft = b.getScrollLeft.bind(b);
			a.AMP.viewport.getScrollWidth = b.getScrollWidth.bind(b);
			a.AMP.viewport.getWidth = b.getWidth.bind(b);
		}
		function Im(a) {
			a.AMP.installAmpdocServices = om.bind(null);
			a.AMP.combinedCss = pf + qf;
		}
		function Em(a, b) {
			if (!P(a, 'version-locking') || 'function' == typeof b || '2007242032002' == b.v) return !1;
			sd(a).reloadExtension(b.n);
			return !0;
		}
		function Fm(a, b) {
			P(a, 'pump-early-frame') ? (a.document.body ? (0 < bf(a).length ? b() : U(a).delay(b, 1)) : b()) : b();
		}
		function Jm() {
			var a = self;
			xj(a.document, function() {
				return Km(a);
			});
		}
		function Km(a) {
			var b = 1500,
				c = a.performance;
			c && c.timing && c.timing.navigationStart && (b = Date.now() - c.timing.navigationStart);
			var d = Math.max(1, 2100 - b);
			a.setTimeout(function() {
				Lm(a);
				var b = a.document.styleSheets;
				if (b) {
					for (
						var c = a.document.querySelectorAll(
								'link[rel~="stylesheet"]:not([href^="' + String(B.cdn).replace(ob, pb) + '"])'
							),
							h = [],
							l = 0;
						l < c.length;
						l++
					) {
						for (var k = c[l], n = !1, r = 0; r < b.length; r++)
							if (b[r].ownerNode == k) {
								n = !0;
								break;
							}
						n || h.push(k);
					}
					l = {};
					for (k = 0; k < h.length; l = { qa: l.qa, ld: l.ld }, k++)
						(l.qa = h[k]),
							(l.ld = l.qa.media || 'all'),
							(l.qa.media = 'print'),
							(l.qa.onload = (function(b) {
								return function() {
									b.qa.media = b.ld;
									Lm(a);
								};
							})(l)),
							l.qa.setAttribute('i-amphtml-timeout', d),
							l.qa.parentNode.insertBefore(l.qa, l.qa.nextSibling);
				}
			}, d);
		}
		function Lm(a) {
			a = a.document;
			if (a.fonts && a.fonts.values)
				for (var b = a.fonts.values(); (a = b.next()); ) {
					var c = a.value;
					if (!c) break;
					'loading' == c.status && 'display' in c && 'auto' == c.display && (c.display = 'swap');
				}
		}
		function Mm(a) {
			return a.waitForBodyOpen().then(function() {
				var b = a.getBody(),
					c = vb(b, function() {
						return !!b.firstElementChild;
					});
				return U(a.win).timeoutPromise(2e3, c).then(
					function() {
						return 'AMP-STORY' === b.firstElementChild.tagName;
					},
					function() {
						return !1;
					}
				);
			});
		}
		function Nm(a) {
			var b = a.win;
			tf([ '\u26a1', 'amp' ], b.document) &&
				a.isSingleDoc() &&
				Bi(a, function() {
					Mm(a).then(function(c) {
						c || sd(b).installExtensionForDoc(a, 'amp-auto-lightbox');
					});
				});
		}
		function Om(a) {
			this.win = a;
			this.Ub = null;
			var b = I();
			a.name && 0 == a.name.indexOf('__AMP__') && Object.assign(b, t(a.name.substring(7)));
			a.location && a.location.hash && Object.assign(b, t(a.location.hash));
			this.Ub = new Pm(a, { params: b });
			a.document.__AMPDOC = this.Ub;
			this.Ag = Sc(a);
			this.Of = !1;
		}
		f = Om.prototype;
		f.isSingleDoc = function() {
			return !!this.Ub;
		};
		f.getSingleDoc = function() {
			return this.Ub;
		};
		f.getAmpDocIfAvailable = function(a) {
			if (this.Ag) {
				for (var b = a; b; ) {
					var c = a.everAttached && 'function' === typeof a.getAmpDoc ? a.getAmpDoc() : null;
					if (c) return c;
					b = Bb(b);
					if (!b) break;
					var d = b.__AMPDOC;
					if (d) return d;
					b = b.host ? b.host : ed(b, this.win);
				}
				return null;
			}
			for (b = a; b; ) {
				if ((d = a.everAttached && 'function' === typeof a.getAmpDoc ? a.getAmpDoc() : null)) return d;
				if ((d = ed(b, this.win))) b = d;
				else {
					if (!this.Of) break;
					b = 9 == b.nodeType ? b : nf(b);
					if (!b) break;
					if ((d = b.__AMPDOC)) return d;
					b = b.host;
				}
			}
			return this.Ub;
		};
		f.getAmpDoc = function(a) {
			var b = this.getAmpDocIfAvailable(a);
			if (!b) throw F().createError('No ampdoc found for', a);
			return b;
		};
		f.installShadowDoc = function(a, b, c) {
			this.Of = !0;
			a = new Qm(this.win, a, b, c);
			return (b.__AMPDOC = a);
		};
		f.installFieDoc = function(a, b, c) {
			var d = b.document;
			a = new Rm(b, a, this.getAmpDoc(b.frameElement), c);
			return (d.__AMPDOC = a);
		};
		function Sm(a, b, c) {
			var d = this;
			this.win = a;
			this.$f = I();
			this.Ic = b;
			this.K = (c && c.signals) || new pi();
			this.qe = (c && c.params) || I();
			this.sa = null;
			this.mf = [];
			this.Je =
				(c && c.visibilityState) ||
				(this.qe.visibilityState && F().assertEnumValue(Xe, this.qe.visibilityState, 'VisibilityState')) ||
				null;
			this.jd = null;
			this.yg = new Y();
			this.Lf = null;
			this.Fe = [];
			var e = this.Ge.bind(this);
			this.Ic && this.Fe.push(this.Ic.onVisibilityChanged(e));
			fm(this.win.document, e);
			this.Fe.push(function() {
				return hm(d.win.document, e);
			});
			this.Ge();
		}
		f = Sm.prototype;
		f.dispose = function() {
			this.Fe.forEach(function(a) {
				return a();
			});
		};
		f.isSingleDoc = function() {
			return null;
		};
		f.getParent = function() {
			return this.Ic;
		};
		f.getWin = function() {
			return this.win;
		};
		f.signals = function() {
			return this.K;
		};
		f.getParam = function(a) {
			a = this.qe[a];
			return null == a ? null : a;
		};
		f.getMeta = function() {
			var a = this;
			if (this.sa) return I(this.sa);
			this.sa = I();
			var b = this.win.document.head.querySelectorAll('meta[name]');
			Nb(b, function(b) {
				var c = b.getAttribute('name');
				b = b.getAttribute('content');
				c && null !== b && void 0 === a.sa[c] && (a.sa[c] = b);
			});
			return I(this.sa);
		};
		f.getMetaByName = function(a) {
			if (!a) return null;
			a = this.getMeta()[a];
			return void 0 !== a ? a : null;
		};
		f.setMetaByName = function() {};
		f.declaresExtension = function(a) {
			return -1 != this.mf.indexOf(a);
		};
		f.declareExtension = function(a) {
			this.declaresExtension(a) || this.mf.push(a);
		};
		f.getRootNode = function() {
			return null;
		};
		f.getHeadNode = function() {};
		f.isBodyAvailable = function() {
			return !1;
		};
		f.getBody = function() {
			return null;
		};
		f.waitForBodyOpen = function() {
			return null;
		};
		f.isReady = function() {
			return null;
		};
		f.whenReady = function() {
			return null;
		};
		f.getUrl = function() {
			return null;
		};
		f.getElementById = function(a) {
			return this.getRootNode().getElementById(a);
		};
		f.contains = function(a) {
			return this.getRootNode().contains(a);
		};
		f.overrideVisibilityState = function(a) {
			this.Je != a && ((this.Je = a), this.Ge());
		};
		f.Ge = function() {
			for (var a = em(this.win.document), b = 'visible', c = this.Ic; c; c = c.getParent())
				if ('visible' != c.getVisibilityState()) {
					b = c.getVisibilityState();
					break;
				}
			var d = this.Je || 'visible';
			c =
				'visible' == d && 'visible' == b && 'visible' == a
					? 'visible'
					: 'hidden' == a && 'paused' == d
						? a
						: 'paused' == d || 'inactive' == d
							? d
							: 'paused' == b || 'inactive' == b
								? b
								: 'prerender' == d || 'prerender' == a || 'prerender' == b ? 'prerender' : 'hidden';
			this.jd != c &&
				((this.jd = c),
				'visible' == c
					? ((this.Lf = Date.now()),
						this.K.signal('-ampdoc-first-visible'),
						this.K.signal('-ampdoc-next-visible'))
					: this.K.reset('-ampdoc-next-visible'),
				this.yg.fire());
		};
		f.whenFirstVisible = function() {
			return this.K.whenSignal('-ampdoc-first-visible').then(function() {});
		};
		f.whenNextVisible = function() {
			return this.K.whenSignal('-ampdoc-next-visible').then(function() {});
		};
		f.getFirstVisibleTime = function() {
			return this.K.get('-ampdoc-first-visible');
		};
		f.getLastVisibleTime = function() {
			return this.Lf;
		};
		f.getVisibilityState = function() {
			return this.jd;
		};
		f.isVisible = function() {
			return 'visible' == this.jd;
		};
		f.hasBeenVisible = function() {
			return null != this.getLastVisibleTime();
		};
		f.onVisibilityChanged = function(a) {
			return this.yg.add(a);
		};
		f.registerSingleton = function(a) {
			return this.$f[a] ? !1 : (this.$f[a] = !0);
		};
		function Pm(a, b) {
			Sm.call(this, a, null, b);
			var c = this;
			this.pb = this.win.document.body
				? Promise.resolve(this.win.document.body)
				: xb(this.win.document).then(function() {
						return c.getBody();
					});
			this.Pb = zj(this.win.document);
		}
		m(Pm, Sm);
		f = Pm.prototype;
		f.isSingleDoc = function() {
			return !0;
		};
		f.getRootNode = function() {
			return this.win.document;
		};
		f.getUrl = function() {
			return this.win.location.href;
		};
		f.getHeadNode = function() {
			return this.win.document.head;
		};
		f.isBodyAvailable = function() {
			return !!this.win.document.body;
		};
		f.getBody = function() {
			return this.win.document.body;
		};
		f.waitForBodyOpen = function() {
			return this.pb;
		};
		f.isReady = function() {
			return vj(this.win.document);
		};
		f.whenReady = function() {
			return this.Pb;
		};
		function Qm(a, b, c, d) {
			Sm.call(this, a, null, d);
			this.Zb = b;
			this.hg = c;
			this.sd = null;
			var e = new L();
			this.pb = e.promise;
			this.Te = e.resolve;
			this.Rb = !1;
			var g = new L();
			this.Pb = g.promise;
			this.Qb = g.resolve;
		}
		m(Qm, Sm);
		f = Qm.prototype;
		f.isSingleDoc = function() {
			return !1;
		};
		f.getRootNode = function() {
			return this.hg;
		};
		f.getUrl = function() {
			return this.Zb;
		};
		f.getHeadNode = function() {
			return this.hg;
		};
		f.isBodyAvailable = function() {
			return !!this.sd;
		};
		f.getBody = function() {
			return this.sd;
		};
		f.setBody = function(a) {
			this.sd = a;
			this.Te(a);
			this.Te = void 0;
		};
		f.waitForBodyOpen = function() {
			return this.pb;
		};
		f.isReady = function() {
			return this.Rb;
		};
		f.setReady = function() {
			this.Rb = !0;
			this.Qb();
			this.Qb = void 0;
		};
		f.whenReady = function() {
			return this.Pb;
		};
		f.getMeta = function() {
			return I(this.sa);
		};
		f.setMetaByName = function(a, b) {
			this.sa || (this.sa = I());
			this.sa[a] = b;
		};
		function Rm(a, b, c, d) {
			Sm.call(this, a, c, d);
			var e = this;
			this.Zb = b;
			this.pb = this.win.document.body
				? Promise.resolve(this.win.document.body)
				: xb(this.win.document).then(function() {
						return e.getBody();
					});
			this.Rb = !1;
			a = new L();
			this.Pb = a.promise;
			this.Qb = a.resolve;
		}
		m(Rm, Sm);
		f = Rm.prototype;
		f.isSingleDoc = function() {
			return !1;
		};
		f.getRootNode = function() {
			return this.win.document;
		};
		f.getUrl = function() {
			return this.Zb;
		};
		f.getHeadNode = function() {
			return this.win.document.head;
		};
		f.isBodyAvailable = function() {
			return !!this.win.document.body;
		};
		f.getBody = function() {
			return this.win.document.body;
		};
		f.waitForBodyOpen = function() {
			return this.pb;
		};
		f.isReady = function() {
			return this.Rb;
		};
		f.whenReady = function() {
			return this.Pb;
		};
		f.setReady = function() {
			this.Rb = !0;
			this.Qb();
			this.Qb = void 0;
		};
		function Tm() {
			var a = self;
			Q(a, 'ampdoc', function() {
				return new Om(a);
			});
		}
		var Um = [ 'AMP-AD', 'AMP-ANALYTICS', 'AMP-PIXEL', 'AMP-AD-EXIT' ];
		function Vm(a, b, c) {
			a = Xc(a);
			return Wm(a, b, function(a) {
				return a.isDisplayed() && (a.overlaps(c) || a.isFixed()) && a.prerenderAllowed() ? !0 : !1;
			}).then(function(a) {
				var b = [];
				a.forEach(function(a) {
					Um.includes(a.element.tagName) || b.push(a.loadedOnce());
				});
				return Promise.all(b);
			});
		}
		function Wm(a, b, c) {
			return a
				.signals()
				.whenSignal('ready-scan')
				.then(function() {
					var c = [];
					ud(a).get().forEach(function(a) {
						a.hasBeenMeasured() || a.hostWin != b || a.hasOwner() || c.push(a.getPageLayoutBoxAsync());
					});
					return Promise.all(c);
				})
				.then(function() {
					return ud(a).get().filter(function(a) {
						return a.hostWin == b && !a.hasOwner() && a.hasBeenMeasured() && c(a);
					});
				});
		}
		function Xm(a) {
			var b = this;
			this.win = a;
			this.vb = [];
			this.Ce = a.performance.timeOrigin || a.performance.timing.navigationStart;
			this.j = this.h = this.C = null;
			this.Gb = this.$d = !1;
			this.qf = I();
			this.Me = '';
			this.eb = new pi();
			this.bc = this.Uc = 0;
			this.jg = !1;
			var c = (this.win.PerformanceObserver && this.win.PerformanceObserver.supportedEntryTypes) || [];
			c.includes('paint') ||
				this.eb.rejectSignal('fcp', F().createExpectedError('First Contentful Paint not supported'));
			(this.$c = c.includes('layout-shift')) ||
				this.eb.rejectSignal('cls', F().createExpectedError('Cumulative Layout Shift not supported'));
			(this.lg = c.includes('first-input')) ||
				this.eb.rejectSignal('fid', F().createExpectedError('First Input Delay not supported'));
			(this.Zc = c.includes('largest-contentful-paint')) ||
				this.eb.rejectSignal('lcpv', F().createExpectedError('Largest Contentful Paint not supported'));
			this.Xh = c.includes('navigation');
			this.tc = this.sc = null;
			this.We = this.Bh.bind(this);
			this.ne = this.ne.bind(this);
			this.addEnabledExperiment('rtv-' + v(this.win).rtvVersion);
			zj(a.document).then(function() {
				b.tick('dr');
				b.flush();
			});
			Aj(a.document).then(function() {
				b.tick('ol');
				if (!b.win.PerformancePaintTiming && b.win.chrome && 'function' == typeof b.win.chrome.loadTimes) {
					var a = 1e3 * b.win.chrome.loadTimes().firstPaintTime - b.win.performance.timing.navigationStart;
					1 >= a || b.tickDelta('fp', a);
				}
				b.flush();
			});
			Ym(this);
			Zm(this);
		}
		f = Xm.prototype;
		f.coreServicesAvailable = function() {
			var a = this,
				b = this.win.document.documentElement;
			this.C = Xc(b);
			this.h = V(b);
			this.j = ud(b);
			this.Gb = this.h.isEmbedded() && '1' === this.h.getParam('csi');
			this.C.onVisibilityChanged(this.flush.bind(this));
			$m(this);
			var c = this.h.whenMessagingReady();
			this.C.whenFirstVisible().then(function() {
				a.tick('ofv');
				a.flush();
			});
			if (this.Zc || this.$c)
				this.win.addEventListener('visibilitychange', this.We, { capture: !0 }),
					this.C.onVisibilityChanged(this.ne);
			return c
				? c
						.then(function() {
							a.tickDelta('msr', a.win.performance.now());
							a.tick('timeOrigin', void 0, a.Ce);
							return an(a);
						})
						.then(function() {
							a.$d = !0;
							bn(a);
							a.flush();
						})
				: x();
		};
		function an(a) {
			var b = qd(a.win).getSingleDoc();
			return Mm(b).then(function(b) {
				b && a.addEnabledExperiment('story');
			});
		}
		function Ym(a) {
			if ('inabox' !== v(a.win).runtime) {
				var b = !1,
					c = !1,
					d = !1,
					e = !1,
					g = function(g) {
						if ('first-paint' != g.name || b)
							if ('first-contentful-paint' != g.name || c)
								'first-input' !== g.entryType || d
									? 'layout-shift' === g.entryType
										? g.hadRecentInput || (a.bc += g.value)
										: 'largest-contentful-paint' === g.entryType
											? (g.loadTime && (a.sc = g.loadTime), g.renderTime && (a.tc = g.renderTime))
											: 'navigation' != g.entryType ||
												e ||
												('domComplete domContentLoadedEventEnd domContentLoadedEventStart domInteractive loadEventEnd loadEventStart requestStart responseStart'
													.split(' ')
													.forEach(function(b) {
														return a.tick(b, g[b]);
													}),
												(e = !0))
									: (a.tickDelta('fid', g.processingStart - g.startTime), (d = !0));
							else {
								var h = g.startTime + g.duration;
								a.tickDelta('fcp', h);
								a.tickSinceVisible('fcpv', h);
								c = !0;
							}
						else a.tickDelta('fp', g.startTime + g.duration), (b = !0);
					},
					h = [];
				a.win.PerformancePaintTiming &&
					(a.win.performance.getEntriesByType('paint').forEach(g), h.push('paint'));
				a.lg && cn(a, g).observe({ type: 'first-input', buffered: !0 });
				a.$c && cn(a, g).observe({ type: 'layout-shift', buffered: !0 });
				a.Zc && cn(a, g).observe({ type: 'largest-contentful-paint', buffered: !0 });
				a.Xh && cn(a, g).observe({ type: 'navigation', buffered: !0 });
				if (0 !== h.length) {
					var l = cn(a, g);
					try {
						l.observe({ entryTypes: h });
					} catch (k) {
						F().warn(k);
					}
				}
			}
		}
		function cn(a, b) {
			return new a.win.PerformanceObserver(function(c) {
				c.getEntries().forEach(b);
				a.flush();
			});
		}
		function Zm(a) {
			if (a.win.perfMetrics && a.win.perfMetrics.onFirstInputDelay)
				a.win.perfMetrics.onFirstInputDelay(function(b) {
					a.tickDelta('fid-polyfill', b);
					a.flush();
				});
		}
		f.Bh = function() {
			'hidden' === this.win.document.visibilityState && dn(this);
		};
		f.ne = function() {
			'inactive' === this.C.getVisibilityState() && dn(this);
		};
		function dn(a) {
			a.$c &&
				(0 === a.Uc
					? (a.tickDelta('cls', a.bc), a.flush(), (a.Uc = 1))
					: 1 === a.Uc &&
						(a.tickDelta('cls-2', a.bc),
						a.flush(),
						(a.Uc = 2),
						a.win.removeEventListener('visibilitychange', a.We, { capture: !0 })));
			if (a.Zc) {
				if (null !== a.sc) {
					a.tickDelta('lcpl', a.sc);
					var b = a.sc;
				}
				null !== a.tc && (a.tickDelta('lcpr', a.tc), (b = b || a.tc));
				null !== b && a.tickSinceVisible('lcpv', b);
				a.flush();
			}
			a.jg ||
				(a.j
					? ((a.jg = !0), a.tickDelta('ser', a.j.getSlowElementRatio()), a.flush())
					: F().error('Performance', 'Failed to tick ser due to null resources'));
		}
		function $m(a) {
			var b = !a.C.hasBeenVisible(),
				c = -1;
			a.C.whenFirstVisible().then(function() {
				c = a.win.performance.now();
				a.mark('visible');
			});
			en(a).then(function() {
				if (b) {
					var d = -1 < c ? a.win.performance.now() - c : 0;
					a.C.whenFirstVisible().then(function() {
						a.tickDelta('pc', d);
					});
					fn(a, d);
					a.mark('pc');
				} else a.tick('pc'), fn(a, a.win.performance.now() - c);
				a.flush();
			});
		}
		function en(a) {
			return a.j.whenFirstPass().then(function() {
				var b = a.win.document.documentElement,
					c = wd(b).getSize();
				c = fc(0, 0, c.width, c.height);
				return Vm(b, a.win, c);
			});
		}
		f.tick = function(a, b, c) {
			var d = K({ label: a }),
				e;
			void 0 != b
				? (d.delta = e = Math.max(b, 0))
				: void 0 != c
					? (d.value = c)
					: (this.mark(a), (e = this.win.performance.now()), (d.value = this.Ce + e));
			this.win.dispatchEvent(Ke(this.win, { label: a, delta: e }));
			this.$d && this.Gb
				? this.h.sendMessage('tick', d)
				: (50 <= this.vb.length && this.vb.shift(), this.vb.push(d));
			this.eb.signal(a, e);
		};
		f.mark = function(a) {
			this.win.performance && this.win.performance.mark && 1 == arguments.length && this.win.performance.mark(a);
		};
		f.tickDelta = function(a, b) {
			this.tick(a, b);
		};
		f.tickSinceVisible = function(a, b) {
			b = void 0 == b ? this.win.performance.now() : b;
			b = this.Ce + b;
			var c = this.C && this.C.getFirstVisibleTime();
			this.tickDelta(a, c ? Math.max(b - c, 0) : 0);
		};
		f.flush = function() {
			this.$d && this.Gb && this.h.sendMessage('sendCsi', K({ ampexp: this.Me }), !0);
		};
		f.throttledFlush = function() {
			this.og || (this.og = rf(this.win, this.flush.bind(this), 100));
			this.og();
		};
		f.addEnabledExperiment = function(a) {
			this.qf[a] = !0;
			this.Me = Object.keys(this.qf).join(',');
		};
		function bn(a) {
			a.h &&
				(a.Gb &&
					a.vb.forEach(function(b) {
						a.h.sendMessage('tick', b);
					}),
				(a.vb.length = 0));
		}
		function fn(a, b) {
			a.h && a.h.sendMessage('prerenderComplete', K({ value: b }), !0);
		}
		f.isPerformanceTrackingOn = function() {
			return this.Gb;
		};
		f.getMetric = function(a) {
			return this.eb.whenSignal(a);
		};
		function gn(a, b) {
			this.Z = a;
			this.H = b;
			this.cd = !1;
			this.ye = 0;
			this.$e = this.Ah.bind(this);
			this.Ze = this.zh.bind(this);
			this.Ye = this.yh.bind(this);
			this.Xe = this.xh.bind(this);
			this.Z.addEventListener('touchstart', this.$e, !0);
		}
		f = gn.prototype;
		f.cleanup = function() {
			hn(this);
			this.Z.removeEventListener('touchstart', this.$e, !0);
		};
		f.Ah = function(a) {
			this.cd ||
				!a.touches ||
				1 != a.touches.length ||
				0 < this.H.getScrollTop() ||
				((a = a.touches[0].clientY),
				(this.cd = !0),
				(this.ye = a),
				this.Z.addEventListener('touchmove', this.Ze, !0),
				this.Z.addEventListener('touchend', this.Ye, !0),
				this.Z.addEventListener('touchcancel', this.Xe, !0));
		};
		function hn(a) {
			a.cd = !1;
			a.ye = 0;
			a.Z.removeEventListener('touchmove', a.Ze, !0);
			a.Z.removeEventListener('touchend', a.Ye, !0);
			a.Z.removeEventListener('touchcancel', a.Xe, !0);
		}
		f.zh = function(a) {
			if (this.cd) {
				var b = a.touches[0].clientY - this.ye;
				0 < b && a.preventDefault();
				0 != b && hn(this);
			}
		};
		f.yh = function() {
			hn(this);
		};
		f.xh = function() {
			hn(this);
		};
		function jn(a) {
			var b = a.win;
			tf([ '\u26a1', 'amp' ], b.document) &&
				T(a.win).isStandalone() &&
				Bi(a, function() {
					sd(b)
						.installExtensionForDoc(a, 'amp-standalone')
						.then(function() {
							return jd(a.getBody(), 'standalone', 'amp-standalone');
						})
						.then(function(a) {
							return a.initialize();
						});
				});
		}
		function kn() {
			var a = self,
				b = a.location.href;
			if (!M(b, 'about:')) {
				var c = !1;
				v().development && (c = '0' !== t(a.location.originalHash || a.location.hash).validate);
				c
					? ln(a.document, B.cdn + '/v0/validator.js').then(function() {
							amp.validator.validateUrlAndLog(b, a.document);
						})
					: v().examiner && ln(a.document, B.cdn + '/examiner.js');
			}
		}
		function ln(a, b) {
			var c = a.createElement('script');
			c.src = b;
			(b = a.head.querySelector('script[nonce]')) && c.setAttribute('nonce', b.getAttribute('nonce'));
			b = Qe(c).then(
				function() {
					a.head.removeChild(c);
				},
				function() {}
			);
			a.head.appendChild(c);
			return b;
		}
		function mn(a, b) {
			Ai(self.document, function() {
				nm(self);
				om(a);
				b.coreServicesAvailable();
				th();
			});
			Ai(self.document, function() {
				Gm();
			});
			Ai(self.document, function() {
				var a = self;
				Si(a, 'amp-img', Ui);
				Si(a, 'amp-pixel', rj);
				Si(a, 'amp-layout', aj);
			});
			Ai(self.document, function() {
				Qi(a);
			});
			Ai(
				self.document,
				function() {
					var b = self,
						d = b.document.documentElement;
					'0' == V(d).getParam('p2r') && T(b).isChrome() && new gn(b.document, wd(d));
					Nm(a);
					jn(a);
					kn();
					jf();
					Gj();
				},
				!0
			);
			Ai(self.document, function() {
				b.tick('e_is');
				ud(a).ampInitComplete();
				b.flush();
			});
		}
		if (!self.IS_AMP_ALT) {
			self.location && (self.location.originalHash = self.location.hash);
			var ampdocService;
			try {
				Ef(), Tm(), (ampdocService = qd(self));
			} catch (a) {
				throw (lf(self.document), a);
			}
			Ai(self.document, function() {
				var a = ampdocService.getAmpDoc(self.document);
				Q(self, 'platform', tj);
				Q(self, 'performance', Xm);
				var b = S(self, 'performance');
				self.document.documentElement.hasAttribute('i-amphtml-no-boilerplate') &&
					b.addEnabledExperiment('no-boilerplate');
				v().esm && b.addEnabledExperiment('esm');
				Jm();
				b.tick('is');
				cf(
					a,
					pf + qf,
					function() {
						return mn(a, b);
					},
					!0,
					'amp-runtime'
				);
			});
			self.console &&
				(console.info || console.log)
					.call(console, 'Powered by AMP \u26a1 HTML \u2013 Version 2007242032002', self.location.href);
			self.document.documentElement.setAttribute('amp-version', '2007242032002');
		}
	})((AMP._ = AMP._ || {}));
} catch (e) {
	setTimeout(function() {
		var s = document.body.style;
		s.opacity = 1;
		s.visibility = 'visible';
		s.animation = 'none';
		s.WebkitAnimation = 'none;';
	}, 1000);
	throw e;
}
