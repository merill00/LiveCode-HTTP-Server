(self.AMP = self.AMP || []).push({
	n: 'amp-form',
	v: '2007302351001',
	f: function(AMP, _) {
		var l,
			aa =
				'function' == typeof Object.create
					? Object.create
					: function(a) {
							function b() {}
							b.prototype = a;
							return new b();
						};
		function ba(a) {
			for (
				var b = [
						'object' == typeof globalThis && globalThis,
						a,
						'object' == typeof window && window,
						'object' == typeof self && self,
						'object' == typeof global && global
					],
					c = 0;
				c < b.length;
				++c
			) {
				var d = b[c];
				if (d && d.Math == Math) return;
			}
			(function() {
				throw Error('Cannot find global object');
			})();
		}
		ba(this);
		'function' === typeof Symbol && Symbol('x');
		var ca;
		if ('function' == typeof Object.setPrototypeOf) ca = Object.setPrototypeOf;
		else {
			var da;
			a: {
				var ea = { a: !0 },
					fa = {};
				try {
					fa.__proto__ = ea;
					da = fa.a;
					break a;
				} catch (a) {}
				da = !1;
			}
			ca = da
				? function(a, b) {
						a.__proto__ = b;
						if (a.__proto__ !== b) throw new TypeError(a + ' is not extensible');
						return a;
					}
				: null;
		}
		var ha = ca;
		function n(a, b) {
			a.prototype = aa(b.prototype);
			a.prototype.constructor = a;
			if (ha) ha(a, b);
			else
				for (var c in b)
					if ('prototype' != c)
						if (Object.defineProperties) {
							var d = Object.getOwnPropertyDescriptor(b, c);
							d && Object.defineProperty(a, c, d);
						} else a[c] = b[c];
			a.Wa = b.prototype;
		}
		var ia;
		function p() {
			return ia ? ia : (ia = Promise.resolve(void 0));
		}
		function ja(a, b) {
			b = void 0 === b ? '' : b;
			try {
				return decodeURIComponent(a);
			} catch (c) {
				return b;
			}
		}
		var ka = /(?:^[#?]?|&)([^=&]+)(?:=([^&]*))?/g;
		function la(a) {
			var b = Object.create(null);
			if (!a) return b;
			for (var c; (c = ka.exec(a)); ) {
				var d = ja(c[1], c[1]),
					e = c[2] ? ja(c[2].replace(/\+/g, ' '), c[2]) : '';
				b[d] = e;
			}
			return b;
		}
		var ma = Object.prototype.toString;
		function na(a) {
			return a ? Array.prototype.slice.call(a) : [];
		}
		var q = self.AMP_CONFIG || {},
			oa =
				('string' == typeof q.cdnProxyRegex ? new RegExp(q.cdnProxyRegex) : q.cdnProxyRegex) ||
				/^https:\/\/([a-zA-Z0-9_-]+\.)?cdn\.ampproject\.org$/;
		function pa(a) {
			if (!self.document || !self.document.head || (self.location && oa.test(self.location.origin))) return null;
			var b = self.document.head.querySelector('meta[name="' + a + '"]');
			return (b && b.getAttribute('content')) || null;
		}
		var qa = {
			thirdParty: q.thirdPartyUrl || 'https://3p.ampproject.net',
			thirdPartyFrameHost: q.thirdPartyFrameHost || 'ampproject.net',
			thirdPartyFrameRegex:
				('string' == typeof q.thirdPartyFrameRegex
					? new RegExp(q.thirdPartyFrameRegex)
					: q.thirdPartyFrameRegex) || /^d-\d+\.ampproject\.net$/,
			cdn: q.cdnUrl || pa('runtime-host') || 'https://cdn.ampproject.org',
			cdnProxyRegex: oa,
			localhostRegex: /^https?:\/\/localhost(:\d+)?$/,
			errorReporting: q.errorReportingUrl || 'https://us-central1-amp-error-reporting.cloudfunctions.net/r',
			betaErrorReporting:
				q.betaErrorReportingUrl || 'https://us-central1-amp-error-reporting.cloudfunctions.net/r-beta',
			localDev: q.localDev || !1,
			trustedViewerHosts: [ /(^|\.)google\.(com?|[a-z]{2}|com?\.[a-z]{2}|cat)$/, /(^|\.)gmail\.(com|dev)$/ ],
			geoApi: q.geoApiUrl || pa('amp-geo-api')
		};
		self.__AMP_LOG = self.__AMP_LOG || { user: null, dev: null, userForEmbed: null };
		var r = self.__AMP_LOG;
		function t() {
			if (!r.user) throw Error('failed to call initLogConstructor');
			return r.user;
		}
		function u() {
			if (r.dev) return r.dev;
			throw Error('failed to call initLogConstructor');
		}
		function v(a, b, c, d) {
			t().assert(a, b, c, d, void 0, void 0, void 0, void 0, void 0, void 0, void 0);
		}
		function ra() {
			var a, b;
			this.promise = new Promise(function(c, d) {
				a = c;
				b = d;
			});
			this.resolve = a;
			this.reject = b;
		}
		function sa(a) {
			return new Promise(function(b) {
				b(a());
			});
		}
		function ta() {
			var a, b;
			this.xa = new Promise(function(c, d) {
				a = c;
				b = d;
			});
			this.Ma = a;
			this.Ka = b;
			this.ha = 0;
		}
		ta.prototype.add = function(a) {
			var b = this,
				c = ++this.ha;
			Promise.resolve(a).then(
				function(a) {
					b.ha === c && b.Ma(a);
				},
				function(a) {
					b.ha === c && b.Ka(a);
				}
			);
			return this.xa;
		};
		ta.prototype.then = function(a, b) {
			return this.xa.then(a, b);
		};
		var ua = Object.prototype.hasOwnProperty;
		function w() {
			return Object.create(null);
		}
		function x(a) {
			return a || {};
		}
		function va(a, b) {
			var c = void 0 === c ? 10 : c;
			var d = [],
				e = [];
			e.push({ t: a, s: b, d: 0 });
			for (a = {}; 0 < e.length; ) {
				b = e.shift();
				a.G = b.t;
				a.B = b.s;
				a.Y = b.d;
				if (d.includes(a.B)) throw Error('Source object has a circular reference.');
				d.push(a.B);
				a.G !== a.B &&
					(a.Y > c
						? Object.assign(a.G, a.B)
						: Object.keys(a.B).forEach(
								(function(a) {
									return function(b) {
										var c = a.B[b];
										if (ua.call(a.G, b)) {
											var d = a.G[b];
											if ('[object Object]' === ma.call(c) && '[object Object]' === ma.call(d)) {
												e.push({ t: d, s: c, d: a.Y + 1 });
												return;
											}
										}
										a.G[b] = c;
									};
								})(a)
							));
				a = { B: a.B, G: a.G, Y: a.Y };
			}
		}
		function y() {
			this.Ga = 100;
			this.ga = this.na = 0;
			this.$ = Object.create(null);
		}
		y.prototype.has = function(a) {
			return !!this.$[a];
		};
		y.prototype.get = function(a) {
			var b = this.$[a];
			if (b) return (b.access = ++this.ga), b.payload;
		};
		y.prototype.put = function(a, b) {
			this.has(a) || this.na++;
			this.$[a] = { payload: b, access: this.ga };
			if (!(this.na <= this.Ga)) {
				u().warn('lru-cache', 'Trimming LRU cache');
				a = this.$;
				var c = this.ga + 1,
					d;
				for (d in a) {
					var e = a[d].access;
					if (e < c) {
						c = e;
						var f = d;
					}
				}
				void 0 !== f && (delete a[f], this.na--);
			}
		};
		function wa(a, b) {
			return b.length > a.length ? !1 : 0 == a.lastIndexOf(b, 0);
		}
		var xa = x({ c: !0, v: !0, a: !0, ad: !0, action: !0 }),
			ya,
			za,
			Aa = /[?&]amp_js[^&]*/,
			Ba = /[?&]amp_gsa[^&]*/,
			Ca = /[?&]amp_r[^&]*/,
			Da = /[?&]amp_kit[^&]*/,
			Ea = /[?&]usqp[^&]*/;
		function z(a) {
			ya ||
				((ya = self.document.createElement('a')),
				(za = self.__AMP_URL_CACHE || (self.__AMP_URL_CACHE = new y())));
			var b = za,
				c = ya;
			if (b && b.has(a)) a = b.get(a);
			else {
				c.href = a;
				c.protocol || (c.href = c.href);
				var d = {
					href: c.href,
					protocol: c.protocol,
					host: c.host,
					hostname: c.hostname,
					port: '0' == c.port ? '' : c.port,
					pathname: c.pathname,
					search: c.search,
					hash: c.hash,
					origin: null
				};
				'/' !== d.pathname[0] && (d.pathname = '/' + d.pathname);
				if (('http:' == d.protocol && 80 == d.port) || ('https:' == d.protocol && 443 == d.port))
					(d.port = ''), (d.host = d.hostname);
				d.origin =
					c.origin && 'null' != c.origin
						? c.origin
						: 'data:' != d.protocol && d.host ? d.protocol + '//' + d.host : d.href;
				b && b.put(a, d);
				a = d;
			}
			return a;
		}
		function Fa(a, b, c) {
			if (!b) return a;
			var d = a.split('#', 2),
				e = d[0].split('?', 2),
				f = e[0] + (e[1] ? (c ? '?' + b + '&' + e[1] : '?' + e[1] + '&' + b) : '?' + b);
			return (f += d[1] ? '#' + d[1] : '');
		}
		function Ga(a) {
			var b = [],
				c;
			for (c in a) {
				var d = a[c];
				if (null != d)
					if (Array.isArray(d))
						for (var e = 0; e < d.length; e++) {
							var f = d[e];
							b.push(encodeURIComponent(c) + '=' + encodeURIComponent(f));
						}
					else (e = d), b.push(encodeURIComponent(c) + '=' + encodeURIComponent(e));
			}
			return b.join('&');
		}
		function Ha(a) {
			'string' == typeof a && (a = z(a));
			return qa.cdnProxyRegex.test(a.origin);
		}
		function Ia(a) {
			if (a.__AMP__EXPERIMENT_TOGGLES) return a.__AMP__EXPERIMENT_TOGGLES;
			a.__AMP__EXPERIMENT_TOGGLES = Object.create(null);
			var b = a.__AMP__EXPERIMENT_TOGGLES;
			if (a.AMP_CONFIG)
				for (var c in a.AMP_CONFIG) {
					var d = a.AMP_CONFIG[c];
					'number' === typeof d && 0 <= d && 1 >= d && (b[c] = Math.random() < d);
				}
			if (
				a.AMP_CONFIG &&
				Array.isArray(a.AMP_CONFIG['allow-doc-opt-in']) &&
				0 < a.AMP_CONFIG['allow-doc-opt-in'].length
			) {
				var e = a.AMP_CONFIG['allow-doc-opt-in'],
					f = a.document.head.querySelector('meta[name="amp-experiments-opt-in"]');
				if (f) {
					var h = f.getAttribute('content').split(',');
					for (c = 0; c < h.length; c++) -1 != e.indexOf(h[c]) && (b[h[c]] = !0);
				}
			}
			Object.assign(b, Ja(a));
			if (
				a.AMP_CONFIG &&
				Array.isArray(a.AMP_CONFIG['allow-url-opt-in']) &&
				0 < a.AMP_CONFIG['allow-url-opt-in'].length
			) {
				c = a.AMP_CONFIG['allow-url-opt-in'];
				a = la(a.location.originalHash || a.location.hash);
				for (var g = 0; g < c.length; g++) {
					var k = a['e-' + c[g]];
					'1' == k && (b[c[g]] = !0);
					'0' == k && (b[c[g]] = !1);
				}
			}
			return b;
		}
		function Ja(a) {
			var b = '';
			try {
				'localStorage' in a && (b = a.localStorage.getItem('amp-experiment-toggles'));
			} catch (e) {
				u().warn('EXPERIMENTS', 'Failed to retrieve experiments from localStorage.');
			}
			var c = b ? b.split(/\s*,\s*/g) : [];
			a = Object.create(null);
			for (var d = 0; d < c.length; d++)
				0 != c[d].length && ('-' == c[d][0] ? (a[c[d].substr(1)] = !1) : (a[c[d]] = !0));
			return a;
		}
		var Ka = [
			{
				experimentId: 'ampdoc-fie',
				isTrafficEligible: function() {
					return !0;
				},
				branches: [ '21066823', '21066824' ]
			}
		];
		function A(a, b) {
			var c = a.ownerDocument.defaultView,
				d = c.__AMP_TOP || (c.__AMP_TOP = c),
				e = c != d,
				f;
			if (Ia(d)['ampdoc-fie']) {
				d.__AMP_EXPERIMENT_BRANCHES = d.__AMP_EXPERIMENT_BRANCHES || {};
				for (f = 0; f < Ka.length; f++) {
					var h = Ka[f],
						g = h.experimentId;
					ua.call(d.__AMP_EXPERIMENT_BRANCHES, g) ||
						(h.isTrafficEligible && h.isTrafficEligible(d)
							? !d.__AMP_EXPERIMENT_BRANCHES[g] &&
								Ia(d)[g] &&
								((h = h.branches),
								(d.__AMP_EXPERIMENT_BRANCHES[g] = h[Math.floor(Math.random() * h.length)] || null))
							: (d.__AMP_EXPERIMENT_BRANCHES[g] = null));
				}
				f = '21066824' === (d.__AMP_EXPERIMENT_BRANCHES ? d.__AMP_EXPERIMENT_BRANCHES['ampdoc-fie'] : null);
			} else f = !1;
			var k = f;
			e && !k ? (b = La(c, b) ? B(c, b) : null) : ((a = C(a)), (a = D(a)), (b = La(a, b) ? B(a, b) : null));
			return b;
		}
		function E(a, b) {
			a = a.__AMP_TOP || (a.__AMP_TOP = a);
			return B(a, b);
		}
		function F(a, b) {
			var c = C(a);
			c = D(c);
			return B(c, b);
		}
		function Ma(a, b) {
			return Na(D(a), b);
		}
		function C(a) {
			return a.nodeType ? E((a.ownerDocument || a).defaultView, 'ampdoc').getAmpDoc(a) : a;
		}
		function D(a) {
			a = C(a);
			return a.isSingleDoc() ? a.win : a;
		}
		function B(a, b) {
			La(a, b);
			a = Oa(a)[b];
			a.obj ||
				((a.obj = new a.ctor(a.context)), (a.ctor = null), (a.context = null), a.resolve && a.resolve(a.obj));
			return a.obj;
		}
		function Pa(a, b) {
			var c = Na(a, b);
			if (c) return c;
			a = Oa(a);
			a[b] = Qa();
			return a[b].promise;
		}
		function Na(a, b) {
			var c = Oa(a)[b];
			if (c) {
				if (c.promise) return c.promise;
				B(a, b);
				return (c.promise = Promise.resolve(c.obj));
			}
			return null;
		}
		function Oa(a) {
			var b = a.__AMP_SERVICES;
			b || (b = a.__AMP_SERVICES = {});
			return b;
		}
		function La(a, b) {
			a = a.__AMP_SERVICES && a.__AMP_SERVICES[b];
			return !(!a || (!a.ctor && !a.obj));
		}
		function Qa() {
			var a = new ra(),
				b = a.promise,
				c = a.resolve;
			a = a.reject;
			b.catch(function() {});
			return { obj: null, promise: b, resolve: c, reject: a, context: null, ctor: null };
		} /*
 https://mths.be/cssescape v1.5.1 by @mathias | MIT license */
		var Ra = /(\0)|^(-)$|([\x01-\x1f\x7f]|^-?[0-9])|([\x80-\uffff0-9a-zA-Z_-]+)|[^]/g;
		function Sa(a, b, c, d, e) {
			return e
				? e
				: b ? '\ufffd' : d ? a.slice(0, -1) + '\\' + a.slice(-1).charCodeAt(0).toString(16) + ' ' : '\\' + a;
		}
		var Ta;
		function Ua(a, b) {
			for (var c = [], d = a.parentElement; d; d = d.parentElement) b(d) && c.push(d);
			return c;
		}
		function Va(a) {
			var b = 'fieldset';
			/^[\w-]+$/.test(b);
			b = b.toUpperCase();
			return Ua(a, function(a) {
				return a.tagName == b;
			});
		}
		function G(a, b) {
			for (var c = a.length, d = 0; d < c; d++) b(a[d], d);
		}
		function Wa(a, b, c) {
			var d = Ma(a, b);
			if (d) return d;
			var e = C(a);
			return e
				.waitForBodyOpen()
				.then(function() {
					var a = e.win;
					var b = e.win.document.head;
					if (b) {
						var d = {};
						b = b.querySelectorAll('script[custom-element],script[custom-template]');
						for (var k = 0; k < b.length; k++) {
							var m = b[k];
							m = m.getAttribute('custom-element') || m.getAttribute('custom-template');
							d[m] = !0;
						}
						d = Object.keys(d);
					} else d = [];
					return d.includes(c) ? E(a, 'extensions').waitForExtension(a, c) : p();
				})
				.then(function() {
					var d = e.win;
					return d.__AMP_EXTENDED_ELEMENTS && d.__AMP_EXTENDED_ELEMENTS[c] ? Pa(D(a), b) : null;
				});
		}
		function H(a) {
			return F(a, 'mutator');
		}
		var Xa,
			Ya = 'Webkit webkit Moz moz ms O o'.split(' ');
		function Za(a, b, c) {
			var d = a.style;
			if (!wa(b, '--')) {
				Xa || (Xa = w());
				var e = Xa[b];
				if (!e) {
					e = b;
					if (void 0 === d[b]) {
						var f = b.charAt(0).toUpperCase() + b.slice(1);
						b: {
							for (var h = 0; h < Ya.length; h++) {
								var g = Ya[h] + f;
								if (void 0 !== d[g]) {
									f = g;
									break b;
								}
							}
							f = '';
						}
						void 0 !== d[f] && (e = f);
					}
					Xa[b] = e;
				}
				b = e;
			}
			b && (wa(b, '--') ? a.style.setProperty(b, c) : (a.style[b] = c));
		}
		function $a(a, b) {
			void 0 === b && (b = a.hasAttribute('hidden'));
			b ? a.removeAttribute('hidden') : a.setAttribute('hidden', '');
		}
		var I;
		function ab(a, b, c) {
			var d = a,
				e = c;
			var f = function(a) {
				try {
					return e(a);
				} catch (k) {
					throw (self.__AMP_REPORT_ERROR(k), k);
				}
			};
			var h = bb();
			d.addEventListener(b, f, h ? void 0 : !1);
			return function() {
				d && d.removeEventListener(b, f, h ? void 0 : !1);
				f = d = e = null;
			};
		}
		function bb() {
			if (void 0 !== I) return I;
			I = !1;
			try {
				var a = {
					get capture() {
						I = !0;
					}
				};
				self.addEventListener('test-options', null, a);
				self.removeEventListener('test-options', null, a);
			} catch (b) {}
			return I;
		}
		function cb(a, b, c, d) {
			var e = { detail: c };
			Object.assign(e, d);
			if ('function' == typeof a.CustomEvent) return new a.CustomEvent(b, e);
			a = a.document.createEvent('CustomEvent');
			a.initCustomEvent(b, !!e.bubbles, !!e.cancelable, c);
			return a;
		}
		function db(a, b, c) {
			return ab(a, b, c);
		}
		function eb(a, b) {
			var c = b,
				d = ab(a, 'mouseup', function(a) {
					try {
						c(a);
					} finally {
						(c = null), d();
					}
				});
			return d;
		}
		function fb(a) {
			var b,
				c = new Promise(function(c) {
					b = eb(a, c);
				});
			c.then(b, b);
			return c;
		}
		function hb(a, b) {
			function c(c) {
				f = null;
				e = a.setTimeout(d, 100);
				b.apply(null, c);
			}
			function d() {
				e = 0;
				f && c(f);
			}
			var e = 0,
				f = null;
			return function(a) {
				for (var b = [], d = 0; d < arguments.length; ++d) b[d - 0] = arguments[d];
				e ? (f = b) : c(b);
			};
		}
		function ib(a) {
			var b = a.getRootNode();
			this.S = b.ownerDocument || b;
			this.j = this.S.defaultView;
			this.pa = F(a, 'viewport');
			this.U = [];
			this.U.push(
				db(b, 'input', function(a) {
					a = a.target;
					'TEXTAREA' == a.tagName && a.hasAttribute('autoexpand') && jb(a);
				})
			);
			this.U.push(
				db(b, 'mousedown', function(a) {
					1 == a.which && ((a = a.target), 'TEXTAREA' == a.tagName && kb(a));
				})
			);
			var c = b.querySelectorAll('textarea');
			this.U.push(
				db(b, 'amp:dom-update', function() {
					c = b.querySelectorAll('textarea');
				})
			);
			var d = hb(this.j, function(a) {
				a.relayoutAll && lb(c);
			});
			this.U.push(this.pa.onResize(d));
			mb(c);
		}
		function nb(a) {
			function b() {
				var b = c.querySelector('textarea[autoexpand]');
				b && !d ? (d = new ib(a)) : !b && d && (d.dispose(), (d = null));
			}
			var c = a.getRootNode(),
				d = null;
			ab(c, 'amp:dom-update', b);
			b();
		}
		ib.prototype.dispose = function() {
			this.U.forEach(function(a) {
				return a();
			});
		};
		function mb(a) {
			Promise.all(
				na(a).map(function(a) {
					return ob(a).then(function(b) {
						b &&
							(t().warn(
								'AMP-FORM',
								'"textarea[autoexpand]" with initially scrolling content will not autoexpand.\nSee https://github.com/ampproject/amphtml/issues/20839'
							),
							a.removeAttribute('autoexpand'));
					});
				})
			);
		}
		function ob(a) {
			return H(a).measureElement(function() {
				return a.scrollHeight > a.clientHeight;
			});
		}
		function lb(a) {
			G(a, function(a) {
				'TEXTAREA' == a.tagName && a.hasAttribute('autoexpand') && jb(a);
			});
		}
		function kb(a) {
			var b = H(a);
			Promise.all([
				b.measureElement(function() {
					return a.scrollHeight;
				}),
				fb(a)
			]).then(function(c) {
				var d = c[0],
					e = 0;
				return b.measureMutateElement(
					a,
					function() {
						e = a.scrollHeight;
					},
					function() {
						d != e && a.removeAttribute('autoexpand');
					}
				);
			});
		}
		function jb(a) {
			var b = H(a),
				c = a.ownerDocument.defaultView,
				d = 0,
				e = 0,
				f = 0,
				h = pb(a);
			b.measureMutateElement(
				a,
				function() {
					var b = c.getComputedStyle(a) || w();
					e = a.scrollHeight;
					var h = parseInt(b.getPropertyValue('max-height'), 10);
					f = isNaN(h) ? Infinity : h;
					d =
						'content-box' == b.getPropertyValue('box-sizing')
							? -parseInt(b.getPropertyValue('padding-top'), 10) +
								-parseInt(b.getPropertyValue('padding-bottom'), 10)
							: parseInt(b.getPropertyValue('border-top-width'), 10) +
								parseInt(b.getPropertyValue('border-bottom-width'), 10);
				},
				function() {
					return h.then(function(b) {
						a.classList.toggle('i-amphtml-textarea-max', b + d > f);
						if ('iAmphtmlHasExpanded' in a.dataset || e <= b)
							(a.dataset.iAmphtmlHasExpanded = ''), Za(a, 'height', b + d + 'px');
					});
				}
			);
		}
		function pb(a) {
			var b = a.ownerDocument,
				c = b.defaultView,
				d = b.body,
				e = H(a),
				f = a.cloneNode(!1);
			f.classList.add('i-amphtml-textarea-clone');
			var h = 0,
				g = 0,
				k = !1;
			return e
				.measureMutateElement(
					d,
					function() {
						var b = c.getComputedStyle(a) || w(),
							d = parseInt(b.getPropertyValue('max-height'), 10);
						h = parseInt(b.getPropertyValue('width'), 10);
						k = isNaN(d) || a.scrollHeight < d;
					},
					function() {
						k && (a.scrollTop = 0);
						Za(f, 'width', h + 'px');
						b.body.appendChild(f);
					}
				)
				.then(function() {
					return e.measureMutateElement(
						d,
						function() {
							g = f.scrollHeight;
						},
						function() {
							f.parentElement && f.parentElement.removeChild(f);
						}
					);
				})
				.then(function() {
					return g;
				});
		}
		function J(a) {
			for (
				var b = a.elements,
					c = {},
					d = /^(?:input|select|textarea)$/i,
					e = /^(?:submit|button|image|file|reset)$/i,
					f = /^(?:checkbox|radio)$/i,
					h = {},
					g = 0;
				g < b.length;
				h = { F: h.F }, g++
			) {
				var k = b[g],
					m = k,
					P = m.checked;
				h.F = m.name;
				var gc = m.multiple,
					hc = m.options,
					ic = m.tagName,
					gb = m.type;
				m = m.value;
				!h.F ||
					qb(k) ||
					!d.test(ic) ||
					e.test(gb) ||
					(f.test(gb) && !P) ||
					(void 0 === c[h.F] && (c[h.F] = []),
					gc
						? G(
								hc,
								(function(a) {
									return function(b) {
										b.selected && c[a.F].push(b.value);
									};
								})(h)
							)
						: c[h.F].push(m));
			}
			var Q = rb(a);
			Q && Q.name && ((a = Q.name), void 0 === c[a] && (c[a] = []), c[Q.name].push(Q.value));
			Object.keys(c).forEach(function(a) {
				0 == c[a].length && delete c[a];
			});
			return c;
		}
		function rb(a) {
			var b = a.elements,
				c = b.length,
				d = a.ownerDocument.activeElement,
				e = null;
			for (a = 0; a < c; a++) {
				var f = b[a],
					h = f.type;
				if ('BUTTON' == f.tagName || 'submit' == h) if ((e || (e = f), d == f)) return d;
			}
			return e;
		}
		function qb(a) {
			if (a.disabled) return !0;
			a = Va(a);
			for (var b = 0; b < a.length; b++) if (a[b].disabled) return !0;
			return !1;
		}
		function sb(a) {
			switch (a.type) {
				case 'select-multiple':
				case 'select-one':
					a = a.options;
					for (var b = 0; b < a.length; b++) if (a[b].selected !== a[b].defaultSelected) return !1;
					break;
				case 'checkbox':
				case 'radio':
					return a.checked === a.defaultChecked;
				default:
					return a.value === a.defaultValue;
			}
			return !0;
		}
		function tb(a, b) {
			return a.hasAttribute('verify-xhr') ? new ub(a, b) : new vb(a);
		}
		function K(a) {
			this.h = a;
		}
		K.prototype.onCommit = function() {
			wb(this);
			a: {
				var a = this.h.elements;
				for (var b = 0; b < a.length; b++) {
					var c = a[b];
					if (!c.disabled && !sb(c)) {
						a = !0;
						break a;
					}
				}
				a = !1;
			}
			return a ? this.Aa() : Promise.resolve({ updatedElements: [], errors: [] });
		};
		K.prototype.Aa = function() {
			return Promise.resolve({ updatedElements: [], errors: [] });
		};
		function wb(a) {
			(a = a.h.elements) &&
				G(a, function(a) {
					a.setCustomValidity('');
				});
		}
		function vb() {
			K.apply(this, arguments);
		}
		n(vb, K);
		function ub(a, b) {
			this.h = a;
			this.ba = b;
			this.X = null;
			this.wa = [];
		}
		n(ub, K);
		ub.prototype.Aa = function() {
			var a = this,
				b = this.ba().then(
					function() {
						return [];
					},
					function(a) {
						return xb(a);
					}
				);
			return yb(this, b).then(function(b) {
				return zb(a, b);
			});
		};
		function yb(a, b) {
			if (!a.X) {
				a.X = new ta();
				var c = function() {
					return (a.X = null);
				};
				a.X.then(c, c);
			}
			return a.X.add(b);
		}
		function zb(a, b) {
			var c = [],
				d = a.wa;
			a.wa = b;
			for (var e = 0; e < b.length; e++) {
				var f = b[e],
					h = t().assertString(f.name, 'Verification errors must have a name property');
				f = t().assertString(f.message, 'Verification errors must have a message property');
				h = t().assertElement(
					a.h.querySelector('[name="' + h + '"]'),
					'Verification error name property must match a field name'
				);
				h.checkValidity() && (h.setCustomValidity(f), c.push(h));
			}
			var g = d
				.filter(function(a) {
					return b.every(function(b) {
						return a.name !== b.name;
					});
				})
				.map(function(b) {
					return a.h.querySelector('[name="' + b.name + '"]');
				});
			return { updatedElements: c.concat(g), errors: b };
		}
		function xb(a) {
			return (a = a.response)
				? a.json().then(
						function(a) {
							return a.verifyErrors || [];
						},
						function() {
							return [];
						}
					)
				: Promise.resolve([]);
		}
		function Ab(a, b) {
			var c = E(a, 'platform');
			return c.isIos() && 11 == c.getMajorVersion()
				? new Bb(b)
				: FormData.prototype.entries && FormData.prototype.delete ? new L(b) : new M(b);
		}
		function M(a) {
			this.C = a ? J(a) : w();
		}
		M.prototype.append = function(a, b) {
			var c = String(a);
			this.C[c] = this.C[c] || [];
			this.C[c].push(String(b));
		};
		M.prototype.delete = function(a) {
			delete this.C[a];
		};
		M.prototype.entries = function() {
			var a = this,
				b = [];
			Object.keys(this.C).forEach(function(c) {
				a.C[c].forEach(function(a) {
					return b.push([ c, a ]);
				});
			});
			var c = 0;
			return {
				next: function() {
					return c < b.length ? { value: b[c++], done: !1 } : { value: void 0, done: !0 };
				}
			};
		};
		M.prototype.getFormData = function() {
			var a = this,
				b = new FormData();
			Object.keys(this.C).forEach(function(c) {
				a.C[c].forEach(function(a) {
					return b.append(c, a);
				});
			});
			return b;
		};
		function L(a) {
			this.D = new FormData(a);
			a && (a = rb(a)) && a.name && this.append(a.name, a.value);
		}
		L.prototype.append = function(a, b) {
			this.D.append(a, b);
		};
		L.prototype.delete = function(a) {
			this.D.delete(a);
		};
		L.prototype.entries = function() {
			return this.D.entries();
		};
		L.prototype.getFormData = function() {
			return this.D;
		};
		function Bb(a) {
			L.call(this, a);
			var b = this;
			a &&
				G(a.elements, function(a) {
					'file' == a.type &&
						0 == a.files.length &&
						(b.D.delete(a.name), b.D.append(a.name, new Blob([]), ''));
				});
		}
		n(Bb, L);
		Bb.prototype.append = function(a, b, c) {
			b && 'object' == typeof b && '' == b.name && 0 == b.size
				? this.D.append(a, new Blob([]), c || '')
				: this.D.append(a, b);
		};
		var Cb = { INPUT: !0, SELECT: !0, TEXTAREA: !0 };
		function Db(a, b) {
			this.h = a;
			this.j = b;
			this.R = 0;
			this.K = w();
			this.oa = null;
			this.Ca = this.da = !1;
			this.ma();
			for (a = 0; a < this.h.elements.length; ++a) Eb(this, this.h.elements[a]);
			N(this);
		}
		l = Db.prototype;
		l.onSubmitting = function() {
			this.da = !0;
			N(this);
		};
		l.onSubmitError = function() {
			this.da = !1;
			N(this);
		};
		l.onSubmitSuccess = function() {
			this.da = !1;
			this.oa = Ab(this.j, this.h).getFormData();
			this.K = w();
			this.R = 0;
			N(this);
		};
		function N(a) {
			var b = 0 < a.R && !a.da;
			if (b !== a.Ca) {
				a.h.classList.toggle('amp-form-dirty', b);
				var c = cb(a.j, 'amp:form-dirtiness-change', x({ isDirty: b }), { bubbles: !0 });
				a.h.dispatchEvent(c);
			}
			a.Ca = b;
		}
		l.ma = function() {
			this.h.addEventListener('input', this.va.bind(this));
			this.h.addEventListener('reset', this.Ja.bind(this));
			this.h.addEventListener('amp:form-value-change', this.va.bind(this));
		};
		l.va = function(a) {
			Eb(this, a.target);
			N(this);
		};
		l.Ja = function() {
			this.K = w();
			this.R = 0;
			N(this);
		};
		function Eb(a, b) {
			var c = b.hidden;
			if (Cb[b.tagName] && b.name && !c && !qb(b)) {
				a: switch (b.tagName) {
					case 'INPUT':
						c = 'checkbox' == b.type || 'radio' == b.type ? !b.checked : !b.value;
						break a;
					case 'TEXTAREA':
						c = !b.value;
						break a;
					case 'SELECT':
						c = !1;
						break a;
					default:
						throw Error('isFieldEmpty: ' + b.tagName + ' is not a supported field element.');
				}
				(c = c || sb(b)) || (a.oa ? ((c = b.value), (c = a.oa.get(b.name) === c)) : (c = !1));
				c ? ((b = b.name), a.K[b] && ((a.K[b] = !1), --a.R)) : ((b = b.name), a.K[b] || ((a.K[b] = !0), ++a.R));
			}
		}
		function Fb() {
			this.o = null;
		}
		l = Fb.prototype;
		l.add = function(a) {
			var b = this;
			this.o || (this.o = []);
			this.o.push(a);
			return function() {
				b.remove(a);
			};
		};
		l.remove = function(a) {
			this.o && ((a = this.o.indexOf(a)), -1 < a && this.o.splice(a, 1));
		};
		l.removeAll = function() {
			this.o && (this.o.length = 0);
		};
		l.fire = function(a) {
			if (this.o) for (var b = this.o, c = 0; c < b.length; c++) (0, b[c])(a);
		};
		l.getHandlerCount = function() {
			return this.o ? this.o.length : 0;
		};
		function Gb() {
			this.ua = new Fb();
		}
		Gb.prototype.beforeSubmit = function(a) {
			return this.ua.add(a);
		};
		Gb.prototype.fire = function(a) {
			this.ua.fire(a);
		};
		var Hb = [ 'GET', 'POST' ];
		function Ib(a) {
			var b = a.getAttribute('crossorigin');
			return b && 'amp-viewer-auth-token-via-post' === b.trim()
				? Wa(a, 'amp-viewer-assistance', 'amp-viewer-assistance')
						.then(function(a) {
							v(a, 'crossorigin="amp-viewer-auth-token-post" requires amp-viewer-assistance extension.');
							return a.getIdTokenPromise();
						})
						.then(function(a) {
							return a || '';
						})
						.catch(function() {
							return '';
						})
				: Promise.resolve(void 0);
		}
		function O(a, b) {
			this.L = a;
			this.A = b;
			this.Na = 'amp-form';
		}
		O.prototype.isEnabled = function() {
			var a = this.L.getAmpDoc();
			return a.isSingleDoc() && a.getRootNode().documentElement.hasAttribute('allow-viewer-render-template')
				? this.L.hasCapability('viewerRenderTemplate')
				: !1;
		};
		O.prototype.assertTrustedViewer = function(a) {
			return this.L.isTrustedViewer().then(function(b) {
				v(b, 'Refused to attempt SSR in untrusted viewer: ', a);
			});
		};
		O.prototype.ssr = function(a, b, c, d) {
			var e = this;
			c = void 0 === c ? null : c;
			d = void 0 === d ? {} : d;
			var f;
			c || (f = this.A.maybeFindTemplate(a));
			return this.assertTrustedViewer(a).then(function() {
				return e.L.sendMessageAwaitResponse('viewerRenderTemplate', Jb(e, b, f, c, d));
			});
		};
		O.prototype.applySsrOrCsrTemplate = function(a, b) {
			var c = this;
			if (this.isEnabled()) {
				v('string' === typeof b.html, 'Server side html response must be defined');
				var d = this.assertTrustedViewer(a).then(function() {
					return c.A.findAndSetHtmlForTemplate(a, b.html);
				});
			} else d = Array.isArray(b) ? this.A.findAndRenderTemplateArray(a, b) : this.A.findAndRenderTemplate(a, b);
			return d;
		};
		function Jb(a, b, c, d, e) {
			e = void 0 === e ? {} : e;
			var f = x({ type: a.Na }),
				h = d && d.successTemplate ? d.successTemplate : c;
			h && (f.successTemplate = { type: 'amp-mustache', payload: h.innerHTML });
			var g = d && d.errorTemplate ? d.errorTemplate : null;
			g && (f.errorTemplate = { type: 'amp-mustache', payload: g.innerHTML });
			e && Object.assign(f, e);
			a = b.xhrUrl;
			c = b.fetchOpt;
			b = Object.assign({}, c);
			if ((d = c.body) && 'function' == typeof d.getFormData) {
				c = c.body;
				b.headers['Content-Type'] = 'multipart/form-data;charset=utf-8';
				c = c.entries();
				d = [];
				for (e = c.next(); !e.done; e = c.next()) d.push(e.value);
				b.body = d;
			}
			return x({ originalRequest: { input: a, init: b }, ampComponent: f });
		}
		function Kb(a, b) {
			this.la = b;
			this.pa = F(a, 'viewport');
			this.Ba = E(a.win, 'vsync');
			this.ja = null;
			this.ia = '';
			this.ea = !1;
			this.J = a.win.document.createElement('div');
			$a(this.J, !1);
			this.J.classList.add('i-amphtml-validation-bubble');
			this.J.__BUBBLE_OBJ = this;
			a.getBody().appendChild(this.J);
		}
		Kb.prototype.isActiveOn = function(a) {
			return this.ea && a == this.ja;
		};
		Kb.prototype.hide = function() {
			this.ea &&
				((this.ea = !1),
				(this.ja = null),
				(this.ia = ''),
				this.Ba.run({ measure: void 0, mutate: Lb }, { bubbleElement: this.J }));
		};
		Kb.prototype.show = function(a, b) {
			(this.isActiveOn(a) && b == this.ia) ||
				((this.ea = !0),
				(this.ja = a),
				(this.ia = b),
				this.Ba.run(
					{ measure: Mb, mutate: Nb },
					{ message: b, targetElement: a, bubbleElement: this.J, viewport: this.pa, id: this.la }
				));
		};
		function Lb(a) {
			a.bubbleElement.removeAttribute('aria-alert');
			a.bubbleElement.removeAttribute('role');
			for (var b = a.bubbleElement; b.firstChild; ) b.removeChild(b.firstChild);
			$a(a.bubbleElement, !1);
		}
		function Mb(a) {
			a.targetRect = a.viewport.getLayoutRect(a.targetElement);
		}
		function Nb(a) {
			for (var b = a.bubbleElement; b.firstChild; ) b.removeChild(b.firstChild);
			var c = a.bubbleElement.ownerDocument.createElement('div');
			c.id = 'bubble-message-' + a.id;
			c.textContent = a.message;
			a.bubbleElement.setAttribute('aria-labeledby', c.id);
			a.bubbleElement.setAttribute('role', 'alert');
			a.bubbleElement.setAttribute('aria-live', 'assertive');
			a.bubbleElement.appendChild(c);
			$a(a.bubbleElement, !0);
			b = a.bubbleElement;
			a = { top: a.targetRect.top - 10 + 'px', left: a.targetRect.left + a.targetRect.width / 2 + 'px' };
			for (var d in a) Za(b, d, a[d]);
		}
		var Ob,
			Pb,
			Qb = 0;
		function R(a) {
			this.form = a;
			this.ampdoc = C(a);
			this.mutator = H(a);
			this.root = this.ampdoc.getRootNode();
			this.ca = null;
		}
		l = R.prototype;
		l.report = function() {};
		l.onBlur = function() {};
		l.onInput = function() {};
		l.inputs = function() {
			return this.form.querySelectorAll('input,select,textarea');
		};
		l.checkInputValidity = function(a) {
			if (
				'TEXTAREA' === a.tagName &&
				a.hasAttribute('pattern') &&
				(a.checkValidity() || 'Please match the requested format.' === a.validationMessage)
			) {
				var b = a.getAttribute('pattern'),
					c = new RegExp('^' + b + '$', 'm').test(a.value);
				a.setCustomValidity(c ? '' : 'Please match the requested format.');
			}
			return a.checkValidity();
		};
		l.checkFormValidity = function(a) {
			Rb(this, a);
			return a.checkValidity();
		};
		l.reportFormValidity = function(a) {
			Rb(this, a);
			return a.reportValidity();
		};
		function Rb(a, b) {
			G(b.elements, function(b) {
				'TEXTAREA' == b.tagName && a.checkInputValidity(b);
			});
		}
		l.fireValidityEventIfNecessary = function() {
			var a = this.ca;
			this.ca = this.checkFormValidity(this.form);
			if (a !== this.ca) {
				var b = cb(this.form.ownerDocument.defaultView, this.ca ? 'valid' : 'invalid', null, { bubbles: !0 });
				this.form.dispatchEvent(b);
			}
		};
		function Sb() {
			R.apply(this, arguments);
		}
		n(Sb, R);
		Sb.prototype.report = function() {
			this.reportFormValidity(this.form);
			this.fireValidityEventIfNecessary();
		};
		function S(a) {
			R.call(this, a);
			var b = 'i-amphtml-validation-bubble-' + Qb++;
			this.V = new Kb(this.ampdoc, b);
		}
		n(S, R);
		S.prototype.report = function() {
			for (var a = this.inputs(), b = 0; b < a.length; b++)
				if (!this.checkInputValidity(a[b])) {
					a[b].focus();
					this.V.show(a[b], a[b].validationMessage);
					break;
				}
			this.fireValidityEventIfNecessary();
		};
		S.prototype.onBlur = function(a) {
			'submit' != a.target.type && this.V.hide();
		};
		S.prototype.onInput = function(a) {
			a = a.target;
			this.V.isActiveOn(a) &&
				(this.checkInputValidity(a)
					? (a.removeAttribute('aria-invalid'), this.V.hide())
					: (a.setAttribute('aria-invalid', 'true'), this.V.show(a, a.validationMessage)));
		};
		function T(a) {
			R.call(this, a);
			this.Qa = this.form.id ? this.form.id : String(Date.now() + Math.floor(100 * Math.random()));
			this.Fa = 0;
		}
		n(T, R);
		l = T.prototype;
		l.reportInput = function(a) {
			var b = Tb(a);
			b && this.showValidationFor(a, b);
		};
		l.hideAllValidations = function() {
			for (var a = this.inputs(), b = 0; b < a.length; b++) this.hideValidationFor(a[b]);
		};
		l.getValidationFor = function(a, b) {
			if (!a.id) return null;
			var c = a.validationMessage;
			c =
				'TEXTAREA' === a.tagName && 'customError' === b && 'Please match the requested format.' === c
					? 'patternMismatch'
					: b;
			var d = '__AMP_VALIDATION_' + c;
			d in a ||
				(a[d] = this.root.querySelector('[visible-when-invalid=' + c + '][validation-for=' + (a.id + ']')));
			return a[d];
		};
		l.showValidationFor = function(a, b) {
			var c = this.getValidationFor(a, b);
			if (c) {
				c.textContent.trim() || (c.textContent = a.validationMessage);
				a.__AMP_VISIBLE_VALIDATION = c;
				var d = c.getAttribute('id');
				d || ((d = 'i-amphtml-aria-desc-' + this.Qa + '-' + this.Fa++), c.setAttribute('id', d));
				a.setAttribute('aria-invalid', 'true');
				a.setAttribute('aria-describedby', d);
				this.mutator.mutateElement(c, function() {
					return c.classList.add('visible');
				});
			}
		};
		l.hideValidationFor = function(a) {
			var b = this.getVisibleValidationFor(a);
			b &&
				(delete a.__AMP_VISIBLE_VALIDATION,
				a.removeAttribute('aria-invalid'),
				a.removeAttribute('aria-describedby'),
				this.mutator.mutateElement(b, function() {
					return b.classList.remove('visible');
				}));
		};
		l.getVisibleValidationFor = function(a) {
			return a.__AMP_VISIBLE_VALIDATION;
		};
		l.shouldValidateOnInteraction = function() {
			throw Error('Not Implemented');
		};
		l.onInteraction = function(a) {
			a = a.target;
			var b = !!a.checkValidity && this.shouldValidateOnInteraction(a);
			this.hideValidationFor(a);
			b && !this.checkInputValidity(a) && this.reportInput(a);
		};
		l.onBlur = function(a) {
			this.onInteraction(a);
		};
		l.onInput = function(a) {
			this.onInteraction(a);
		};
		function Ub() {
			T.apply(this, arguments);
		}
		n(Ub, T);
		Ub.prototype.report = function() {
			this.hideAllValidations();
			for (var a = this.inputs(), b = 0; b < a.length; b++)
				if (!this.checkInputValidity(a[b])) {
					this.reportInput(a[b]);
					a[b].focus();
					break;
				}
			this.fireValidityEventIfNecessary();
		};
		Ub.prototype.shouldValidateOnInteraction = function(a) {
			return !!this.getVisibleValidationFor(a);
		};
		function U() {
			T.apply(this, arguments);
		}
		n(U, T);
		U.prototype.report = function() {
			this.hideAllValidations();
			for (var a = null, b = this.inputs(), c = 0; c < b.length; c++)
				this.checkInputValidity(b[c]) || ((a = a || b[c]), this.reportInput(b[c]));
			a && a.focus();
			this.fireValidityEventIfNecessary();
		};
		U.prototype.shouldValidateOnInteraction = function(a) {
			return !!this.getVisibleValidationFor(a);
		};
		function Vb() {
			T.apply(this, arguments);
		}
		n(Vb, T);
		Vb.prototype.shouldValidateOnInteraction = function() {
			return !0;
		};
		Vb.prototype.onInteraction = function(a) {
			T.prototype.onInteraction.call(this, a);
			this.fireValidityEventIfNecessary();
		};
		function Wb() {
			U.apply(this, arguments);
		}
		n(Wb, U);
		Wb.prototype.shouldValidateOnInteraction = function() {
			return !0;
		};
		Wb.prototype.onInteraction = function(a) {
			U.prototype.onInteraction.call(this, a);
			this.fireValidityEventIfNecessary();
		};
		function Xb(a) {
			switch (a.getAttribute('custom-validation-reporting')) {
				case 'as-you-go':
					return new Vb(a);
				case 'show-all-on-submit':
					return new U(a);
				case 'interact-and-submit':
					return new Wb(a);
				case 'show-first-on-submit':
					return new Ub(a);
			}
			a.ownerDocument && void 0 === Ob && (Ob = !!document.createElement('form').reportValidity);
			return Ob ? new Sb(a) : new S(a);
		}
		function Tb(a) {
			var b = [ 'badInput' ];
			for (c in a.validity) b.includes(c) || b.push(c);
			var c = b.filter(function(b) {
				return !0 === a.validity[b];
			});
			return c.length ? c[0] : null;
		}
		function Yb(a) {
			var b = a.ownerDocument.defaultView;
			b.FormProxy || (b.FormProxy = Zb(b));
			var c = new b.FormProxy(a);
			'action' in c || $b(a, c);
			a.$p = c;
		}
		function Zb(a) {
			function b(a) {
				this.h = a;
			}
			var c = b.prototype,
				d = a.Object,
				e = d.prototype;
			[ a.HTMLFormElement, a.EventTarget ]
				.reduce(function(a, b) {
					for (b = b && b.prototype; b && b !== e && !(0 <= a.indexOf(b)); )
						a.push(b), (b = d.getPrototypeOf(b));
					return a;
				}, [])
				.forEach(function(b) {
					var d = {},
						f;
					for (f in b) {
						d.w = a.Object.getOwnPropertyDescriptor(b, f);
						if (d.w && f.toUpperCase() != f && !wa(f, 'on') && !e.hasOwnProperty.call(c, f))
							if ('function' == typeof d.w.value)
								(d.fa = d.w.value),
									(c[f] = (function(a) {
										return function() {
											return a.fa.apply(this.h, arguments);
										};
									})(d));
							else {
								var k = {};
								d.w.get &&
									(k.get = (function(a) {
										return function() {
											return a.w.get.call(this.h);
										};
									})(d));
								d.w.set &&
									(k.set = (function(a) {
										return function(b) {
											return a.w.set.call(this.h, b);
										};
									})(d));
								a.Object.defineProperty(c, f, k);
							}
						d = { fa: d.fa, w: d.w };
					}
				});
			return b;
		}
		function $b(a, b) {
			var c = a.ownerDocument.defaultView.HTMLFormElement.prototype.cloneNode.call(a, !1),
				d = {},
				e;
			for (e in c) {
				d.l = e;
				if (!(d.l in b || d.l.toUpperCase() == d.l || wa(d.l, 'on'))) {
					d.m = ac[d.l];
					var f = a[d.l];
					if (d.m)
						if (d.m.access == V) {
							d.N = void 0;
							if (f && f.nodeType) {
								var h = (c = f),
									g = h.nextSibling;
								h = h.parentNode;
								h.removeChild(c);
								try {
									d.N = a[d.l];
								} finally {
									h.insertBefore(c, g);
								}
							} else d.N = f;
							Object.defineProperty(b, d.l, {
								get: (function(a) {
									return function() {
										return a.N;
									};
								})(d)
							});
						} else
							d.m.access == W &&
								((d.O = d.m.attr || d.l),
								Object.defineProperty(b, d.l, {
									get: (function(c) {
										return function() {
											var d = b.getAttribute(c.O);
											return null == d && void 0 !== c.m.def
												? c.m.def
												: c.m.type == bc
													? 'true' === d
													: c.m.type == cc
														? null != d
														: c.m.type == dc ? ((d = d || ''), A(a, 'url').parse(d).href) : d;
										};
									})(d),
									set: (function(a) {
										return function(c) {
											a.m.type == cc && (c = c ? '' : null);
											null != c ? b.setAttribute(a.O, c) : b.removeAttribute(a.O);
										};
									})(d)
								}));
					else
						Object.defineProperty(b, d.l, {
							get: (function(b) {
								return function() {
									return a[b.l];
								};
							})(d),
							set: (function(b) {
								return function(c) {
									a[b.l] = c;
								};
							})(d)
						});
				}
				d = { N: d.N, O: d.O, m: d.m, l: d.l };
			}
		}
		var W = 1,
			V = 2,
			dc = 1,
			bc = 2,
			cc = 3,
			ac = {
				acceptCharset: { access: W, attr: 'accept-charset' },
				accessKey: { access: W, attr: 'accesskey' },
				action: { access: W, type: dc },
				attributes: { access: V },
				autocomplete: { access: W, def: 'on' },
				children: { access: V },
				dataset: { access: V },
				dir: { access: W },
				draggable: { access: W, type: bc, def: !1 },
				elements: { access: V },
				encoding: { access: V },
				enctype: { access: W },
				hidden: { access: W, type: cc, def: !1 },
				id: { access: W, def: '' },
				lang: { access: W },
				localName: { access: V },
				method: { access: W, def: 'get' },
				name: { access: W },
				noValidate: {
					access: W,
					attr: 'novalidate',
					type: cc,
					def: !1
				},
				prefix: { access: V },
				spellcheck: { access: W },
				style: { access: V },
				target: { access: W, def: '' },
				title: { access: W },
				translate: { access: W }
			};
		function ec(a, b) {
			var c = a.getHeadNode(),
				d = fc(c, jc(c));
			if (b) {
				var e = a.getRootNode();
				if (kc(e, d)) b(d);
				else
					var f = setInterval(function() {
						kc(e, d) && (clearInterval(f), b(d));
					}, 4);
			}
		}
		function fc(a, b) {
			var c = a.__AMP_CSS_SM;
			c || (c = a.__AMP_CSS_SM = w());
			var d = lc(a, c, 'amp-extension=amp-form');
			if (d) return d.textContent !== b && (d.textContent = b), d;
			var e = (a.ownerDocument || a).createElement('style');
			e.textContent = b;
			var f = null;
			e.setAttribute('amp-extension', 'amp-form');
			b = f = lc(a, c, 'amp-runtime');
			(b = void 0 === b ? null : b) ? a.insertBefore(e, b.nextSibling) : a.insertBefore(e, a.firstChild);
			return (c['amp-extension=amp-form'] = e);
		}
		function lc(a, b, c) {
			return b[c] ? b[c] : (a = a.querySelector('style[' + c + ']')) ? (b[c] = a) : null;
		}
		function jc(a) {
			return (a = a.__AMP_CSS_TR)
				? a(
						'form.amp-form-submit-error [submit-error],form.amp-form-submit-success [submit-success],form.amp-form-submitting [submitting]{display:block}textarea[autoexpand]:not(.i-amphtml-textarea-max){overflow:hidden!important}.i-amphtml-textarea-clone{visibility:hidden;position:absolute;top:-9999px;left:-9999px;height:0!important}.i-amphtml-validation-bubble{transform:translate(-50%,-100%);background-color:#fff;box-shadow:0 5px 15px 0 rgba(0,0,0,0.5);max-width:200px;position:absolute;display:block;box-sizing:border-box;padding:10px;border-radius:5px}.i-amphtml-validation-bubble:after{content:" ";position:absolute;bottom:-8px;left:30px;width:0;height:0;border-left:8px solid transparent;border-right:8px solid transparent;border-top:8px solid #fff}[visible-when-invalid]{color:red}\n/*# sourceURL=/extensions/amp-form/0.1/amp-form.css*/'
					)
				: 'form.amp-form-submit-error [submit-error],form.amp-form-submit-success [submit-success],form.amp-form-submitting [submitting]{display:block}textarea[autoexpand]:not(.i-amphtml-textarea-max){overflow:hidden!important}.i-amphtml-textarea-clone{visibility:hidden;position:absolute;top:-9999px;left:-9999px;height:0!important}.i-amphtml-validation-bubble{transform:translate(-50%,-100%);background-color:#fff;box-shadow:0 5px 15px 0 rgba(0,0,0,0.5);max-width:200px;position:absolute;display:block;box-sizing:border-box;padding:10px;border-radius:5px}.i-amphtml-validation-bubble:after{content:" ";position:absolute;bottom:-8px;left:30px;width:0;height:0;border-left:8px solid transparent;border-right:8px solid transparent;border-top:8px solid #fff}[visible-when-invalid]{color:red}\n/*# sourceURL=/extensions/amp-form/0.1/amp-form.css*/';
		}
		function kc(a, b) {
			var c = a.styleSheets;
			for (a = 0; a < c.length; a++) if (c[a].ownerNode == b) return !0;
			return !1;
		}
		function mc(a) {
			var b = a.documentElement;
			return [ '\u26a14email', 'amp4email' ].some(function(a) {
				return b.hasAttribute(a);
			});
		}
		function nc(a, b, c) {
			c = void 0 === c ? {} : c;
			var d = void 0 === d ? !0 : d;
			Wa(a, 'amp-analytics-instrumentation', 'amp-analytics').then(function(e) {
				e && e.triggerEventForTarget(a, b, c, d);
			});
		}
		function oc(a, b) {
			try {
				return JSON.parse(a);
			} catch (c) {
				return b && b(c), null;
			}
		}
		var pc = [ 'amp-selector' ];
		function qc(a, b) {
			var c = this;
			try {
				Yb(a);
			} catch (f) {
				u().error('amp-form', 'form proxy failed to install', f);
			}
			a.__AMP_FORM = this;
			this.la = b;
			this.S = a.ownerDocument;
			this.j = this.S.defaultView;
			this.Pa = E(this.j, 'timer');
			this.za = A(a, 'url-replace');
			this.ka = null;
			this.h = a;
			this.Ea = C(this.h);
			this.A = E(this.j, 'templates');
			this.qa = E(this.j, 'xhr');
			this.P = A(this.h, 'action');
			this.ta = H(this.h);
			this.L = F(this.h, 'viewer');
			this.T = new O(this.L, this.A);
			this.H = (this.h.getAttribute('method') || 'GET').toUpperCase();
			this.Oa = this.h.getAttribute('target');
			this.M = rc(this, 'action-xhr');
			this.Ua = rc(this, 'verify-xhr');
			this.Ha = sc(this);
			this.ya = !this.h.hasAttribute('novalidate');
			this.h.setAttribute('novalidate', '');
			this.ya || this.h.setAttribute('amp-novalidate', '');
			this.h.classList.add('i-amphtml-form');
			this.I = 'initial';
			b = this.h.elements;
			for (var d = 0; d < b.length; d++) {
				var e = b[d].name;
				v('__amp_source_origin' != e && '__amp_form_verify' != e, 'Illegal input name, %s found: %s', e, b[d]);
			}
			this.aa = new Db(this.h, this.j);
			this.W = Xb(this.h);
			this.Ra = tb(this.h, function() {
				return tc(c);
			});
			this.P.addToAllowlist('FORM', [ 'clear', 'submit' ], [ 'email' ]);
			this.P.installActionHandler(this.h, this.Da.bind(this));
			this.ma();
			uc(this);
			vc(this);
			this.ra = this.La = this.Ta = null;
			Pa(D(a), 'form-submit-service').then(function(a) {
				c.ra = a;
			});
			this.Ia = this.S && mc(this.S);
		}
		function rc(a, b) {
			var c = a.h.getAttribute(b);
			if (c) {
				var d = A(a.h, 'url');
				d.assertHttpsUrl(c, a.h, b);
				v(!d.isProxyOrigin(c), 'form %s should not be on AMP CDN: %s', b, a.h);
			}
			return c;
		}
		function sc(a) {
			var b = a.h.getAttribute('enctype');
			if ('application/x-www-form-urlencoded' === b || 'multipart/form-data' === b) return b;
			null !== b && t().warn('amp-form', 'Unexpected enctype: ' + b + ". Defaulting to 'multipart/form-data'.");
			return 'multipart/form-data';
		}
		l = qc.prototype;
		l.getXssiPrefix = function() {
			return this.h.getAttribute('xssi-prefix');
		};
		l.requestForFormFetch = function(a, b, c, d) {
			var e = x({ Accept: 'application/json' });
			if ('GET' == b || 'HEAD' == b) {
				wc(this);
				var f = J(this.h);
				d &&
					d.forEach(function(a) {
						return delete f[a];
					});
				c && va(f, c);
				var h = Fa(a, Ga(f));
			} else {
				h = a;
				if ('application/x-www-form-urlencoded' === this.Ha) {
					var g = Ga(J(this.h));
					e = x({ Accept: 'application/json', 'Content-Type': 'application/x-www-form-urlencoded' });
				} else g = Ab(this.j, this.h);
				d &&
					d.forEach(function(a) {
						return g.delete(a);
					});
				for (var k in c) g.append(k, c[k]);
			}
			var m = {
				xhrUrl: h,
				fetchOpt: x({
					body: g,
					method: b,
					credentials: 'include',
					headers: e
				})
			};
			return Ib(this.h).then(function(a) {
				a &&
					(v('POST' == m.fetchOpt.method, 'Cannot attach auth token with GET request.'),
					g.append('ampViewerAuthToken', a));
				return m;
			});
		};
		l.setXhrAction = function(a) {
			this.M = a;
		};
		l.Da = function(a) {
			var b = this;
			if (!a.satisfiesTrust(2)) return null;
			if ('submit' == a.method)
				return xc(this).then(function() {
					return 'submitting' != b.I && yc(b) ? zc(b, a.trust, null) : Promise.resolve(null);
				});
			'clear' === a.method && Ac(this);
			return null;
		};
		function xc(a) {
			if (a.ka) return a.ka;
			var b = a.h.querySelectorAll(pc.join(',')),
				c = na(b).map(function(a) {
					return a.whenBuilt();
				});
			return (a.ka = Bc(a, c, 2e3));
		}
		l.ma = function() {
			var a = this;
			this.Ea.whenNextVisible().then(function() {
				var b = a.h.querySelector('[autofocus]');
				if (b)
					try {
						b.focus();
					} catch (c) {}
			});
			this.h.addEventListener('submit', this.sa.bind(this), !0);
			this.h.addEventListener(
				'blur',
				function(b) {
					Cc(b.target);
					a.W.onBlur(b);
				},
				!0
			);
			this.h.addEventListener(
				'amp:form-value-change',
				function(b) {
					Cc(b.target);
					a.W.onInput(b);
				},
				!0
			);
			this.T.isEnabled() ||
				this.h.addEventListener('change', function(b) {
					a.Ra.onCommit().then(function(c) {
						var d = c.errors;
						c.updatedElements.forEach(Cc);
						a.W.onBlur(b);
						'verifying' === a.I &&
							(d.length
								? (X(a, 'verify-error'),
									Y(a, x({ verifyErrors: d })).then(function() {
										Dc(a, 'verify-error', d, 2);
									}))
								: X(a, 'initial'));
					});
				});
			this.h.addEventListener('input', function(b) {
				Cc(b.target);
				a.W.onInput(b);
			});
		};
		function uc(a) {
			Wa(a.h, 'inputmask', 'amp-inputmask').then(function(a) {
				a && a.install();
			});
		}
		function Ec(a, b) {
			Fc(a, 'Form analytics not supported');
			var c = x({}),
				d = J(a.h),
				e;
			for (e in d) Object.prototype.hasOwnProperty.call(d, e) && (c['formFields[' + e + ']'] = d[e].join(','));
			c.formId = a.h.id;
			nc(a.h, b, c);
		}
		function Ac(a) {
			a.h.reset();
			X(a, 'initial');
			a.h.classList.remove('user-valid');
			a.h.classList.remove('user-invalid');
			var b = a.h.querySelectorAll('.user-valid, .user-invalid');
			G(b, function(a) {
				a.classList.remove('user-valid');
				a.classList.remove('user-invalid');
			});
			var c = a.h.querySelectorAll('.visible[validation-for]');
			G(c, function(a) {
				a.classList.remove('visible');
			});
			Gc(a.h);
		}
		l.sa = function(a) {
			if ('submitting' == this.I || !yc(this))
				return a.stopImmediatePropagation(), a.preventDefault(), Promise.resolve(null);
			(this.M || 'POST' == this.H) && a.preventDefault();
			return zc(this, 3, a);
		};
		function zc(a, b, c) {
			try {
				var d = { form: a.h, actionXhrMutator: a.setXhrAction.bind(a) };
				a.ra.fire(d);
			} catch (k) {
				u().error('amp-form', 'Form submit service failed: %s', k);
			}
			var e = Hc(a),
				f = a.h.getElementsByClassName('i-amphtml-async-input');
			a.aa.onSubmitting();
			if (!a.M && 'GET' == a.H) {
				Fc(a, 'Non-XHR GETs not supported.');
				wc(a);
				if (0 === f.length) {
					for (d = 0; d < e.length; d++) a.za.expandInputValueSync(e[d]);
					Ic(a, !c);
					a.aa.onSubmitSuccess();
					return p();
				}
				c && c.preventDefault();
			}
			X(a, 'submitting');
			var h = [],
				g = [];
			g.push(Jc(a, e));
			G(f, function(b) {
				var c = Kc(a, b);
				b.classList.contains('i-async-require-action') ? h.push(c) : g.push(c);
			});
			return Promise.all(h).then(
				function() {
					return Bc(a, g, 1e4).then(
						function() {
							if (a.M) var c = Lc(a, b);
							else
								'POST' == a.H
									? v(
											!1,
											'Only XHR based (via action-xhr attribute) submissions are supported for POST requests. %s',
											a.h
										)
									: 'GET' == a.H && Ic(a, !0),
									(c = p());
							return c;
						},
						function(c) {
							return Mc(a, c, b);
						}
					);
				},
				function(c) {
					return Mc(a, c, b);
				}
			);
		}
		function Mc(a, b, c) {
			var d = {};
			b && b.message && (d.error = b.message);
			return Nc(a, b, d, c);
		}
		function Hc(a) {
			return a.h.querySelectorAll('[type="hidden"][data-amp-replace]');
		}
		function tc(a) {
			if ('submitting' === a.I) return p();
			X(a, 'verifying');
			Dc(a, 'verify', null, 3);
			return Jc(a, Hc(a)).then(function() {
				return Oc(a);
			});
		}
		function Lc(a, b) {
			if (a.T.isEnabled()) var c = Pc(a, b);
			else
				Qc(a, b),
					(c = a.ba(a.M, a.H).then(
						function(c) {
							return Rc(a, c, b);
						},
						function(c) {
							return Sc(a, c, b);
						}
					));
			return c;
		}
		function Pc(a, b) {
			var c,
				d = J(a.h);
			return Y(a, d)
				.then(function() {
					return a.P.trigger(a.h, 'submit', null, b);
				})
				.then(function() {
					return a.requestForFormFetch(a.M, a.H);
				})
				.then(function(b) {
					var d = (c = b),
						e = c.fetchOpt || {};
					var g = e.method;
					void 0 === g ? (g = 'GET') : ((g = g.toUpperCase()), Hb.includes(g));
					e.method = g;
					e.headers = e.headers || x({});
					d.fetchOpt = e;
					d = c;
					g = c.xhrUrl;
					e = (e = c.fetchOpt) || {};
					var k = a.j;
					k = k.origin || z(k.location.href).origin;
					g = z(g).origin;
					k == g && ((e.headers = e.headers || {}), (e.headers['AMP-Same-Origin'] = 'true'));
					d.fetchOpt = e;
					d = c;
					g = a.j;
					e = c.xhrUrl;
					if (!1 !== c.fetchOpt.ampCors) {
						k = z(e);
						k = la(k.search);
						v(!('__amp_source_origin' in k), 'Source origin is not allowed in %s', e);
						g = g.location.href;
						'string' == typeof g && (g = z(g));
						if (Ha(g)) {
							k = g.pathname.split('/');
							v(xa[k[1]], 'Unknown path prefix in url %s', g.href);
							var m = k[2],
								P =
									's' == m
										? 'https://' + decodeURIComponent(k[3])
										: 'http://' + decodeURIComponent(m);
							v(0 < P.indexOf('.'), 'Expected a . in origin %s', P);
							k.splice(1, 's' == m ? 3 : 2);
							k = P + k.join('/');
							m =
								(m = g.search) && '?' != m
									? (m = m
											.replace(Aa, '')
											.replace(Ba, '')
											.replace(Ca, '')
											.replace(Da, '')
											.replace(Ea, '')
											.replace(/^[?&]/, ''))
										? '?' + m
										: ''
									: '';
							g = k + m + (g.hash || '');
						} else g = g.href;
						g = z(g).origin;
						g = encodeURIComponent('__amp_source_origin') + '=' + encodeURIComponent(g);
						e = Fa(e, g, void 0);
					}
					d.xhrUrl = e;
					return a.T.ssr(a.h, c, Tc(a));
				})
				.then(
					function(c) {
						return Uc(a, c, b);
					},
					function(c) {
						var d = {};
						c && c.message && (d.error = c.message);
						return Nc(a, c, d, b);
					}
				);
		}
		function Tc(a) {
			var b,
				c = a.h.querySelector('[submit-success]');
			c && (b = a.A.maybeFindTemplate(c));
			var d,
				e = a.h.querySelector('[submit-error]');
			e && (d = a.A.maybeFindTemplate(e));
			return { successTemplate: b, errorTemplate: d };
		}
		function Uc(a, b, c) {
			var d = b.init,
				e = oc(b.body, function(a) {
					return t().error('amp-form', 'Failed to parse response JSON: %s', a);
				});
			return d && ((d = d.status), 300 <= d) ? Nc(a, d, b, c, e) : Vc(a, b, c, e);
		}
		function Qc(a, b) {
			Ec(a, 'amp-form-submit');
			var c = J(a.h);
			Y(a, c).then(function() {
				a.P.trigger(a.h, 'submit', null, b);
			});
		}
		function Jc(a, b) {
			for (var c = [], d = 0; d < b.length; d++) c.push(a.za.expandInputValueAsync(b[d]));
			return Bc(a, c, 100);
		}
		function Kc(a, b) {
			return b
				.getImpl()
				.then(function(a) {
					return a.getValue();
				})
				.then(function(c) {
					var d = b.getAttribute('name');
					d = a.h.querySelector('input[name=' + String(d).replace(Ra, Sa) + ']');
					if (!d) {
						d = x({ name: b.getAttribute('name'), hidden: 'true' });
						var e = a.j.document.createElement('input'),
							f;
						for (f in d) e.setAttribute(f, d[f]);
						d = e;
					}
					d.setAttribute('value', c);
					a.h.appendChild(d);
				});
		}
		function Oc(a) {
			var b = na(a.h.querySelectorAll('[' + 'no-verify'.replace(Ra, Sa) + ']')).map(function(a) {
					return a.name || a.id;
				}),
				c = {};
			return a.ba(a.Ua, a.H, ((c.__amp_form_verify = !0), c), b);
		}
		l.ba = function(a, b, c, d) {
			var e = this;
			Fc(this, 'XHRs should be proxied.');
			return this.requestForFormFetch(a, b, c, d).then(function(a) {
				return e.qa.fetch(a.xhrUrl, a.fetchOpt);
			});
		};
		function Rc(a, b, c) {
			return a.qa
				.xssiJson(b, a.getXssiPrefix())
				.then(
					function(b) {
						return Vc(a, b, c);
					},
					function(a) {
						return t().error('amp-form', 'Failed to parse response JSON: %s', a);
					}
				)
				.then(function() {
					Ec(a, 'amp-form-submit-success');
					Wc(a, b);
				});
		}
		function Vc(a, b, c, d) {
			X(a, 'submit-success');
			return sa(function() {
				Y(a, b || {}).then(function() {
					Dc(a, 'submit-success', void 0 === d ? b : d, c - 1);
					a.aa.onSubmitSuccess();
				});
			});
		}
		function Sc(a, b, c) {
			return (b && b.response
				? a.qa.xssiJson(b.response, a.getXssiPrefix()).catch(function() {
						return null;
					})
				: Promise.resolve(null)).then(function(d) {
				Ec(a, 'amp-form-submit-error');
				Nc(a, b, d, c);
				Wc(a, b.response);
			});
		}
		function Nc(a, b, c, d, e) {
			X(a, 'submit-error');
			t().error('amp-form', 'Form submission failed: %s', b);
			return sa(function() {
				Y(a, c).then(function() {
					Dc(a, 'submit-error', void 0 === e ? c : e, d - 1);
					a.aa.onSubmitError();
				});
			});
		}
		function Ic(a, b) {
			Ec(a, 'amp-form-submit');
			b && a.h.submit();
			X(a, 'initial');
		}
		function Fc(a, b) {
			var c = a.T.isEnabled();
			v(!1 === c, '[amp-form]: viewerRenderTemplate | %s', b);
		}
		function wc(a) {
			var b = a.h.querySelectorAll('input[type=password],input[type=file]');
			v(0 == b.length, 'input[type=password] or input[type=file] may only appear in form[method=post]');
		}
		function yc(a) {
			void 0 === Pb && (Pb = !!a.j.document.createElement('input').checkValidity);
			if (Pb) {
				var b = Xc(a.h);
				if (a.ya) return a.W.report(), b;
			}
			return !0;
		}
		function Wc(a, b) {
			Fc(a, 'Redirects not supported.');
			if (b && b.headers) {
				var c = b.headers.get('AMP-Redirect-To');
				if (c) {
					v(!a.Ia, 'Redirects not supported in AMP4Email.', a.h);
					v(
						'_blank' != a.Oa,
						'Redirecting to target=_blank using AMP-Redirect-To is currently not supported, use target=_top instead. %s',
						a.h
					);
					try {
						var d = A(a.h, 'url');
						d.assertAbsoluteHttpOrHttpsUrl(c);
						d.assertHttpsUrl(c, 'AMP-Redirect-To', 'Url');
					} catch (e) {
						v(
							!1,
							'The `AMP-Redirect-To` header value must be an absolute URL starting with https://. Found %s',
							c
						);
					}
					F(a.h, 'navigation').navigateTo(a.j, c, 'AMP-Redirect-To');
				}
			}
		}
		function Dc(a, b, c, d) {
			c = cb(a.j, 'amp-form.' + b, x({ response: c }));
			a.P.trigger(a.h, b, c, d);
		}
		function Bc(a, b, c) {
			return Promise.race([ Promise.all(b), a.Pa.promise(c) ]);
		}
		function X(a, b) {
			var c = a.I;
			a.h.classList.remove('amp-form-' + c);
			a.h.classList.add('amp-form-' + b);
			var d = a.h.querySelector('[' + c + ']');
			if (d) {
				/^[\w-]+$/.test('i-amphtml-rendered');
				if (void 0 !== Ta) var e = Ta;
				else {
					try {
						var f = d.ownerDocument,
							h = f.createElement('div'),
							g = f.createElement('div');
						h.appendChild(g);
						e = h.querySelector(':scope div') === g;
					} catch (k) {
						e = !1;
					}
					e = Ta = e;
				}
				e
					? (d = d.querySelector('> [i-amphtml-rendered]'.replace(/^|,/g, '$&:scope ')))
					: (d.classList.add('i-amphtml-scoped'),
						(e = '> [i-amphtml-rendered]'.replace(/^|,/g, '$&.i-amphtml-scoped ')),
						(e = d.querySelectorAll(e)),
						d.classList.remove('i-amphtml-scoped'),
						(d = void 0 === e[0] ? null : e[0]));
				d && d.parentElement && d.parentElement.removeChild(d);
			}
			a.I = b;
		}
		function Y(a, b) {
			Array.isArray(b) &&
				((b = {}), t().warn('amp-form', 'Unexpected data type: ' + b + '. Expected non JSON array.'));
			var c = a.h.querySelector('[' + a.I + ']'),
				d = p();
			if (c) {
				var e = 'rendered-message-' + a.la;
				c.setAttribute('role', 'alert');
				c.setAttribute('aria-labeledby', e);
				c.setAttribute('aria-live', 'assertive');
				a.A.hasTemplate(c)
					? (d = a.T.applySsrOrCsrTemplate(c, b).then(function(b) {
							if (Array.isArray(b))
								if (1 === b.length) var d = b[0];
								else
									(d = document.createElement('div')),
										b.forEach(function(a) {
											return d.appendChild(a);
										});
							else d = b;
							d.id = e;
							d.setAttribute('i-amphtml-rendered', '');
							return a.ta.mutateElement(c, function() {
								c.appendChild(d);
								var b = cb(a.j, 'amp:dom-update', null, { bubbles: !0 });
								c.dispatchEvent(b);
							});
						}))
					: a.ta.mutateElement(c, function() {});
			}
			return d;
		}
		function vc(a) {
			if (!Ha(a.j.location) && a.h.hasAttribute('data-initialize-from-url')) {
				var b = [ 'SELECT', 'TEXTAREA' ],
					c = 'color date datetime-local email hidden month number range search tel text time url week'.split(
						' '
					),
					d = [ 'checkbox', 'radio' ],
					e = function(a, e) {
						if (!a.hasAttribute('data-amp-replace') && a.hasAttribute('data-allow-initialization')) {
							e = f[e] || '';
							var g = a.getAttribute('type') || 'text',
								h = a.tagName;
							'INPUT' === h
								? c.includes(g.toLocaleLowerCase())
									? a.value !== e && (a.value = e)
									: d.includes(g) && ((e = a.value === e), a.checked !== e && (a.checked = e))
								: b.includes(h) && a.value !== e && (a.value = e);
						}
					},
					f = la(a.j.location.search);
				Object.keys(f).forEach(function(b) {
					var c = a.h.elements[b];
					c &&
						(c.nodeType === Node.ELEMENT_NODE
							? e(c, b)
							: c.length &&
								G(c, function(a) {
									return e(a, b);
								}));
				});
			}
		}
		l.Va = function() {
			return this.La;
		};
		l.Xa = function() {
			return this.Ta;
		};
		function Xc(a) {
			var b = a.querySelectorAll('input,select,textarea,fieldset');
			G(b, function(a) {
				return Z(a);
			});
			return Z(a);
		}
		function Gc(a) {
			var b = document.createElement('input'),
				c = {},
				d;
			for (d in b.validity) {
				c.Z = d;
				var e = a.querySelectorAll('.' + String(c.Z).replace(Ra, Sa));
				G(
					e,
					(function(a) {
						return function(b) {
							b.classList.remove(a.Z);
						};
					})(c)
				);
				c = { Z: c.Z };
			}
		}
		function Z(a, b) {
			b = void 0 === b ? !1 : b;
			if (!a.checkValidity) return !0;
			var c = !1;
			var d = a.classList.contains('user-valid')
				? 'valid'
				: a.classList.contains('user-invalid') ? 'invalid' : 'none';
			var e = a.checkValidity();
			'valid' != d && e
				? (a.classList.add('user-valid'), a.classList.remove('user-invalid'), (c = 'invalid' == d))
				: 'invalid' == d || e || (a.classList.add('user-invalid'), a.classList.remove('user-valid'), (c = !0));
			if (a.validity) for (var f in a.validity) a.classList.toggle(f, a.validity[f]);
			if (b && c) {
				d = Va(a);
				for (f = 0; f < d.length; f++) Z(d[f]);
				a.form && Z(a.form);
			}
			return e;
		}
		function Cc(a) {
			Z(a, !0);
		}
		function Yc(a) {
			this.Sa = Zc(a).then(function() {
				return $c(a);
			});
		}
		Yc.prototype.whenInitialized = function() {
			return this.Sa;
		};
		function Zc(a) {
			var b = new ra();
			ec(a, b.resolve);
			return b.promise;
		}
		function $c(a) {
			return a.whenReady().then(function() {
				var b = a.getRootNode();
				ad(b.querySelectorAll('form'));
				nb(a);
				bd(b);
				cd(b);
			});
		}
		function ad(a) {
			a &&
				G(a, function(a, c) {
					a.__AMP_FORM || new qc(a, 'amp-form-' + c);
				});
		}
		function bd(a) {
			a.addEventListener('amp:dom-update', function() {
				ad(a.querySelectorAll('form'));
			});
		}
		function cd(a) {
			a.addEventListener('keydown', function(a) {
				if (
					!a.defaultPrevented &&
					'Enter' == a.key &&
					(a.ctrlKey || a.metaKey) &&
					'TEXTAREA' === a.target.tagName
				) {
					var b = a.target.form,
						d = b ? b.__AMP_FORM || null : null;
					d && (d.sa(a), a.preventDefault());
				}
			});
		}
		(function(a) {
			a.registerServiceForDoc('form-submit-service', Gb);
			a.registerServiceForDoc('amp-form', Yc);
		})(self.AMP);
	}
});
